package com.local.web.health.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.local.web.health.dao.WeightLogDao;
import com.local.web.health.model.WeightLog;
import com.local.web.health.service.WeightLogService;

@Service
public class WeightLogServiceImpl implements WeightLogService {
    
    @Autowired
    private WeightLogDao weightLogDao;
    
    @Override
    public List<Map<String,Object>> queryAll() {
        // TODO Auto-generated method stub
        return weightLogDao.queryAll();
    }

    @Override
    public List<WeightLog> queryByExample(WeightLog log) {
        // TODO Auto-generated method stub
        return weightLogDao.queryByExample(log);
    }

    @Override
    public List<Map<String, Object>> queryByMap(Map<String, Object> map) {
        // TODO Auto-generated method stub
        return weightLogDao.queryByMap(map);
    }

    @Override
    public int add(WeightLog log) {
        // TODO Auto-generated method stub
        return weightLogDao.add(log);
    }

    @Override
    public void updateByExample(WeightLog log) {
        // TODO Auto-generated method stub
        weightLogDao.updateByExample(log);
    }

    @Override
    public void delByExample(WeightLog log) {
        // TODO Auto-generated method stub
        weightLogDao.delByExample(log);
    }

}
