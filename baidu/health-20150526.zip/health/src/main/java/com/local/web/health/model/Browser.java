/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: Browser.java
 * Author:   14041326
 * Date:     2014年9月3日 下午2:52:19
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.model;

/**
 * 浏览器相关信息<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class Browser {
    private Integer bid;
    private String userAgent;
    private String screen;
    private String ip;
    
    public Browser() {
        // TODO Auto-generated constructor stub
    }
    
    public Browser(String userAgent, String screen, String ip) {
        this.userAgent = userAgent;
        this.screen = screen;
        this.ip = ip;
    }



    /**
     * @return the bid
     */
    public Integer getBid() {
        return bid;
    }
    /**
     * @param bid the bid to set
     */
    public void setBid(Integer bid) {
        this.bid = bid;
    }
    /**
     * @return the userAgent
     */
    public String getUserAgent() {
        return userAgent;
    }
    /**
     * @param userAgent the userAgent to set
     */
    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }
    /**
     * @return the screen
     */
    public String getScreen() {
        return screen;
    }
    /**
     * @param screen the screen to set
     */
    public void setScreen(String screen) {
        this.screen = screen;
    }
    /**
     * @return the ip
     */
    public String getIp() {
        return ip;
    }
    /**
     * @param ip the ip to set
     */
    public void setIp(String ip) {
        this.ip = ip;
    }
    
}
