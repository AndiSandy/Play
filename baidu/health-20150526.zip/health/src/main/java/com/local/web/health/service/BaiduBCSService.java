/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: BaiduBCSService.java
 * Author:   14041326
 * Date:     2015年1月7日 上午11:58:06
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

import com.baidu.inf.iis.bcs.model.ObjectMetadata;
import com.baidu.inf.iis.bcs.model.ObjectSummary;

/**
 * baidu 云存储服务<br> 
 * 将静态资源存储在百度云存储上
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public interface BaiduBCSService {
    
    //delete
    
    //copy
    
    //put
	/**
	 * 
	 * 功能描述: 存储文件流<br>
	 * 〈功能详细描述〉
	 *
	 * @param file
	 * @param is
	 * @param mime
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public ObjectMetadata put(String filename, InputStream is, String mime,long length);
	
	/**
	 * 
	 * 功能描述: 存储文件<br>
	 * 〈功能详细描述〉
	 *
	 * @param file
	 * @param is
	 * @param mime
	 * @return
	 * @throws FileNotFoundException 
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public ObjectMetadata put(String filename, File file, String mime) throws FileNotFoundException;
    
    //get
    
	public String get(String filename);
	
    //list
	/**
	 * 
	 * 功能描述: 列出文件<br>
	 * 〈功能详细描述〉
	 *
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public List<ObjectSummary> list(int start, int pagesize, String prefix);
    
}
