/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: BrowserController.java
 * Author:   14041326
 * Date:     2014年9月3日 下午3:29:32
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.controller.webadmin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.local.web.health.model.Browser;
import com.local.web.health.service.BrowserService;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/webadmin/browser")
public class BrowserController {
    
    @Autowired
    private BrowserService browserService;

    /**
     * 
     * 功能描述: 浏览器-列表信息<br>
     * 〈功能详细描述〉
     *
     * @param screen
     * @param request
     * @param response
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping(value = "list")
    public String list(HttpServletRequest request, HttpServletResponse response) {
        String page_ftl = "webadmin/browser-list.ftl";
        
        List<Map<String, Object>> browsers = browserService.queryAll();

        request.setAttribute("browsers", browsers);
        
        return page_ftl;
    }
    
    
    @RequestMapping(value = "save")
    @ResponseBody
    public Map<String, Object> save(@RequestParam(value = "timeName", required = false) String timeName,
            @RequestParam(value = "objid", required = true) Integer objid,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        
        Browser obj = new Browser();
        if(objid != null){
            obj.setBid(objid);
            browserService.updateByExample(obj);
        }else{
            
        }
        
        map.put("success", true);
        map.put("txt", "保存更新信息成功");
        map.put("obj", obj);
        
        return map;
    }
    
    @RequestMapping(value = "del")
    @ResponseBody
    public Map<String, Object> del(@RequestParam(value = "objid", required = true) Integer objid,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        Browser obj = new Browser();
        obj.setBid(objid);
        browserService.delByExample(obj);
        map.put("success", true);
        map.put("txt", "删除信息成功");
        
        return map;
    }
    
    @RequestMapping(value = "query")
    @ResponseBody
    public Map<String, Object> query(@RequestParam(value = "objid", required = true) Integer objid,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        
        Browser obj = new Browser();
        obj.setBid(objid);
        List<Browser> objs = browserService.queryByExample(obj);
        if(objs.size() > 0){
            obj = objs.get(0);
            map.put("success", true);
            map.put("txt", "查询信息成功");
            map.put("obj", obj);
        }else{
            map.put("success", false);
            map.put("txt", "查询信息失败,记录不存在!");
        }
        
        return map;
    }
    
}
