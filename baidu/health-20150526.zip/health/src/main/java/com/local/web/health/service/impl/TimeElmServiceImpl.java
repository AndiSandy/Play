/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: TimeElmServiceImpl.java
 * Author:   14041326
 * Date:     2014年8月28日 下午2:59:04
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.local.web.health.dao.TimeElmDao;
import com.local.web.health.model.TimeElm;
import com.local.web.health.service.TimeElmService;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Service
public class TimeElmServiceImpl implements TimeElmService {
    
    @Autowired
    private TimeElmDao timeElmDao;

    /* (non-Javadoc)
     * @see com.local.web.health.service.TimeElmService#queryAll()
     */
    @Override
    public List<TimeElm> queryAll() {
        // TODO Auto-generated method stub
        return timeElmDao.queryAll();
    }

    /* (non-Javadoc)
     * @see com.local.web.health.service.TimeElmService#queryByExample(com.local.web.health.model.TimeElm)
     */
    @Override
    public List<TimeElm> queryByExample(TimeElm time) {
        // TODO Auto-generated method stub
        return timeElmDao.queryByExample(time);
    }

    /* (non-Javadoc)
     * @see com.local.web.health.service.TimeElmService#add(com.local.web.health.model.TimeElm)
     */
    @Override
    public int add(TimeElm time) {
        // TODO Auto-generated method stub
        return timeElmDao.add(time);
    }

    /* (non-Javadoc)
     * @see com.local.web.health.service.TimeElmService#updateByExample(com.local.web.health.model.TimeElm)
     */
    @Override
    public void updateByExample(TimeElm time) {
        // TODO Auto-generated method stub
        timeElmDao.updateByExample(time);
    }

    /* (non-Javadoc)
     * @see com.local.web.health.service.TimeElmService#delByExample(com.local.web.health.model.TimeElm)
     */
    @Override
    public void delByExample(TimeElm time) {
        // TODO Auto-generated method stub
        timeElmDao.delByExample(time);
    }

	@Override
	public int getNextOrder() {
		// TODO Auto-generated method stub
		return timeElmDao.getNextOrder();
	}

	@Override
	public TimeElm queryById(Integer timeId) {
		// TODO Auto-generated method stub
		return timeElmDao.queryById(timeId);
	}

}
