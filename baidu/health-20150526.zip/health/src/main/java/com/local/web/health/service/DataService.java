/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: DataImportService.java
 * Author:   Administrator
 * Date:     2015年2月25日 下午2:28:48
 * Description: 数据服务//模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.service;

import java.util.List;
import java.util.Map;

/**
 * 〈一句话功能简述〉数据服务<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public interface DataService {
	
	/**
	 * 
	 * 功能描述: 导入json数据<br>
	 * 〈功能详细描述〉
	 *
	 * @param jsondata
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public Map<String, Object> importData(Map<String,Object> jsondata);
	
	/**
	 * 
	 * 功能描述: 查询数据<br>
	 * 〈功能详细描述〉
	 *
	 * @param jsondata
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public List<Map<String, Object>> query(Map<String,Object> jsondata);
	
	/**
	 * 
	 * 功能描述: 查询总量<br>
	 * 〈功能详细描述〉
	 *
	 * @param jsondata
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public int queryTotal(Map<String,Object> jsondata);
	
	
	/**
	 * 
	 * 功能描述: 查询数据是否存在<br>
	 * 〈功能详细描述〉
	 *
	 * @param table
	 * @param id
	 * @param o
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public boolean exist(String table, String id, Map<String,Object> o);
	
	/**
	 * 
	 * 功能描述: 更新数据<br>
	 * 〈功能详细描述〉
	 *
	 * @param table
	 * @param id
	 * @param o
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public Map<String,Object> update(String table, String id, Map<String,Object> o);
	
	/**
	 * 
	 * 功能描述: 添加数据<br>
	 * 〈功能详细描述〉
	 *
	 * @param table
	 * @param o
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public Map<String,Object> insert(String table, String id, Map<String,Object> o);
	
}
