/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: TimeElmService.java
 * Author:   14041326
 * Date:     2014年8月28日 下午2:57:06
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.service;

import java.util.List;

import com.local.web.health.model.TimeElm;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public interface TimeElmService {
    public List<TimeElm> queryAll();
    public List<TimeElm> queryByExample(TimeElm time);
    public TimeElm queryById(Integer timeId);
    public int add(TimeElm time);
    public void updateByExample(TimeElm time);
    public void delByExample(TimeElm time);
    public int getNextOrder();
}
