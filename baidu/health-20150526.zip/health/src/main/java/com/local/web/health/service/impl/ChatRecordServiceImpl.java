/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: ChatRecordServiceImpl.java
 * Author:   Administrator
 * Date:     2015年1月16日 下午10:49:10
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.local.web.health.dao.ChatRecordDao;
import com.local.web.health.model.ChatRecord;
import com.local.web.health.service.ChatRecordService;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Service
public class ChatRecordServiceImpl implements ChatRecordService {
	
	@Autowired
	private ChatRecordDao chatRecordDao;
	
	/* (non-Javadoc)
	 * @see com.local.web.health.service.ChatRecordService#add(com.local.web.health.model.ChatRecord)
	 */
	@Override
	public void add(ChatRecord record) {
		chatRecordDao.add(record);
	}

	/* (non-Javadoc)
	 * @see com.local.web.health.service.ChatRecordService#delete(com.local.web.health.model.ChatRecord)
	 */
	@Override
	public void delete(ChatRecord record) {
		chatRecordDao.delete(record);
	}

	@Override
	public List<Map<String, Object>> query(Map<String, Object> record) {
		return chatRecordDao.query(record);
	}

}
