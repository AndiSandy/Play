/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: BrowserServiceImpl.java
 * Author:   14041326
 * Date:     2014年9月3日 下午3:05:41
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.local.web.health.dao.BrowserDao;
import com.local.web.health.model.Browser;
import com.local.web.health.service.BrowserService;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Service
public class BrowserServiceImpl implements BrowserService {
    
    @Autowired
    private BrowserDao browserDao;
    
    /* (non-Javadoc)
     * @see com.local.web.health.service.BrowserService#queryAll()
     */
    @Override
    public List<Map<String, Object>> queryAll() {
        return browserDao.queryAll();
    }

    /* (non-Javadoc)
     * @see com.local.web.health.service.BrowserService#queryByExample(com.local.web.health.model.Browser)
     */
    @Override
    public List<Browser> queryByExample(Browser browser) {
        return browserDao.queryByExample(browser);
    }

    /* (non-Javadoc)
     * @see com.local.web.health.service.BrowserService#queryByMap(java.util.Map)
     */
    @Override
    public List<Map<String, Object>> queryByMap(Map<String, Object> map) {
        return browserDao.queryByMap(map);
    }

    /* (non-Javadoc)
     * @see com.local.web.health.service.BrowserService#add(com.local.web.health.model.Browser)
     */
    @Override
    public int add(Browser browser) {
        // TODO Auto-generated method stub
        return browserDao.add(browser);
    }

    /* (non-Javadoc)
     * @see com.local.web.health.service.BrowserService#updateByExample(com.local.web.health.model.Browser)
     */
    @Override
    public void updateByExample(Browser browser) {
        // TODO Auto-generated method stub
        browserDao.updateByExample(browser);
    }

    /* (non-Javadoc)
     * @see com.local.web.health.service.BrowserService#delByExample(com.local.web.health.model.Browser)
     */
    @Override
    public void delByExample(Browser browser) {
        // TODO Auto-generated method stub
        browserDao.delByExample(browser);
    }

}
