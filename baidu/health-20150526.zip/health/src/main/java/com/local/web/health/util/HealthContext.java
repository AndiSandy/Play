/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: HealthContext.java
 * Author:   Administrator
 * Date:     2014年8月23日 下午11:04:04
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.util;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class HealthContext {
	
	
	/**
	 * 登录-让入session的标记
	 */
	public	final static String SESSON_LOGIN_USER = "session-login-user";
	
	
	/**
	 * 聊天的session名称
	 */
	public final static String CHAT_SESSION_NAME = "CHAT-JSESSIONID";
	
	/**
	 * 聊天的用户
	 */
	public final static String CHAT_USER = "session-chat-user";
	
	public final static String CHAT_ENABLE_RECORDS = "chat-enable-records";
	
	public final static String CHAT_VERSION = "v.1.0.0";
	
	public final static String CHAT_VERSION_NAME = "chat.v";
	
}
