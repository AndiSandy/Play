/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: BaiduImageServiceImpl.java
 * Author:   Administrator
 * Date:     2014年8月30日 上午10:39:08
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.service.impl;

import com.baidu.bae.api.factory.BaeFactory;
import com.baidu.bae.api.image.BaeImageService;
import com.baidu.bae.api.image.QRCode;
import com.local.web.health.service.BaiduImageService;

/**
 * 百度图片服务<br>
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class BaiduImageServiceImpl implements BaiduImageService {

	private String user;
	private String password;
	private String imageHost;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.local.web.health.service.BaiduImageService#getQRCodeImage(java.lang
	 * .String)
	 */
	@Override
	public byte[] getQRCodeImage(String text, int size, String background) {
		try{
			BaeImageService service = BaeFactory.getBaeImageService(user, password, imageHost);
			QRCode qrcode = new QRCode(text);
			qrcode.setSize(size);
			qrcode.setBackground(background);
			byte[] bs = service.applyQRCode(qrcode);
			return bs;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getImageHost() {
		return imageHost;
	}

	public void setImageHost(String imageHost) {
		this.imageHost = imageHost;
	}

	
	
	

}
