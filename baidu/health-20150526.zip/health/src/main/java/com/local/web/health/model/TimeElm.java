/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: TimeElm.java
 * Author:   14041326
 * Date:     2014年8月28日 上午9:17:47
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.model;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class TimeElm {
    
    private Integer timeId;
    private String timeName;
    private Integer orderno;
    
    public TimeElm() {
        // TODO Auto-generated constructor stub
    }
    
    public TimeElm(String timeName) {
        this.timeName = timeName;
    }

    /**
     * @return the timeId
     */
    public Integer getTimeId() {
        return timeId;
    }

    /**
     * @param timeId the timeId to set
     */
    public void setTimeId(Integer timeId) {
        this.timeId = timeId;
    }

    /**
     * @return the timeName
     */
    public String getTimeName() {
        return timeName;
    }

    /**
     * @param timeName the timeName to set
     */
    public void setTimeName(String timeName) {
        this.timeName = timeName;
    }

	public Integer getOrderno() {
		return orderno;
	}

	public void setOrder(Integer orderno) {
		this.orderno = orderno;
	}
    
    
    
}
