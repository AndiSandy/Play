/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: DebugController.java
 * Author:   14041326
 * Date:     2014年9月3日 下午2:09:34
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.local.web.health.model.Browser;
import com.local.web.health.service.BrowserService;
import com.local.web.util.SNStringUtils;

/**
 * 〈一句话功能简述〉<br>
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/debug")
public class DebugController {

    @Autowired
    private BrowserService browserService;

    @RequestMapping(value = "browser")
    @ResponseBody
    public Map<String, Object> browser(@RequestParam(value = "screen", required = true) String screen,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();

        // getip
        String ip = getIpAddr(request);
        // getUserAgent
        String userAgent = request.getHeader("User-Agent");
        // save browserService
        if(!SNStringUtils.isEmpty(screen) && !SNStringUtils.isEmpty(userAgent)){
            Browser browser = new Browser(userAgent, screen, ip);
            browserService.add(browser);
            map.put("success", true);
            map.put("txt", "保存信息成功");
            map.put("browser", browser);
        }else{
            map.put("success", false);
            map.put("txt", "保存调试信息失败!");
        }
        return map;
    }

    /**
     * 
     * 功能描述: 获取客户端ip<br>
     * 〈功能详细描述〉
     *
     * @param request
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static String getIpAddr(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

}
