/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: ChatUploadServiceImpl.java
 * Author:   14041326
 * Date:     2015年1月16日 下午1:51:06
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.service.impl;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import com.local.web.health.chat.ChatUser;
import com.local.web.health.service.BaiduBCSService;
import com.local.web.health.service.ChatUploadService;
import com.local.web.health.util.HealthContext;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class ChatUploadServiceImpl implements ChatUploadService {
    
    /**
     * 存储方式
     */
    public final static String SAVE_TYPE_NAME = "saveType";
    /**
     * 本地存储方式
     */
    public final static String SAVE_LOACL = "local";
    
    /**
     * 存储路径名称
     */
    public final static String LOCAL_PATH_NAME = "localSavePath";
    
    /**
     * 百度云存储服务方式
     */
    public final static String SAVE_BCS = "bcs";
    
    /**
     * 百度存储服务
     */
    @Autowired
    private BaiduBCSService baiduBCSService;
    
    /**
     * 上下文
     */
    @Resource
    private Map<String,String> context;
    
    /* (non-Javadoc)
     * @see com.local.web.health.service.ChatUploadService#upload(org.springframework.web.multipart.MultipartFile, java.lang.String)
     */
    @Override
    public String upload(MultipartFile myfile, String filename, HttpServletRequest request) throws IOException {
        
    	String encode_filename = URLEncoder.encode(filename,"utf-8");
    	String file_path = "";
        //本地
        if(SAVE_LOACL.equals(context.get(SAVE_TYPE_NAME))){
            String savePath = context.get(LOCAL_PATH_NAME);
            savePath = request.getSession().getServletContext().getRealPath(savePath);
            FileUtils.copyInputStreamToFile(myfile.getInputStream(), new File(savePath, filename));
            file_path = context.get("localPath") + encode_filename;
        }
        //云存储
        if(SAVE_BCS.equals(context.get(SAVE_TYPE_NAME))){
            String prefix = "";
            if(!filename.startsWith("/")){
                prefix = "/";
            }
            ChatUser fromuser = (ChatUser)request.getSession().getAttribute(HealthContext.CHAT_USER);
            if( fromuser != null ){
            	prefix += fromuser.getSessionid() + "/";
            }
            baiduBCSService.put(prefix + filename, myfile.getInputStream(), myfile.getContentType(), myfile.getSize());
            file_path = context.get("bcsPath") + prefix + encode_filename; 
        }
        return file_path;
    }

}
