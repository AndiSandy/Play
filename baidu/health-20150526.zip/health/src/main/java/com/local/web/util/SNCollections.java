/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: Collections.java
 * Author:   14041326
 * Date:     2014-6-16 下午8:43:19
 * Description: 集合工具类//模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.util;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 集合工具类<br> 
 *
 * @author 14041326
 */
@SuppressWarnings("rawtypes")
public class SNCollections {
    
    /**
     * 
     * 功能描述: 判断是否为null<br>
     *
     * @param o
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static boolean isNull(Object o){
        return o == null;
    }
    
    /**
     * 
     * 功能描述: 判断是否为空<br>
     * 〈功能详细描述〉
     *
     * @param collection
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static boolean isEmpty(Collection collection){
        return isNull(collection) || collection.isEmpty();
    }
    
    /**
     * 
     * 功能描述: 判断是否为空<br>
     * 〈功能详细描述〉
     *
     * @param m
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static boolean isEmpty(Map m){
    	return isNull(m) || m.isEmpty();
    }
    
    /**
     * 
     * 功能描述: 返回list中指定长度的部分，如果小于指定长度则直接返回目标list<br>
     *
     * @param ol    目标list
     * @param length 要返回的长度
     * @return
     */
    public static List show(List ol,int length){
        List sl = null;
        if(!isEmpty(ol)){
            sl = ol;
            if(ol.size() > length){
                sl = ol.subList(0, length);  
            }
        }else{
            sl = new ArrayList();
        }
        return sl;
    }
    
    /**
     * 
     * 功能描述: 如果对象o为空，则返回对象s<br>
     * 〈功能详细描述〉
     *
     * @param o
     * @param s
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static Object show(Object o,Object s){
        return isNull(o) ? s : o;
    }
    
    
    /**
     * 
     * 功能描述: 获取指定list<map>中的某个属性list<br>
     * 〈功能详细描述〉
     *
     * @param ol 目标列表
     * @param attributeName 属性名称
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static List<String> getAttributes(List<Map<String,Object>> ol,String attributeName){
        List<String> sl = new ArrayList<String>(10);
        if(!isEmpty(ol) && !SNStringUtils.isEmpty(attributeName)){
            for(int i = 0; i < ol.size(); i ++){
                Map obj = ol.get(i);
                if(!isNull(obj)){
                    sl.add(SNStringUtils.show(obj.get(attributeName)));
                }
            }
        }
        return sl;
    }
    
    /**
     * 
     * 功能描述: 获取object中的制定属性<br>
     * 〈功能详细描述〉
     *
     * @param ol
     * @param attributeName
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static List<String> getAttrList(List<Object> ol,String attributeName){
        List<String> sl = new ArrayList<String>(10);
        if(!isEmpty(ol) && !SNStringUtils.isEmpty(attributeName)){
            for(int i = 0; i < ol.size(); i ++){
                Map obj = transBean2Map(ol.get(i));
                if(!isNull(obj)){
                    sl.add(SNStringUtils.show(obj.get(attributeName)));
                }
            }
        }
        return sl;
    }
    
    
    /**
     * 
     * 功能描述: 将javabean转换为map<br>
     * 〈功能详细描述〉
     *
     * @param obj
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static Map<String,Object> transBean2Map(Object obj){
        if(obj == null){  
            return null;  
        }          
        Map<String, Object> map = new HashMap<String, Object>();  
        try {  
            BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());  
            PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();  
            for (PropertyDescriptor property : propertyDescriptors) {  
                String key = property.getName();  
                // 过滤class属性  
                if (!key.equals("class")) {  
                    // 得到property对应的getter方法  
                    Method getter = property.getReadMethod();  
                    Object value = getter.invoke(obj);  
                    map.put(key, value);  
                }  
            }  
        } catch (Exception e) {  
            System.out.println("transBean2Map Error " + e);  
        }  
        return map;  
    }
    
    /**
     * 
     * 功能描述: 将list列表转化为以list元素中指定属性值为key的map<br>
     * 〈功能详细描述〉
     *
     * @param ol    目标列表
     * @param keyName   属性值名称
     * @return  
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static Map<String,Map<String,Object>> transList2Map(List ol, String keyName){
        if(!isEmpty(ol) && ! SNStringUtils.isEmpty(keyName)){
            Map<String,Map<String,Object>> map = new HashMap<String,Map<String,Object>>();
            for(int i =0; i < ol.size(); i ++){
                Map<String,Object> smap = transBean2Map(ol.get(i));
                String key = SNStringUtils.show(smap.get(keyName));
                if(!SNStringUtils.isEmpty(key)){
                    map.put(key, smap);
                }
            }
            return map;
        }
        return null;
    }
    
}
