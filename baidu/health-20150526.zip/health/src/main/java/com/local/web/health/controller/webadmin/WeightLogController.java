/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: DashBoardController.java
 * Author:   Administrator
 * Date:     2014年8月24日 下午7:38:53
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.controller.webadmin;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.local.web.health.model.TimeElm;
import com.local.web.health.model.User;
import com.local.web.health.model.WeightLog;
import com.local.web.health.service.TimeElmService;
import com.local.web.health.service.UserService;
import com.local.web.health.service.WeightLogService;

/**
 * 后台管理页面<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/webadmin/weight")
public class WeightLogController {

	@Autowired
	private WeightLogService weightLogService;
	
	@Autowired
	private TimeElmService timeElmService;
	
	@Autowired
	private UserService userService;
	
	/**
	 * 
	 * 功能描述: 管理主页<br>
	 * 〈功能详细描述〉
	 *
	 * @param request
	 * @param response
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping(value = "weight-log-list")
	public String weightLogList(HttpServletRequest request,HttpServletResponse response){
		String page_ftl = "webadmin/weight-log-list.ftl";
		
		List<Map<String,Object>> logList = weightLogService.queryAll();
		
		//List<Map<String,Object>> loglist = weightLogService.queryByMap(new HashMap<String,Object>());
		
		List<TimeElm> times = timeElmService.queryAll();
		
		request.setAttribute("loglist", logList);
		request.setAttribute("times", times);
		return page_ftl;
	}
	
	
	@RequestMapping(value = "save")
    @ResponseBody
    public Map<String, Object> save(@RequestParam(value = "userName", required = true) String userName,
    		@RequestParam(value = "timeId", required = true) Integer timeId,
    		@RequestParam(value = "weight", required = true) Double weight,
            @RequestParam(value = "objid", required = true) Integer objid,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        
        WeightLog obj = new WeightLog(null, weight, timeId, null);
        
        List<User> users = userService.queryByName(userName);
        
        if(users.size() > 0){
        	User user = users.get(0);
        	obj.setUserId(user.getUserId());
        	if(objid != null){
                obj.setLogId(objid);
                weightLogService.updateByExample(obj);
            }else{
            	obj.setLogTime(new Date());
            	weightLogService.add(obj);
            }
            map.put("success", true);
            map.put("txt", "保存更新信息成功");
            map.put("obj", obj);
        }else{
        	map.put("success", false);
            map.put("txt", userName + "用户不存在");
        }
        return map;
    }
    
    @RequestMapping(value = "del")
    @ResponseBody
    public Map<String, Object> del(@RequestParam(value = "objid", required = true) Integer objid,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        WeightLog obj = new WeightLog();
        obj.setLogId(objid);
        weightLogService.delByExample(obj);
        map.put("success", true);
        map.put("txt", "删除信息成功");
        
        return map;
    }
    
    @RequestMapping(value = "query")
    @ResponseBody
    public Map<String, Object> query(@RequestParam(value = "objid", required = true) Integer objid,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        
        Map<String, Object> obj = new HashMap<String, Object>();
        obj.put("logId",objid);
        List<Map<String, Object>> objs = weightLogService.queryByMap(obj);
        if(objs.size() > 0){
            obj = objs.get(0);
            map.put("success", true);
            map.put("txt", "查询信息成功");
            map.put("obj", obj);
        }else{
            map.put("success", false);
            map.put("txt", "查询信息失败,记录不存在!");
        }
        
        return map;
    }
	
}
