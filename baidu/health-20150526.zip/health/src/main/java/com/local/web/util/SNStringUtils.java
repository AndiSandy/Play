/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: SNStringUtils.java
 * Author:   14041326
 * Date:     2014-6-16 下午7:36:31
 * Description: 字符串工具类//模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 字符串工具类<br> 
 *
 * @author 14041326
 */
public class SNStringUtils {
    
    /**
     * 
     * 功能描述: 判读是否为null<br>
     *
     * @param o
     * @return
     */
    public static boolean isNull(Object o){
        return o == null;
    }
    
    /**
     * 
     * 功能描述: 是否为空白字符串<br>
     * 〈功能详细描述〉
     *
     * @param o
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static boolean isEmpty(Object o){
        return isNull(o) || o.toString().trim().equals("");
    }
    
    /**
     * 
     * 功能描述: 如果指定对象为空则放回替代的字符串<br>
     * 〈功能详细描述〉
     *
     * @param o 需要判断字符串
     * @param ifEmpty 替代字符串
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static String show(String o , String ifEmpty){
        return isEmpty(o) ? ifEmpty : o ;
    }
    
    /**
     * 
     * 功能描述: 如果指定字符串为null,则返回空字符串<br>
     *
     * @param os
     * @return
     */
    public static String show(String os){
        return show(os,"");
    }
    
    /**
     * 
     * 功能描述: 如果指定对象为null,则返回空字符串<br>
     *
     * @param os
     * @return
     */
    public static String show(Object os){
        return show(os,"");
    }
    
    /**
     * 
     * 功能描述: 如果指定对象为空则放回替代的字符串<br>
     * 〈功能详细描述〉
     *
     * @param o 需要判断字符串
     * @param ifEmpty 替代字符串
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static String show(Object o , String ifEmpty){
        return isEmpty(o) ? ifEmpty : o.toString() ;
    }
    
    /**
     * 
     * 功能描述: 如果指定字符串为不合法的整数，则返回替代的整数值<br>
     * 〈功能详细描述〉
     *
     * @param os
     * @param defaultInt
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static int getInt(String os,int defaultInt){
        int intValue = defaultInt;
        try{
            if(!isEmpty(os)){
                intValue = Integer.valueOf(os);
            }
        }catch(Exception e){
        }
        return intValue;
    }
    
    /**
     * 
     * 功能描述: 转换为日期<br>
     * 〈功能详细描述〉
     *
     * @param sdate
     * @param format yyyy-MM-dd hh:mm:ss 2015-01-17 00:32:23
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static Date parseDate(String sdate,String format){
    	SimpleDateFormat df = new SimpleDateFormat(format);
    	Date date = null;
    	try {
    		date = df.parse(sdate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			date = new Date();
		}
    	return date;
    }
    public static String formatDate(Date date,String format){
    	String sdata = null;
    	SimpleDateFormat df = new SimpleDateFormat(format);
    	if( date != null){
    		sdata = df.format(date);
    	}
    	return sdata;
    }
    public static String formatDate(Long time,String format){
    	String sdata = null;
    	SimpleDateFormat df = new SimpleDateFormat(format);
    	if( time != null){
    		Date date = new Date(time);
    		sdata = df.format(date);
    	}
    	return sdata;
    }
    
    /**
     * 
     * 功能描述: 日期转换<br>
     * 〈功能详细描述〉
     *
     * @param sdate
     * @param format
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static Date parseDate(Object sdate,String format){
    	return parseDate(show(sdate),format);
    }
    
    /**
     * 获取文件名扩展名称
     * 功能描述: <br>
     * 〈功能详细描述〉
     *
     * @param filename
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static String getFileExt(String filename){
    	if(!isEmpty(filename)){
    		int at = filename.lastIndexOf(".");
    		return filename.substring(at+1, filename.length());
    	}
    	return null;
    }
    
    /**
     * 
     * 功能描述: 编码<br>
     * 〈功能详细描述〉
     *
     * @param s
     * @param dcode 解码类型
     * @param ecode 编码类型
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static String encode(String s, String dcode, String ecode){
    	String os = "";
    	try {
    		os = new String(s.getBytes(dcode),ecode);
		} catch (Exception e) {
			System.out.println(dcode+"-decode-encode-"+ecode+" error");
		}
    	return os;
    }
    
}
