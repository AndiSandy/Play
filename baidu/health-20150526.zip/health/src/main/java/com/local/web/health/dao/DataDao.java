/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: DataDao.java
 * Author:   Administrator
 * Date:     2015年2月11日 下午9:40:25
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.dao;

import java.util.List;
import java.util.Map;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public interface DataDao {
    
    /**
     * 查询数据
     * 功能描述: <br>
     * 〈功能详细描述〉
     *
     * @param queryData
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public List<Map<String,Object>> query(Map<String,Object> queryData);
    
    /**
     * 
     * 功能描述: 查询总量<br>
     * 〈功能详细描述〉
     *
     * @param jsondata
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public int queryTotal(Map<String,Object> jsondata);
    
    /**
     * 
     * 功能描述: 更新数据<br>
     * 〈功能详细描述〉
     *
     * @param queryData{table,sets,condition}
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public boolean update(Map<String,Object> queryData);
    
    /**
     * 
     * 功能描述: 添加记录<br>
     * 〈功能详细描述〉
     *
     * @param queryData{table,id,fields,values}
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public boolean add(Map<String,Object> queryData);
    
    
    /**
     * 
     * 功能描述: 批量添加记录<br>
     * 〈功能详细描述〉
     *
     * @param queryData
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public boolean addBatch(Map<String,Object> queryData);
    
    /**
     * 
     * 功能描述: 删除记录<br>
     * 〈功能详细描述〉
     *
     * @param queryData{table,condition}
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public boolean del(Map<String,Object> queryData);
    
    
    
    
}
