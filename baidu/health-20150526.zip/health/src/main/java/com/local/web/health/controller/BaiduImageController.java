/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: BaiduImageController.java
 * Author:   Administrator
 * Date:     2014年8月30日 上午11:32:59
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.controller;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.local.web.health.service.BaiduImageService;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/baidu/image")
public class BaiduImageController {
	
	@Autowired
	private BaiduImageService baiduImageService;
	
	@RequestMapping(value = "qrcode")
    public void qrcode(@RequestParam(value = "text", required = true) String text,
            @RequestParam(value = "size", required = true) int size,
            HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException{
		String decode = "utf-8";
		String etext = URLDecoder.decode(text, decode);
		byte[] bs = baiduImageService.getQRCodeImage(etext, size, "AABBCC");
		BufferedOutputStream bos = null;
		try{
			/****4. 获取返回结果****/
			response.setContentType("image/jpg");
			bos = new BufferedOutputStream(response.getOutputStream());
			bos.write(bs, 0, bs.length);
			if (bos != null)
				bos.close();
			bos.flush();
		}catch(Exception e){
			e.printStackTrace();
			if (bos != null)
				try {
					bos.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		}
	}
}
