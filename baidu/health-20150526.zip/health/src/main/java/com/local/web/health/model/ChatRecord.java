package com.local.web.health.model;

import java.util.Date;

/**
 * 
 * 〈一句话功能简述〉聊天记录消息模型<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class ChatRecord {
	
	/**
	 * 记录id
	 */
	private int rid;
	
	/**
	 * 聊天内容
	 */
	private String msg;
	
	/**
	 * 消息出处
	 */
	private String from;
	
	/**
	 * 消息发出者昵称
	 */
	private String from_nickname;
	
	
	/**
	 * 消息发送到
	 */
	private String to;
	
	/**
	 * 消息接收者昵称
	 */
	private String to_nickname;
	
	/**
	 * 发送日期
	 */
	private Date date;

	/**
	 * @return the rid
	 */
	public int getRid() {
		return rid;
	}

	/**
	 * @param rid the rid to set
	 */
	public void setRid(int rid) {
		this.rid = rid;
	}

	/**
	 * @return the msg
	 */
	public String getMsg() {
		return msg;
	}

	/**
	 * @param msg the msg to set
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}

	/**
	 * @return the from
	 */
	public String getFrom() {
		return from;
	}

	/**
	 * @param from the from to set
	 */
	public void setFrom(String from) {
		this.from = from;
	}

	/**
	 * @return the to
	 */
	public String getTo() {
		return to;
	}

	/**
	 * @param to the to to set
	 */
	public void setTo(String to) {
		this.to = to;
	}

	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * @return the from_nickname
	 */
	public String getFrom_nickname() {
		return from_nickname;
	}

	/**
	 * @param from_nickname the from_nickname to set
	 */
	public void setFrom_nickname(String from_nickname) {
		this.from_nickname = from_nickname;
	}

	/**
	 * @return the to_nickname
	 */
	public String getTo_nickname() {
		return to_nickname;
	}

	/**
	 * @param to_nickname the to_nickname to set
	 */
	public void setTo_nickname(String to_nickname) {
		this.to_nickname = to_nickname;
	}
	
	
	
}
