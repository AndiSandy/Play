/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: DashBoardController.java
 * Author:   Administrator
 * Date:     2014年8月24日 下午7:38:53
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.controller.webadmin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.local.web.health.model.TimeElm;
import com.local.web.health.service.TimeElmService;

/**
 * 后台管理页面<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/webadmin")
public class TimeElmController {

	@Autowired
	private TimeElmService timeElmService;
	
	/**
	 * 
	 * 功能描述: 管理主页<br>
	 * 〈功能详细描述〉
	 *
	 * @param request
	 * @param response
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping(value = "time-elm-list")
	public String timeElmList(HttpServletRequest request,HttpServletResponse response){
		String page_ftl = "webadmin/time-elm-list.ftl";
		List<TimeElm> timeElmList = timeElmService.queryAll();
		request.setAttribute("timelist", timeElmList);
		return page_ftl;
	}
	
	@RequestMapping(value = "time-elm/save")
	@ResponseBody
    public Map<String, Object> save(@RequestParam(value = "timeName", required = true) String timeName,
            @RequestParam(value = "objid", required = false) Integer objid,
            @RequestParam(value = "order", required = false) Integer order,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        
        TimeElm time = new TimeElm(timeName);
        
        if(objid != null){
            time.setTimeId(objid);
            time.setOrder(order);
            timeElmService.updateByExample(time);
        }else{
        	time.setOrder(timeElmService.getNextOrder());
            timeElmService.add(time);
        }
        
        map.put("success", true);
        map.put("txt", "保存信息成功");
        map.put("time", time);
        
        return map;
    }
	
	@RequestMapping(value = "time-elm/del")
    @ResponseBody
    public Map<String, Object> del(@RequestParam(value = "objid", required = true) Integer objid,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        
        TimeElm time = new TimeElm();
        time.setTimeId(objid);
        timeElmService.delByExample(time);
        
        map.put("success", true);
        map.put("txt", "删除信息成功");
        
        return map;
    }
	
	@RequestMapping(value = "time-elm/query")
    @ResponseBody
    public Map<String, Object> query(@RequestParam(value = "objid", required = true) Integer objid,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        
        TimeElm time = new TimeElm();
        time.setTimeId(objid);
        List<TimeElm> times = timeElmService.queryByExample(time);
        if(times.size() > 0){
            time = times.get(0);
            map.put("success", true);
            map.put("txt", "查询信息成功");
            map.put("obj", time);
        }else{
            map.put("success", false);
            map.put("txt", "查询信息失败,记录不存在!");
        }
        
        return map;
    }
	
	@RequestMapping(value = "time-elm/update_order")
    @ResponseBody
    public Map<String, Object> update_order(@RequestParam(value = "objid1", required = true) Integer objid1,
    		@RequestParam(value = "objid2", required = true) Integer objid2,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        
        TimeElm time1 = timeElmService.queryById(objid1);
        TimeElm time2 = timeElmService.queryById(objid2);
        
        if(time1 != null && time2 != null){
        	
        	Integer tmpid = time1.getOrderno();
        	time1.setOrder(time2.getOrderno());
        	time2.setOrder(tmpid);
        	timeElmService.updateByExample(time1);
        	timeElmService.updateByExample(time2);
        	
            map.put("success", true);
            map.put("txt", "更新信息成功");
        }else{
            map.put("success", false);
            map.put("txt", "更新信息失败,记录不存在!");
        }
        
        return map;
    }
	
}
