/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: ChatController.java
 * Author:   14041326
 * Date:     2014年8月21日 上午10:16:39
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.local.web.health.chat.ChatUser;
import com.local.web.health.chat.MsgBox;
import com.local.web.health.chat.MsgUtils;
import com.local.web.health.service.ChatRecordService;
import com.local.web.health.service.ChatUploadService;
import com.local.web.health.util.HealthContext;
import com.local.web.util.SNStringUtils;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/chat/")
public class ChatController {
    
    /**
     * 聊天文件上传服务
     */
    @Autowired
    private ChatUploadService chatUploadService;
    
    /**
     * 聊天记录服务
     */
    @Autowired
    private ChatRecordService chatRecordService;
    
    @RequestMapping(value = "send")
    @ResponseBody
    public Map<String,Object> send(@RequestParam(value = "msg", required = true) String msg,
            @RequestParam(value = "to", required = true) String to,
            @RequestParam(value = "sessionid", required = true) String sessionid,
            @RequestParam(value = "date", required = false) String date,
            HttpServletRequest request,HttpServletResponse response){
        
        
        //String username = (String)request.getSession().getAttribute("username");
        ChatUser touser = new ChatUser(sessionid,null,to);
        ChatUser fromuser = (ChatUser)request.getSession().getAttribute(HealthContext.CHAT_USER);
        
        Map<String,Object> msgInfo = new HashMap<String,Object>();
        msgInfo.put("msg", msg);
        msgInfo.put("from", fromuser);
        msgInfo.put("date", date);
        msgInfo.put("to", touser);
        MsgUtils.getMsgBox(request).sendMsg(touser, msgInfo);
        
        Map<String,Object> map = new HashMap<String,Object>();  
        map.put("success", true);
        map.put("txt", "发送成功");
        return map;
    }
    
    @RequestMapping(value = "receive")
    @ResponseBody
    public Map<String,Object> receive(HttpServletRequest request,HttpServletResponse response){
        
        String username = (String)request.getSession().getAttribute("username");
        ChatUser user = (ChatUser)request.getSession().getAttribute(HealthContext.CHAT_USER);
        
        //获取指定人的消息
        MsgBox msgBox = MsgUtils.getMsgBox(request);
        
        List<Map<String,Object>> msgs = null;
        if(user != null){
            msgs = msgBox.receiveMsg(user);
        }else{
            msgs = msgBox.receiveMsg(username);
        }
        
        
        //在线用户
        List<Object> onlineusers = msgBox.getOnlineUsers();
        
        //接收个人消息
        Map<String,Object> map = new HashMap<String,Object>();  
        map.put("success", true);
        map.put("txt", username+"接收成功");
        map.put("msgs", msgs);
        map.put("onlineusers", onlineusers);
        
        //接收聊天室消息
        Map<String,Object> chat_room = new HashMap<String,Object>();
        Integer index = SNStringUtils.getInt(request.getParameter("index"), 0);
        List<Map<String,Object>> room_msgs = msgBox.receiveChatRoomMsg();
        int nindex = room_msgs.size();
        if(index < 0){
            index = 0;
        }
        if(index > room_msgs.size()){
            index = nindex;
        }
        int msg_length = SNStringUtils.getInt(request.getParameter("msg_length"), 50);
        if(nindex - index > msg_length){
            index = nindex - msg_length;
        }
        chat_room.put("msgs", room_msgs.subList(index, room_msgs.size()));
        chat_room.put("index", nindex);
        
        map.put("chat_room", chat_room);
        
        MsgUtils.live(request);
        return map;
    }
    
    /**
     * 
     * 功能描述: 图片上传<br>
     * 〈功能详细描述〉
     *
     * @param request
     * @param response
     * @return
     * @throws IOException 
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping(value = "upload-img")
    @ResponseBody
    public Map<String,Object> upload(HttpServletRequest request,HttpServletResponse response) throws IOException{
        Map<String,Object> map = new HashMap<String,Object>();
        
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        MultipartFile myfile = multipartRequest.getFile("file");
        if(myfile.isEmpty()){  
            System.out.println("文件未上传");
            map.put("msg","文件未上传");
        }else{
        	UUID uuid = UUID.randomUUID();
        	String filename = myfile.getOriginalFilename();
        	String ext = SNStringUtils.getFileExt(filename);
        	filename = uuid + "." + ext;
            String imgUrl = chatUploadService.upload(myfile, filename, request);
            map.put("imgUrl",imgUrl);
        }  
        return map;
    }
    
    /**
     * 
     * 功能描述: 开启聊天记录功能<br>
     * 〈功能详细描述〉
     *
     * @param request
     * @param response
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping(value = "enable-records")
    @ResponseBody
    public Map<String,Object> enable(@RequestParam boolean enable, HttpServletRequest request,HttpServletResponse response){
        Map<String,Object> map = new HashMap<String,Object>();
        request.getSession().setAttribute(HealthContext.CHAT_ENABLE_RECORDS, enable);
        MsgBox msgBox = MsgUtils.getMsgBox(request);
        ChatUser fromuser = (ChatUser)request.getSession().getAttribute(HealthContext.CHAT_USER);
        if(enable){
            if(!msgBox.getRecordList().contains(fromuser.getSessionid())){
                msgBox.getRecordList().add(fromuser.getSessionid());
            }
        }else{
            if(msgBox.getRecordList().contains(fromuser.getSessionid())){
                msgBox.getRecordList().remove(fromuser.getSessionid());
            }
        }
        map.put("msg", "设置聊天记录功能成功 enable:"+enable);
        return map;
    }
    
    /**
     * 
     * 功能描述: 加载聊天记录<br>
     * 〈功能详细描述〉
     *
     * @param request
     * @param response
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping(value = "load-records")
    @ResponseBody
    public Map<String,Object> load(@RequestParam int start,@RequestParam int size,HttpServletRequest request,HttpServletResponse response){
        Map<String,Object> map = new HashMap<String,Object>();
        ChatUser fromuser = (ChatUser)request.getSession().getAttribute(HealthContext.CHAT_USER);
        if( fromuser != null){
        	Map<String,Object> query = new HashMap<String,Object>();
            query.put("from", fromuser.getSessionid());
            query.put("to", fromuser.getSessionid());
            query.put("start", start);
            query.put("size", size);
            List<Map<String,Object>> msgs = chatRecordService.query(query);
            map.put("msgs", msgs);
        }
        return map;
    }
    
}
