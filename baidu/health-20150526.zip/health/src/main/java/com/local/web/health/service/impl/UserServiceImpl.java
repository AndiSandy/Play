/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: UserServiceImpl.java
 * Author:   14041326
 * Date:     2014年7月10日 上午11:55:27
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.local.web.health.dao.UserDao;
import com.local.web.health.model.User;
import com.local.web.health.service.UserService;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Service
public class UserServiceImpl implements UserService {
    
    @Autowired
    private UserDao userDao;
    
    /* (non-Javadoc)
     * @see com.local.web.health.service.UserService#queryAllUser()
     */
    public List<User> queryAll() {
        // TODO Auto-generated method stub
        return userDao.queryAll();
    }
    
    public List<User> queryByName(String username){
        return userDao.queryByName(username);
    }

    @Override
    public int add(User user) {
        // TODO Auto-generated method stub
        return userDao.add(user);
    }

    @Override
    public void delByUserName(String username) {
        // TODO Auto-generated method stub
        userDao.delByUserName(username);
    }
    public void updateByUserName(User user){
        userDao.updateByUserName(user);
    }

	@Override
	public List<User> queryByExample(User user) {
		return userDao.queryByExample(user);
		
	}

	@Override
	public void updateByExample(User user) {
		userDao.updateByExample(user);
	}

	@Override
	public void delByExample(User user) {
		userDao.delByExample(user);
	}
}
