/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: MsgBox.java
 * Author:   14041326
 * Date:     2014年8月21日 下午12:42:49
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.chat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.local.web.health.chat.event.Event;
import com.local.web.health.chat.event.EventDelegate;
import com.local.web.health.service.ChatRecordListenerService;

/**
 * 消息盒子<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class MsgBox extends EventDelegate<Event>{
    
    
    public static String CHAT_ROOM_ID = "chat_room_simple_spring_mvc_mybatis";
    private static String CHAT_ROOM_NAME = "chat_room";
    public static Integer MAX_MSG_LENGTH_CHAT_ROOM = 500;
    public static ChatUser CHAT_ROOM = new ChatUser(CHAT_ROOM_ID,null,CHAT_ROOM_NAME);
    
    public MsgBox() {
        // TODO Auto-generated constructor stub
    }
    
    /**
     * 聊天记录服务-监听发送的信息
     * @param chatRecordService
     */
    public MsgBox(ChatRecordListenerService chatRecordListenerService) {
        chatRecordListenerService.listenerSendMsg(this);
    }
    
    /**
     * 聊天记录人员名单
     */
    private  List<String> recordList = new ArrayList<String>();
    
    private Map<Object,List<Map<String,Object>>> msgBox = new HashMap<Object,List<Map<String,Object>>>();
    
    private List<Object> onlineUsers = new ArrayList<Object>();
    
    /**
     * 
     * 功能描述: 把消息放入消息盒子里面<br>
     * 〈功能详细描述〉
     *
     * @param to
     * @param msg
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public void sendMsg(Object to,Map<String,Object> msg){
        defineEvent(Event.BeforeSend, new Object[]{this, to,msg});
        //获取指定人的消息
        List<Map<String,Object>> msgs = getMsg(to);
        msgs.add(msg);
        if(CHAT_ROOM_NAME.equals(to)){
            to = CHAT_ROOM;
        }
        msgBox.put(to, msgs);
        defineEvent(Event.AfterSend, new Object[]{this, to,msg});
    }
    
    /**
     * 
     * 功能描述: 从消息盒子里面获取消息<br>
     * 〈功能详细描述〉
     *
     * @param from
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public List<Map<String,Object>> getMsg(Object from){
        //获取指定人的消息
        List<Map<String,Object>> msgs = (List<Map<String,Object>>)msgBox.get(from);
        if(msgs == null){
            msgs = new ArrayList<Map<String,Object>>();
            msgBox.put(from,msgs);
        }
        return msgs;
    }
    
    public List<Map<String,Object>> receiveMsg(Object from){
        defineEvent(Event.BeforeReceive, new Object[]{this,from});
        //获取指定人的消息
        List<Map<String,Object>> msgs = (List<Map<String,Object>>)msgBox.get(from);
        if(msgs == null){
            msgs = new ArrayList<Map<String,Object>>();
        }
        clearMsg(from);
        defineEvent(Event.AfterReceive, new Object[]{this,from,msgs});
        return msgs;
    }
    
    public List<Map<String,Object>> receiveChatRoomMsg(){
        defineEvent(Event.BeforeReceive, new Object[]{this, CHAT_ROOM});
        //获取指定人的消息
        List<Map<String,Object>> msgs = (List<Map<String,Object>>)msgBox.get(CHAT_ROOM);
        if(msgs == null){
            msgs = new ArrayList<Map<String,Object>>();
        }
        int msg_length = msgs.size(); 
        if( msg_length >= MAX_MSG_LENGTH_CHAT_ROOM){
            try {
                msgs = msgs.subList(msg_length - MAX_MSG_LENGTH_CHAT_ROOM, msg_length);
                msgBox.put(CHAT_ROOM, msgs);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //clearMsg(from);
        defineEvent(Event.AfterReceive, new Object[]{this,CHAT_ROOM,msgs});
        return msgs;
    }
    
    
    /**
     * 
     * 功能描述:清除消息 <br>
     * 〈功能详细描述〉
     *
     * @param from
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public void clearMsg(Object from){
        msgBox.put(from,null);
    }
    /**
     * 
     * 功能描述: 移除消息<br>
     * 〈功能详细描述〉
     *
     * @param from
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public void removeMsg(Object from){
        msgBox.remove(from);
    }
    
    public void offline(Object username){
        onlineUsers.remove(username);
    }
    
    public void online(Object username){
        int at = onlineUsers.indexOf(username);
        if(at < 0){
            onlineUsers.add(username);
        }
    }

    /**
     * @return the onlineUsers
     */
    public List<Object> getOnlineUsers() {
        return onlineUsers;
    }

    /**
     * @return the recordList
     */
    public List<String> getRecordList() {
        return recordList;
    }

    /**
     * @param recordList the recordList to set
     */
    public void setRecordList(List<String> recordList) {
        this.recordList = recordList;
    }
    
    
    
}
