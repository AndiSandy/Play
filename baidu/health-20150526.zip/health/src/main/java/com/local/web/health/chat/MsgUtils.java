/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: MsgUtils.java
 * Author:   14041326
 * Date:     2014年8月21日 下午12:43:42
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.chat;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.local.web.health.service.ChatRecordListenerService;
import com.local.web.health.util.HealthContext;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class MsgUtils {
    
    /**
     * 
     * 功能描述: 从web上下文中获取消息盒子<br>
     * 〈功能详细描述〉
     *
     * @param request
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static MsgBox getMsgBox(HttpServletRequest request){
        MsgBox msgBox = (MsgBox)request.getSession().getServletContext().getAttribute("msgBox");
        if(msgBox == null){
        	WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(request.getServletContext());
        	ChatRecordListenerService chatRecordListenerService = (ChatRecordListenerService)ctx.getBean("chatRecordListenerServiceImpl");
            msgBox = new MsgBox(chatRecordListenerService);
            putMsgBox(request,msgBox);
        }
        return msgBox;
    }
    public static MsgBox getMsgBox(HttpSession session){
        MsgBox msgBox = (MsgBox)session.getServletContext().getAttribute("msgBox");
        if(msgBox == null){
        	WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(session.getServletContext());
        	ChatRecordListenerService chatRecordListenerService = (ChatRecordListenerService)ctx.getBean("chatRecordListenerServiceImpl");
            msgBox = new MsgBox(chatRecordListenerService);
            putMsgBox(session,msgBox);
        }
        return msgBox;
    }
    
    /**
     * 
     * 功能描述: 把消息盒子放入web上下文中<br>
     * 〈功能详细描述〉
     *
     * @param request
     * @param msgBox
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static void putMsgBox(HttpServletRequest request, MsgBox msgBox){
        request.getSession().getServletContext().setAttribute("msgBox",msgBox);
    }
    
    public static void putMsgBox(HttpSession session, MsgBox msgBox){
    	session.getServletContext().setAttribute("msgBox",msgBox);
    }
    
    /**
     * 
     * 功能描述: 维持在线状态<br>
     * 〈功能详细描述〉
     *
     * @param request
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public static void live(HttpServletRequest request){
        new MsgUtils.OnlineCheck(request.getSession(),2*1000).start();
    }
    
    /**
     * 
     * 在线检测功能<br> 
     * 〈功能详细描述〉
     *
     * @author Administrator
     * @see [相关类/方法]（可选）
     * @since [产品/模块版本] （可选）
     */
    public static class OnlineCheck extends Thread{
    	private HttpSession session;
    	HttpServletRequest request;
    	private int sleep_time = 1100;
    	String LIVE_ONLINE = "liveonline";
        String LIVE_TIME = "livetime";
    	public OnlineCheck(HttpSession session,int sleep_time) {
			this.session = session;
			this.sleep_time = sleep_time;
		}
    	public OnlineCheck(HttpServletRequest request,int sleep_time) {
			this.session = request.getSession();
			this.request = request;
			this.sleep_time = sleep_time;
		}
    	@Override
    	public void run() {
    		boolean online = true;
            boolean live_online = online;
            long live_time = new Date().getTime();

            session.setAttribute(LIVE_ONLINE,live_online);
            session.setAttribute(LIVE_TIME,live_time);
        	try {
				Thread.sleep(sleep_time);
				boolean next_live_online = false;
				if(session.getAttribute(LIVE_ONLINE) != null){
					next_live_online = (Boolean)session.getAttribute(LIVE_ONLINE);
				}
				long next_live_time = -1;
				if(session.getAttribute(LIVE_TIME) != null){
					next_live_time = (Long)session.getAttribute(LIVE_TIME);
				}
				if(next_live_online == false || next_live_time == live_time){
					//offline
					//System.out.println("offline...");
					session.setAttribute(LIVE_ONLINE,!online);
					String username = (String)session.getAttribute("username");
					ChatUser user = (ChatUser)session.getAttribute(HealthContext.CHAT_USER);
					if(user != null){
					    MsgUtils.getMsgBox(session).offline(user);
					}else{
					    MsgUtils.getMsgBox(session).offline(username);
					}
				}else{
					//online
					System.out.println("online...");
				}
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    }
    
}
