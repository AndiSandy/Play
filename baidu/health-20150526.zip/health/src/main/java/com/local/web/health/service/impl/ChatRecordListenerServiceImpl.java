/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: ChatRecordServiceImpl.java
 * Author:   14041326
 * Date:     2015年1月16日 下午5:45:58
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.service.impl;

import javax.annotation.Resource;

import com.local.web.health.chat.MsgBox;
import com.local.web.health.chat.event.Event;
import com.local.web.health.chat.event.IEventHandler;
import com.local.web.health.service.ChatRecordListenerService;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class ChatRecordListenerServiceImpl implements ChatRecordListenerService {
    
    @Resource
    IEventHandler sendMsgHandler;
    
    /* (non-Javadoc)
     * @see com.local.web.health.service.ChatRecordService#listenerSendMsg(com.local.web.health.chat.MsgBox)
     */
    @Override
    public void listenerSendMsg(MsgBox msgBox) {
        // 绑定发送事件
        msgBox.on(Event.AfterSend, sendMsgHandler);
    }
    
    
    
}
