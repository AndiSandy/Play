package com.local.web.health.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

import com.baidu.inf.iis.bcs.BaiduBCS;
import com.baidu.inf.iis.bcs.model.ObjectListing;
import com.baidu.inf.iis.bcs.model.ObjectMetadata;
import com.baidu.inf.iis.bcs.model.ObjectSummary;
import com.baidu.inf.iis.bcs.model.X_BS_ACL;
import com.baidu.inf.iis.bcs.request.ListObjectRequest;
import com.baidu.inf.iis.bcs.request.PutObjectRequest;
import com.baidu.inf.iis.bcs.response.BaiduBCSResponse;
import com.local.web.health.service.BaiduBCSService;


public class BaiduBCSServiceImpl implements BaiduBCSService {
	
	/**
	 * 访问权限-公共可读
	 */
	private X_BS_ACL acl = X_BS_ACL.PublicRead;
	
	/**
	 * 百度存储服务
	 */
	private BaiduBCS baiduBCS;
	
	/**
	 * 根目录
	 */
	private String bucket;
	
	private String bcsHost;
	
	
	@Override
	public List<ObjectSummary> list(int start, int pagesize, String prefix) {
		ListObjectRequest listObjectRequest = new ListObjectRequest(bucket);
		listObjectRequest.setStart(start);
		listObjectRequest.setLimit(pagesize);
		listObjectRequest.setPrefix(prefix);
		BaiduBCSResponse<ObjectListing> response = baiduBCS.listObject(listObjectRequest);
		List<ObjectSummary> oss = response.getResult().getObjectSummaries();
		return oss;
	}
	
	@Override
	public ObjectMetadata put(String filename, InputStream is, String mime,long length) {
		ObjectMetadata objectMetadata = new ObjectMetadata();
		objectMetadata.setContentType(mime);
		objectMetadata.setContentLength(length);
		PutObjectRequest request = new PutObjectRequest(bucket, filename, is, objectMetadata);
		ObjectMetadata result = baiduBCS.putObject(request).getResult();
		baiduBCS.putObjectPolicy(bucket, filename, acl);
		return result;
	}

	@Override
	public ObjectMetadata put(String filename, File file, String mime) throws FileNotFoundException {
		InputStream  is = new FileInputStream(file);
		return put(filename, is, mime, file.length());
	}
	
	@Override
    public String get(String filename) {
        return bcsHost + bucket + filename;
    }

	/**
	 * @return the baiduBCS
	 */
	public BaiduBCS getBaiduBCS() {
		return baiduBCS;
	}

	/**
	 * @param baiduBCS the baiduBCS to set
	 */
	public void setBaiduBCS(BaiduBCS baiduBCS) {
		this.baiduBCS = baiduBCS;
	}

	/**
	 * @return the bucket
	 */
	public String getBucket() {
		return bucket;
	}

	/**
	 * @param bucket the bucket to set
	 */
	public void setBucket(String bucket) {
		this.bucket = bucket;
	}

	/**
	 * @return the acl
	 */
	public X_BS_ACL getAcl() {
		return acl;
	}

	/**
	 * @param acl the acl to set
	 */
	public void setAcl(X_BS_ACL acl) {
		this.acl = acl;
	}

    /**
     * @return the bcsHost
     */
    public String getBcsHost() {
        return bcsHost;
    }

    /**
     * @param bcsHost the bcsHost to set
     */
    public void setBcsHost(String bcsHost) {
        this.bcsHost = bcsHost;
    }

	
	

}
