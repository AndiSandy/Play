/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: WeightLog.java
 * Author:   14041326
 * Date:     2014年8月28日 上午9:18:27
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.model;

import java.util.Date;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class WeightLog {
    
    private Integer logId;
    private Integer userId;
    private Double weight;
    private Integer timeId;
    private Date logTime;
    
    public WeightLog() {
        // TODO Auto-generated constructor stub
    }
    
    public WeightLog(Integer userId,Double weight,Integer timeId,Date logTime) {
        this.userId = userId;
        this.weight = weight;
        this.timeId = timeId;
        this.logTime = logTime;
    }

    /**
     * @return the logId
     */
    public Integer getLogId() {
        return logId;
    }

    /**
     * @param logId the logId to set
     */
    public void setLogId(Integer logId) {
        this.logId = logId;
    }

    /**
     * @return the userId
     */
    public Integer getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    /**
     * @return the weight
     */
    public Double getWeight() {
        return weight;
    }

    /**
     * @param weight the weight to set
     */
    public void setWeight(Double weight) {
        this.weight = weight;
    }

    /**
     * @return the timeId
     */
    public Integer getTimeId() {
        return timeId;
    }

    /**
     * @param timeId the timeId to set
     */
    public void setTimeId(Integer timeId) {
        this.timeId = timeId;
    }

    /**
     * @return the logTime
     */
    public Date getLogTime() {
        return logTime;
    }

    /**
     * @param logTime the logTime to set
     */
    public void setLogTime(Date logTime) {
        this.logTime = logTime;
    }
    
    
}
