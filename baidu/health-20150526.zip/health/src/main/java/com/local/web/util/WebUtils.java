package com.local.web.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class WebUtils {
	
	/**
	 * 
	 * 功能描述: 获取cookie<br>
	 * 〈功能详细描述〉
	 *
	 * @param request
	 * @param name
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static String getCookie(HttpServletRequest request,String name){
		Cookie[] cookies = request.getCookies();
		for(int i = 0; i < cookies.length; i ++){
			Cookie cookie = cookies[i];
			if(name.equals(cookie.getName())){
				return cookie.getValue();
			}
		}
		return null;
	}
	
	/**
	 * 
	 * 功能描述: 生产聊天sessionid<br>
	 * 〈功能详细描述〉
	 *
	 * @param request
	 * @param response
	 * @param name
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static String makeSession(HttpServletRequest request,HttpServletResponse response,String name){
	    
	    String CHAT_JSESSIONID = getCookie(request,name);
	    //String sv = getCookie(request,HealthContext.CHAT_VERSION_NAME);
	    //boolean right = true;//HealthContext.CHAT_VERSION.equals(sv);
	    HttpSession session = request.getSession();
	    
	    //设置聊天的sessionid
	    if(CHAT_JSESSIONID == null){
	        String sessionid = (String)session.getId();
	        Cookie cookie = new Cookie(name,sessionid);
	        cookie.setHttpOnly(true);
	        int age = 60*60*24*365;
	        cookie.setMaxAge(age);
	        cookie.setPath("/");
	        response.addCookie(cookie);
	        CHAT_JSESSIONID = sessionid;
	        
	        //版本
	        /*Cookie cookie_vrsion = new Cookie(HealthContext.CHAT_VERSION_NAME,HealthContext.CHAT_VERSION);
	        cookie_vrsion.setHttpOnly(true);
	        cookie_vrsion.setMaxAge(age);
	        cookie_vrsion.setPath("/");
            response.addCookie(cookie_vrsion);
            */
	        //response.setHeader("SET-COOKIE", chat_session_name+"=" + sessionid + "");
	    }
	    return CHAT_JSESSIONID;
	}
	
}
