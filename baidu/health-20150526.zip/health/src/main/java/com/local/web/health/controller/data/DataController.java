/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: DataImportController.java
 * Author:   14041326
 * Date:     2015年2月11日 下午7:01:02
 * Description: 数据导入//模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.controller.data;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.local.web.health.converter.MapEditor;
import com.local.web.health.service.DataService;
import com.local.web.health.util.JsonpCallback;
import com.local.web.util.DataUtil;
import com.local.web.util.SNStringUtils;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/data/")
public class DataController {
    
	@Autowired
	DataService dataService;
    
	@InitBinder    
	protected void initBinder(WebDataBinder binder) { 
		 binder.registerCustomEditor(Map.class, new MapEditor("ISO-8859-1"));
	}
	/**
	 * 
	 * 功能描述: 数据导入-jsonp接口<br>
	 * 〈功能详细描述〉
	 *
	 * @param jsondata{callback,data,mapper,id,table}
	 * @param request
	 * @param response
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
    @RequestMapping(value = "import",produces = {"application/json;charset=UTF-8"})
    @ResponseBody
    public String importData(@RequestParam("jsondata") Map<String,Object> jsondata, HttpServletRequest request,HttpServletResponse response){
        Map<String,Object> rs = new HashMap<String,Object>();
        
        String callback = SNStringUtils.show(request.getParameter("callback"),(String)jsondata.get("callback"));
        
        if(DataUtil.check(jsondata)){
            //判断id来查询是否存在记录
            //插入数据字段，插入数据值，映射
            rs.put("success", true);
            rs.put("msg", "导入成功!");
            rs.put("detail", dataService.importData(jsondata));
        }else{
        	rs.put("success", false);
            rs.put("msg", "数据格式不符合!");
        }
        
        return JsonpCallback.callbcak(callback, rs);
    }
    
    /**
     * 
     * 功能描述: 查询数据<br>
     * 〈功能详细描述〉
     *
     * @param jsondata
     * @param request
     * @param response
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping(value = "query",produces = {"application/json;charset=UTF-8"})
    @ResponseBody
    public String query(@RequestParam("jsondata") Map<String,Object> jsondata, HttpServletRequest request,HttpServletResponse response){
    	Map<String,Object> rs = new HashMap<String,Object>();
    	String callback = SNStringUtils.show(request.getParameter("callback"),(String)jsondata.get("callback"));
    	if(DataUtil.check(jsondata,new String[]{"table"})){
    		rs.put("success", true);
    		rs.put("data", dataService.query(jsondata));
    		rs.put("total", dataService.queryTotal(jsondata));
    	}else{
    		rs.put("success", false);
    		rs.put("error", "数据格式错误!");
    	}
    	return JsonpCallback.callbcak(callback, rs);
    }
    
}
