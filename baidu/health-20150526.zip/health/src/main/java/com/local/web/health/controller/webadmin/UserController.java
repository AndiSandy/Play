/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: DashBoardController.java
 * Author:   Administrator
 * Date:     2014年8月24日 下午7:38:53
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.controller.webadmin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.local.web.health.model.User;
import com.local.web.health.service.UserService;
import com.local.web.util.MD5Util;

/**
 * 后台管理页面<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/webadmin/user")
public class UserController {

	@Autowired
	private UserService userService;
	
	/**
	 * 
	 * 功能描述: 管理主页<br>
	 * 〈功能详细描述〉
	 *
	 * @param request
	 * @param response
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping(value = "list")
	public String userList(HttpServletRequest request,HttpServletResponse response){
		String page_ftl = "webadmin/user-list.ftl";
		
		List<User> userList = userService.queryAll();
		
		request.setAttribute("userlist", userList);
		
		return page_ftl;
	}
	
	@RequestMapping(value = "save")
    @ResponseBody
    public Map<String, Object> save(@RequestParam(value = "userName", required = true) String userName,
    		@RequestParam(value = "nickName", required = false) String nickName,
    		@RequestParam(value = "password", required = true) String password,
            @RequestParam(value = "objid", required = true) Integer objid,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        
        User obj = new User(userName,password);
        obj.setNickName(nickName);
        if(objid != null){
            obj.setUserId(objid);
            userService.updateByExample(obj);
        }else{
        	obj.setPassword(MD5Util.MD5(obj.getPassword()));
        	userService.add(obj);
        }
        map.put("success", true);
        map.put("txt", "保存更新信息成功");
        map.put("obj", obj);
        
        return map;
    }
    
    @RequestMapping(value = "del")
    @ResponseBody
    public Map<String, Object> del(@RequestParam(value = "objid", required = true) Integer objid,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        User obj = new User();
        obj.setUserId(objid);
        userService.delByExample(obj);
        map.put("success", true);
        map.put("txt", "删除信息成功");
        
        return map;
    }
    
    @RequestMapping(value = "query")
    @ResponseBody
    public Map<String, Object> query(@RequestParam(value = "objid", required = true) Integer objid,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> map = new HashMap<String, Object>();
        
        User obj = new User();
        obj.setUserId(objid);
        List<User> objs = userService.queryByExample(obj);
        if(objs.size() > 0){
            obj = objs.get(0);
            map.put("success", true);
            map.put("txt", "查询信息成功");
            map.put("obj", obj);
        }else{
            map.put("success", false);
            map.put("txt", "查询信息失败,记录不存在!");
        }
        
        return map;
    }
	
	
}
