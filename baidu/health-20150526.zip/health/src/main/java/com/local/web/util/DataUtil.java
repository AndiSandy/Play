/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: DataUtil.java
 * Author:   Administrator
 * Date:     2015年2月25日 上午11:13:37
 * Description: 数据处理工具//模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.core.convert.converter.Converter;

import com.local.web.health.converter.LongToDateStrng;

/**
 * 〈一句话功能简述〉处理数据<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class DataUtil {
	
	/**
	 * 检测字段列表
	 */
	private static String[] checkFileds = {"data","table"};
	
	/**
	 * 类型转换器
	 */
	private static Map<String,Converter> parser = new HashMap<String,Converter>();
	static{
		parser.put("long2date", new LongToDateStrng());
	}
	
	/**
	 * 
	 * 功能描述: 检查是否符合数据规范<br>
	 * 〈功能详细描述〉
	 *
	 * @param jsondata
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static boolean check(Map<String,Object> jsondata){
		return check(jsondata, checkFileds);
	}
	
	/**
	 * 
	 * 功能描述: 检查数据是否合格<br>
	 * 〈功能详细描述〉
	 *
	 * @param jsondata
	 * @param fields
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static boolean check(Map<String,Object> jsondata,String[] fields){
		boolean valid = true;
		for (int i = 0; i < fields.length; i++) {
			String field = fields[i];
			valid = valid && jsondata.containsKey(field);
		}
		return valid;
	}
	
	
	/**
	 * 
	 * 功能描述: 按照映射处理数据<br>
	 * 〈功能详细描述〉
	 *
	 * @param odata
	 * @param mapper
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static Map<String,Object> makeData(Map<String,Object> odata, Map<String,String> mapper){
		Map<String,Object> data = odata;
		if(!SNCollections.isEmpty(mapper)){
			data = new HashMap<String,Object>();
			for (Iterator<String> iterator = mapper.keySet().iterator(); iterator.hasNext();) {
				String key = (String) iterator.next();
				String nkey = mapper.get(key);
				data.put(nkey, odata.get(key));
			}
		}
		return data;
	}
	
	/**
	 * 
	 * 功能描述: 按照映射处理数据<br>
	 * 〈功能详细描述〉
	 *
	 * @param odata
	 * @param mapper
	 * @param oparser 类型转换器
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@SuppressWarnings("unchecked")
	public static Map<String,Object> makeData(Map<String,Object> odata, Map<String,String> mapper,Map<String,String> oparser){
		Map<String,Object> data = odata;
		if(oparser == null){
			oparser = new HashMap<String,String>();
		}
		if(!SNCollections.isEmpty(mapper)){
			data = new HashMap<String,Object>();
			for (Iterator<String> iterator = mapper.keySet().iterator(); iterator.hasNext();) {
				String key = (String) iterator.next();
				String nkey = mapper.get(key);
				Object v = odata.get(key);
				String sparser = oparser.get(nkey);
				if(!SNStringUtils.isEmpty(sparser)){
					Converter converter = parser.get(sparser);
					if( converter != null){
						v = converter.convert(v);
					}
				}
				data.put(nkey, v);
			}
		}
		return data;
	}
	
	
	/**
	 * 
	 * 功能描述: 处理映射字段<br>
	 * 〈功能详细描述〉
	 *
	 * @param jsondata
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static String[] makeFileds7Values(Map<String,Object> data){
		String[] fv = new String[2];
		List<String> fileds = new ArrayList<String>(),values = new ArrayList<String>();
		for (Iterator<String> iterator = data.keySet().iterator(); iterator.hasNext();) {
			String field = (String) iterator.next();
			Object value = data.get(field);
			fileds.add(field);
			values.add(tostring(value));
		}
		fv[0] = StringUtils.join(fileds.toArray(),",");
		fv[1] = StringUtils.join(values.toArray(),",");
		return fv;
	}
	
	public static String makeFileds(Map<String,Object> data){
		List<String> fileds = new ArrayList<String>();
		for (Iterator<String> iterator = data.keySet().iterator(); iterator.hasNext();) {
			String field = (String) iterator.next();
			fileds.add(field);
		}
		return StringUtils.join(fileds.toArray(),",");
	}
	
	/**
	 * 
	 * 功能描述: 处理插入的数据<br>
	 * 〈功能详细描述〉
	 *
	 * @param data
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static String makeValues(Map<String,Object> data){
		List<String> values = new ArrayList<String>();
		for (Iterator<String> iterator = data.keySet().iterator(); iterator.hasNext();) {
			String field = (String) iterator.next();
			Object value = data.get(field);
			values.add(tostring(value));
		}
		return StringUtils.join(values.toArray(),",");
	}
	
	/**
	 * 
	 * 功能描述: 转换为sql的字符串<br>
	 * 〈功能详细描述〉
	 *
	 * @param value
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static String tostring(Object value){
		return "'"+SNStringUtils.show(value)+"'";
	}
	
	/**
	 * 
	 * 功能描述: 条件处理<br>
	 * 〈功能详细描述〉
	 *
	 * @param data
	 * @param id
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static String makeCondition(Map<String,Object> data, String id){
	    String condition = null;
	    String v = tostring(data.get(id));
	    if(!SNStringUtils.isEmpty(v)){
	        condition = id + "=" + tostring(data.get(id));
	    }
		return condition;
	}
	
	/**
	 * 
	 * 功能描述: 更新处理<br>
	 * 〈功能详细描述〉
	 *
	 * @param data
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static String makeSets(Map<String,Object> data){
		List<String> sets = new ArrayList<String>();
		for (Iterator<String> iterator = data.keySet().iterator(); iterator.hasNext();) {
			String field = (String) iterator.next();
			Object value = data.get(field);
			sets.add( field + "=" + tostring(value));
		}
		return StringUtils.join(sets.toArray(),",");
	}
	
	/**
	 * 
	 * 功能描述: 处理添加的数据<br>
	 * 〈功能详细描述〉
	 *
	 * @param table
	 * @param o
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public static Map<String,Object> makeInsert(String table, Map<String,Object> o){
		String[] fv = DataUtil.makeFileds7Values(o);
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("fields", fv[0]);
		condition.put("values", fv[1]);
		condition.put("table", table);
		return condition;
	}
	
}
