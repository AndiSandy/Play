/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: ChatSendMsgHandler.java
 * Author:   14041326
 * Date:     2015年1月16日 下午5:48:06
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.chat;

import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.local.web.health.chat.event.IEventHandler;
import com.local.web.health.model.ChatRecord;
import com.local.web.health.service.ChatRecordService;
import com.local.web.util.SNStringUtils;

/**
 * 〈一句话功能简述〉处理发送信息<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class ChatSendMsgHandler implements IEventHandler {
    
    
	/**
	 * 聊天记录持久化服务
	 */
    @Autowired
	ChatRecordService chatRecordService;
    
    /**
     * 
     * 功能描述: 将map转换为record对象<br>
     * 〈功能详细描述〉
     *
     * @param msg
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public ChatRecord parse(Map<String,Object> msg){
    	ChatRecord record = new ChatRecord();
    	
    	ChatUser to = (ChatUser) msg.get("to");
    	ChatUser fromuser = (ChatUser) msg.get("from");
    	Date date = SNStringUtils.parseDate(msg.get("date"), "yyyy-MM-dd hh:mm:ss");
    	record.setDate(date);
    	record.setFrom(fromuser.getSessionid());
    	record.setFrom_nickname(fromuser.getNickname());
    	record.setTo(to.getSessionid());
    	record.setTo_nickname(to.getNickname());
    	record.setMsg((String)msg.get("msg"));
    	
    	return record;
    }
    
    /**
     * MsgBox ChatUser:to Map:msg
     */
    @SuppressWarnings("unchecked")
	@Override
    public void handler(Object[] args) {
        if(args != null && args.length == 3 ){
        	//解析参数
        	MsgBox msgBox = (MsgBox) args[0];
        	ChatUser to = (ChatUser) args[1];
        	Map<String,Object> msg = (Map<String,Object>) args[2];
        	ChatUser fromuser = (ChatUser) msg.get("from");
        	if( to != null && fromuser != null){
        		//判断是否要记录的用户
            	if( msgBox.getRecordList().contains(to.getSessionid()) 
            			|| msgBox.getRecordList().contains(fromuser.getSessionid())){
            		//记录聊天记录
            		chatRecordService.add(parse(msg));
            	}
        	}
        }
    }

}
