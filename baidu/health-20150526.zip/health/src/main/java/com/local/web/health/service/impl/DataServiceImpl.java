/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: DataImportServiceImpl.java
 * Author:   Administrator
 * Date:     2015年2月25日 下午2:29:08
 * Description: 数据服务//模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.local.web.health.dao.DataDao;
import com.local.web.health.service.DataService;
import com.local.web.util.DataUtil;
import com.local.web.util.SNCollections;
import com.local.web.util.SNStringUtils;

/**
 * 〈一句话功能简述〉数据服务<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Service
public class DataServiceImpl implements DataService {
	
	@Autowired
	DataDao dataDao;
	
	@SuppressWarnings("unchecked")
	@Transactional
	@Override
	public Map<String, Object> importData(Map<String, Object> jsondata) {
		
		Map<String,Object> msg = new HashMap<String,Object>();
		
		//json数据字符串
    	List<Map<String,Object>> jsonlist = (List<Map<String,Object>>)jsondata.get("data");
        //映射
    	Map<String,String> mapper = (Map<String,String>)jsondata.get("mapper");
        //主键
        String id = SNStringUtils.show(jsondata.get("id"));
        //表名
        String table = SNStringUtils.show(jsondata.get("table"));
        
        //类型转换器
        Map<String,String> parser = (Map<String,String>)jsondata.get("parser");
		
        if (!SNCollections.isEmpty(jsonlist)) {
        	if(SNStringUtils.isEmpty(id)){//批量添加数据
        		Map<String,Object> res = new HashMap<String,Object>();
        		res.put("table", table);
        		
        		List<String> vlist = new ArrayList<String>();
        		for (int i = 0; i < jsonlist.size(); i++) {
        			Map<String,Object> o = DataUtil.makeData(jsonlist.get(i), mapper,parser);
    				vlist.add(DataUtil.makeValues(o));
    				if(!res.containsKey("fields")){
    					res.put("fields", DataUtil.makeFileds(o));
    				}
    			}
        		res.put("vlist", vlist);
        		dataDao.addBatch(res);
        		msg.put("info", "数据添加成功");
        	}else{
        	    List<Map<String,Object>> retlist = new ArrayList<Map<String,Object>>();
        		for (int i = 0; i < jsonlist.size(); i++) {
    				Map<String,Object> o = DataUtil.makeData(jsonlist.get(i), mapper,parser);
    				if(exist(table,id,o)){
    					//update
    				    retlist.add(update(table, id, o));
    				}else{
    					//insert
    				    retlist.add(insert(table, id, o));
    				}
    			}
        		msg.put("data", retlist);
        	}
		}else{
			msg.put("error", "数据为空!");
		}
		return msg;
	}
	
	/**
	 * 
	 * 功能描述: 查询数据是否存在<br>
	 * 〈功能详细描述〉
	 *
	 * @param table
	 * @param id
	 * @param o
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public boolean exist(String table, String id, Map<String,Object> o){
		boolean exist = false;
		if(!SNStringUtils.isEmpty(id)){
			Map<String,Object> condition = new HashMap<String,Object>();
			condition.put("table", table);
			condition.put("condition", DataUtil.makeCondition(o, id));
			return dataDao.query(condition).size() > 0;
		}
		return exist;
	}
	
	/**
	 * 
	 * 功能描述: 更新数据<br>
	 * 〈功能详细描述〉
	 *
	 * @param table
	 * @param id
	 * @param o
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public Map<String,Object> update(String table, String id, Map<String,Object> o){
		String sets = DataUtil.makeSets(o);
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("sets", sets);
		condition.put("table", table);
		if(!SNStringUtils.isEmpty(id)){
			condition.put("condition", DataUtil.makeCondition(o, id));
		}
		Map<String,Object> ret = new HashMap<String,Object>();
		ret.put("success", dataDao.update(condition));
		ret.put(SNStringUtils.show(id,"id"), condition.get(id));
		return ret;
	}
	
	/**
	 * 
	 * 功能描述: 添加数据<br>
	 * 〈功能详细描述〉
	 *
	 * @param table
	 * @param o
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public Map<String,Object> insert(String table,String id, Map<String,Object> o){
		String[] fv = DataUtil.makeFileds7Values(o);
		Map<String,Object> condition = new HashMap<String,Object>();
		condition.put("fields", fv[0]);
		condition.put("values", fv[1]);
		condition.put("table", table);
		Map<String,Object> ret = new HashMap<String,Object>();
        ret.put("success", dataDao.add(condition));
        ret.put(SNStringUtils.show(id,"id"), condition.get(id));
		return ret;
	}

	@Override
	public List<Map<String, Object>> query(Map<String, Object> jsondata) {
		return dataDao.query(jsondata);
	}

    @Override
    public int queryTotal(Map<String, Object> jsondata) {
        // TODO Auto-generated method stub
        return dataDao.queryTotal(jsondata);
    }
	
}
