/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: MapEditor.java
 * Author:   Administrator
 * Date:     2015年2月27日 上午12:05:21
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.converter;

import java.beans.PropertyEditorSupport;

/**
 * 〈一句话功能简述〉Map编辑器<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class MapEditor extends PropertyEditorSupport {
	
	StringToMap stringToMap = new StringToMap();
	
	public MapEditor() {
		// TODO Auto-generated constructor stub
	}
	
	public MapEditor(String dcode) {
		stringToMap = new StringToMap(dcode);
	}
	
	@Override
	public void setAsText(String json) throws IllegalArgumentException {
		this.setValue(stringToMap.convert(json));
	}
}
