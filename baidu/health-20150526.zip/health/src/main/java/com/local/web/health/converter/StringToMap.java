/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: StringToMap.java
 * Author:   14041326
 * Date:     2015年2月26日 下午6:06:47
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.converter;

import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.core.convert.converter.Converter;

import com.local.web.util.SNStringUtils;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class StringToMap implements Converter<String, Map<String,Object>> {
	
	private ObjectMapper objectMapper = new ObjectMapper();
	
	private String dcode = null;
	
	public StringToMap() {
		// TODO Auto-generated constructor stub
		objectMapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
	}
	
	public StringToMap(String dcode) {
		// TODO Auto-generated constructor stub
		objectMapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
		this.dcode = dcode;
	}
	
    @SuppressWarnings("unchecked")
	@Override
    public Map<String,Object> convert(String ojson) {
    	Map<String,Object> map = null;
    	try {
    		String json = ojson;
    		if(!SNStringUtils.isEmpty(dcode)){
    			json = SNStringUtils.encode(ojson, dcode, "utf-8");
    		}
    		map = objectMapper.readValue(json, HashMap.class);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("conert error");
		}
        return map;
    }

}
