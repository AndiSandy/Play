/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: ChatUser.java
 * Author:   Administrator
 * Date:     2014年9月19日 下午10:27:41
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.chat;

/**
 * 聊天用户<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class ChatUser {
	
	/**
	 * 会话id
	 */
	String sessionid;
	String usrename;
	String nickname;
	
	public ChatUser() {
		// TODO Auto-generated constructor stub
	}
	
	public ChatUser(String sessionid, String usrename, String nickname) {
		super();
		this.sessionid = sessionid;
		this.usrename = usrename;
		this.nickname = nickname;
	}
	public String getSessionid() {
		return sessionid;
	}
	public void setSessionid(String sessionid) {
		this.sessionid = sessionid;
	}
	public String getUsrename() {
		return usrename;
	}
	public void setUsrename(String usrename) {
		this.usrename = usrename;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof ChatUser){
			ChatUser u = (ChatUser) obj;
			if(this.getUsrename() != null && !this.getUsrename().trim().equals("")){
				return this.getUsrename().equals(u.getUsrename());
			}else{
				return this.getSessionid().equals(u.getSessionid());
			}
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		//return super.hashCode();
		return 0;
	}
	
}
