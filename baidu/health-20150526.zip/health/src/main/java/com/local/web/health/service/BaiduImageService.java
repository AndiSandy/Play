package com.local.web.health.service;

/**
 * 
 * 百度图片服务功能<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public interface BaiduImageService {
	/**
	 * 
	 * 功能描述: 获取二维码<br>
	 * 〈功能详细描述〉
	 *
	 * @param text 内容
	 * @param size 尺寸
	 * @param background 背景"AABBCC"
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	public byte[] getQRCodeImage(String text,int size,String background);
}
