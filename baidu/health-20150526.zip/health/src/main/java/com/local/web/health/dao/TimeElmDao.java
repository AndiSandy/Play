/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: TimeElmDao.java
 * Author:   14041326
 * Date:     2014年8月28日 下午2:47:30
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.dao;

import java.util.List;

import com.local.web.health.model.TimeElm;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public interface TimeElmDao {
    
    public List<TimeElm> queryAll();
    public List<TimeElm> queryByExample(TimeElm time);
    public TimeElm queryById(Integer timeId);
    public int add(TimeElm time);
    public void updateByExample(TimeElm time);
    public void delByExample(TimeElm time);
    public int getNextOrder();
    
}
