/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: DashBoardController.java
 * Author:   Administrator
 * Date:     2014年8月24日 下午7:38:53
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.controller.webadmin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 后台管理页面<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/webadmin")
public class DashBoardController {

	
	
	/**
	 * 
	 * 功能描述: 管理主页<br>
	 * 〈功能详细描述〉
	 *
	 * @param request
	 * @param response
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
	@RequestMapping(value = "dashboard")
	public String dashboard(HttpServletRequest request,HttpServletResponse response){
		String page_ftl = "webadmin/dashboard.ftl";
		return page_ftl;
	}
	
}
