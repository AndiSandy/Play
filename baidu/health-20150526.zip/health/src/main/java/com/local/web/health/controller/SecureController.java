/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: SecureController.java
 * Author:   14041326
 * Date:     2014年8月21日 上午10:16:25
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.local.web.health.chat.ChatUser;
import com.local.web.health.chat.MsgBox;
import com.local.web.health.chat.MsgUtils;
import com.local.web.health.model.User;
import com.local.web.health.service.UserService;
import com.local.web.health.util.HealthContext;
import com.local.web.util.MD5Util;
import com.local.web.util.SNStringUtils;
import com.local.web.util.WebUtils;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
@Controller
@RequestMapping("/secure/")
public class SecureController {
    
	 @Autowired
	 private UserService userService; 
    
	/**
	 * 
	 * 功能描述: 匿名登录-匿名聊天<br>
	 * 〈功能详细描述〉
	 *
	 * @param username
	 * @param password
	 * @param request
	 * @param response
	 * @return
	 * @see [相关类/方法](可选)
	 * @since [产品/模块版本](可选)
	 */
    @RequestMapping(value = "login")
    @ResponseBody
    public Map<String,Object> login(@RequestParam(value = "username", required = true) String username,
            @RequestParam(value = "password", required = true) String password,
            HttpServletRequest request,HttpServletResponse response){
    	
    	//获取指定人的消息
        MsgBox msgBox = MsgUtils.getMsgBox(request);
        
        //注销之前登录的用户
    	ChatUser pre_user = (ChatUser)request.getSession().getAttribute(HealthContext.CHAT_USER);
    	if(pre_user != null){
    		msgBox.offline(pre_user);
    	}
    	
    	String chat_session_id = WebUtils.getCookie(request, HealthContext.CHAT_SESSION_NAME);
    	if(!SNStringUtils.isEmpty(chat_session_id)){
    	    ChatUser user = new ChatUser(chat_session_id,null,username);
            request.getSession().setAttribute(HealthContext.CHAT_USER,user);
            //上线
            msgBox.online(user);
    	}else{
    	    chat_session_id = WebUtils.makeSession(request, response, HealthContext.CHAT_SESSION_NAME);
    	    ChatUser user = new ChatUser(chat_session_id,null,username);
            request.getSession().setAttribute(HealthContext.CHAT_USER,user);
            //上线
            msgBox.online(user);
    	}
    	
    	request.getSession().setAttribute("username",username);
        Map<String,Object> map = new HashMap<String,Object>();  
        map.put("success", true);
        map.put("txt", username+"登陆成功");
        
        
        
        return map;
    }
    
    /**
     * 
     * 功能描述: 注销-匿名聊天<br>
     * 〈功能详细描述〉
     *
     * @param request
     * @param response
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping(value = "logout")
    @ResponseBody
    public Map<String,Object> logout(HttpServletRequest request,HttpServletResponse response){
        request.getSession().removeAttribute("username");
        Map<String,Object> map = new HashMap<String,Object>();  
        map.put("success", true);
        map.put("txt", "注销成功");
        
        String username = (String)request.getSession().getAttribute("username");
        ChatUser user = (ChatUser)request.getSession().getAttribute(HealthContext.CHAT_USER);
        //获取指定人的消息
        MsgBox msgBox = MsgUtils.getMsgBox(request);
        if(user != null){
        	msgBox.offline(user);
        }else{
        	msgBox.offline(username);
        }
        return map;
    }
    
    /**
     * 
     * 功能描述: 安全登录-后台<br>
     * 〈功能详细描述〉
     *
     * @param username
     * @param password
     * @param request
     * @param response
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping(value = "slogin")
    @ResponseBody
    public Map<String,Object> slogin(@RequestParam(value = "username", required = true) String username,
            @RequestParam(value = "password", required = true) String password,
            HttpServletRequest request,HttpServletResponse response){
    	Map<String,Object> map = new HashMap<String,Object>();  
    	//登录逻辑
    	User loginuser = new User(username,MD5Util.MD5(password));
    	List<User> users = userService.queryByExample(loginuser);
    	if(users.size() == 1){//登录成功
    		loginuser = users.get(0);
    		request.getSession().setAttribute(HealthContext.SESSON_LOGIN_USER,loginuser);
    		map.put("success", true);
    		map.put("txt", username+"登陆成功");
    	}else{//登录失败
    		map.put("success", false);
    		map.put("txt", username+"登陆失败,用户不存在或密码错误!!!");
    	}
        return map;
    }
    
    /**
     * 
     * 功能描述: 安全退出-后台<br>
     * 〈功能详细描述〉
     *
     * @param request
     * @param response
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping(value = "slogout")
    @ResponseBody
    public Map<String,Object> slogout(HttpServletRequest request,HttpServletResponse response){
        request.getSession().removeAttribute("username");
        
        Map<String,Object> map = new HashMap<String,Object>();  
        map.put("success", true);
        map.put("txt", "注销成功");
        request.getSession().removeAttribute(HealthContext.SESSON_LOGIN_USER);
        
        return map;
    }
    
    /**
     * 
     * 功能描述: 检查是否登录<br>
     * 〈功能详细描述〉
     *
     * @param request
     * @param response
     * @return
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    @RequestMapping(value = "islogin")
    @ResponseBody
    public Map<String,Object> islogin(HttpServletRequest request,HttpServletResponse response){
        Map<String,Object> map = new HashMap<String,Object>();  
        map.put("success", false);
        map.put("txt", "用户未登录");
        User loginUser = (User) request.getSession().getAttribute(HealthContext.SESSON_LOGIN_USER); 
        if( loginUser != null){
            map.put("success", true);
            map.put("txt", loginUser.getUserName()+"已经登录");
        }
        return map;
    }
    
}
