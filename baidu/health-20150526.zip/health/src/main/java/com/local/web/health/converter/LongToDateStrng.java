/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: LongToDataStrng.java
 * Author:   Administrator
 * Date:     2015年3月8日 上午12:52:07
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.converter;

import java.util.Date;

import org.springframework.core.convert.converter.Converter;

import com.local.web.util.SNStringUtils;

/**
 * 〈一句话功能简述〉将long转化为日期字符串yyyy-MM-dd hh:mm:ss<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class LongToDateStrng implements Converter<Long,String> {
	
	private String format = "yyyy-MM-dd hh:mm:ss";
	
	@Override
	public String convert(Long source) {
		Date d = null;
		if(!SNStringUtils.isEmpty(source)){
			try{
				d = new Date(source);
			}catch(Exception e){
				d = new Date();
			}
		}else{
			d = new Date();
		}
		return SNStringUtils.formatDate(d, format);
	}

}
