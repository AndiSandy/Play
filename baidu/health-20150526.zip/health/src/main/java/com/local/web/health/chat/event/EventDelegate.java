/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: EventDelegate.java
 * Author:   14041326
 * Date:     2014年8月21日 下午2:32:12
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.chat.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class EventDelegate <T>{
    
    private Map<T,List<IEventHandler>> eventsMap = new HashMap<T,List<IEventHandler>>();
    
    /**
     * 
     * 功能描述: 事件绑定<br>
     * 〈功能详细描述〉
     *
     * @param e
     * @param handler
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public void on(T e,IEventHandler handler){
        List<IEventHandler> events = getEvents(e);
        events.add(handler);
    }
    
    /**
     * 
     * 功能描述: 定义事件<br>
     * 〈功能详细描述〉
     *
     * @param e
     * @param o
     * @see [相关类/方法](可选)
     * @since [产品/模块版本](可选)
     */
    public void defineEvent(T e,Object[] o){
        List<IEventHandler> events = getEvents(e);
        for (int i = 0; i < events.size(); i++) {
            IEventHandler eventHandler = events.get(i);
            eventHandler.handler(o);
        }
    }

    /**
     * @return the events
     */
    public List<IEventHandler> getEvents(T e) {
        List<IEventHandler> events = eventsMap.get(e);
        if(events == null){
            events = new ArrayList<IEventHandler>();
            eventsMap.put(e, events);
        }
        return events;
    }
    
    
}
