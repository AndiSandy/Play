angular.module("lottery").controller("test", ["$scope", "$timeout","$interval", function ($scope,$timeout,$interval) {
	var table = $.extend(new Table(),{
		length : 10,
		$interval : $interval,
		compare : function(a,b){
			var oa = a[6], ob = b[6];
			return oa == ob ? 0 : oa > ob ? 1 : -1;
		}
	});
	$scope.table = table;
	
	var i = 0;
	table.until(1000, function(){
		//执行一次
	}, function(){
		table.add(table.random());
		i ++;
		return !(i < table.length);
	});
}]);