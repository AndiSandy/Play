angular.module("lottery").controller("charts", ["$scope", "$timeout","$interval","$http", function ($scope,$timeout,$interval,$http) {
	
	function random(){
		var wl = WL.gwl();
		wl.red_ball.push(wl.blue_ball);
		return wl.red_ball;
	}
	
	$scope.labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
    $scope.series = ['Series A', 'Series B'];
    $scope.data = [
      random(),
      random()
    ];

    $interval(function () {
      $scope.data[0].splice(0,1);
      $scope.data[0].push(Math.$random(1,33));
      
      $scope.data[1].splice(0,1);
      $scope.data[1].push(Math.$random(1,33));
    }, 1000);
}]);