Array.fn = Array.prototype;
Array.compare_asc = function(oa,ob){
	return oa == ob ? 0 : oa > ob ? 1 : -1;
}
Array.compare_desc = function(oa,ob){
	return oa == ob ? 0 : oa > ob ? -1 : 1;
}
Array.compare = Array.compare_asc;

Array.prototype.swap = function(i, j) {
	var temp = this[i];
	this[i] = this[j];
	this[j] = temp;
}


/**
 * 冒泡排序
 * @memberOf {Array} 
 */
Array.prototype.bubbleSort = function() {
	for ( var i = this.length - 1; i > 0; --i) {
		for ( var j = 0; j < i; ++j) {
			var result = Array.compare(this[j],this[j + 1]) ;
			if (result > 0 )// (this[j] > this[j + 1])
				Array.prototype.swap.call(this,j, j + 1);
		}
	}
}

/**
 * 选择排序
 * @memberOf {Array} 
 */
Array.prototype.selectionSort = function() {
	for ( var i = 0; i < this.length; ++i) {
		var index = i;
		for ( var j = i + 1; j < this.length; ++j) {
			if (Array.compare(this[index],this[j]) > 0)//this[j] < this[index])
				index = j;
		}
		Array.prototype.swap.call(this,i, index);
	}
}
/**
 * 插入排序
 * @memberOf {Array} 
 */
Array.prototype.insertionSort = function() {
	for ( var i = 1; i < this.length; ++i) {
		var j = i, value = this[i];
		while (j > 0 && Array.compare(this[j - 1],value) > 0) {//this[j - 1] > value
			this[j] = this[j - 1];
			--j;
		}
		this[j] = value;
	}
}
/**
 * 谢尔排序
 * @memberOf {TypeName} 
 */
Array.prototype.shellSort = function() {
	for ( var step = this.length >> 1; step > 0; step >>= 1) {
		for ( var i = 0; i < step; ++i) {
			for ( var j = i + step; j < this.length; j += step) {
				var k = j, value = this[j];
				while (k >= step && Array.compare(this[k - step],value) > 0 ) {//this[k - step] > value
					this[k] = this[k - step];
					k -= step;
				}
				this[k] = value;
			}
		}
	}
}

/**
 * 快速排序(递归)
 * @param {Object} s
 * @param {Object} e
 * @memberOf {TypeName} 
 * @return {TypeName} 
 */
Array.prototype.quickSort = function(s, e) {
	if (s == null)
		s = 0;
	if (e == null)
		e = this.length - 1;
	if (s >= e)
		return;
	Array.prototype.swap.call(this,(s + e) >> 1, e);
	var index = s - 1;
	for ( var i = s; i <= e; ++i) {
		if (Array.compare(this[e],this[i]) >= 0 )// this[i] <= this[e]
			Array.prototype.swap.call(this,i, ++index);
	}
	this.quickSort(s, index - 1);
	this.quickSort(index + 1, e);
}

/**
 * 快速排序(堆栈)
 * @memberOf {TypeName} 
 */
Array.prototype.stackQuickSort = function() {
	var stack = [ 0, this.length - 1 ];
	while (stack.length > 0) {
		var e = stack.pop(), s = stack.pop();
		if (s >= e)
			continue;
		Array.prototype.swap.call(this,(s + e) >> 1, e);
		var index = s - 1;
		for ( var i = s; i <= e; ++i) {
			if ( Array.compare(this[e],this[i]) >= 0 )//this[i] <= this[e]
				Array.prototype.swap.call(this,i, ++index);
		}
		stack.push(s, index - 1, index + 1, e);
	}
}

/**
 * 归并排序
 * @param {Object} s
 * @param {Object} e
 * @param {Object} b
 * @memberOf {TypeName} 
 * @return {TypeName} 
 */
Array.prototype.mergeSort = function(s, e, b) {
	if (s == null)
		s = 0;
	if (e == null)
		e = this.length - 1;
	if (b == null)
		b = new Array(this.length);
	if (s >= e)
		return;
	var m = (s + e) >> 1;
	this.mergeSort(s, m, b);
	this.mergeSort(m + 1, e, b);
	for ( var i = s, j = s, k = m + 1; i <= e; ++i) {
		b[i] = this[(k > e || j <= m && Array.compare(this[k],this[j]) > 0 ) ? j++ : k++];//this[j] < this[k]
	}
	for ( var i = s; i <= e; ++i)
		this[i] = b[i];
}
/**
 * 堆排序
 * @memberOf {TypeName} 
 */
Array.prototype.heapSort = function() {
	for ( var i = 1; i < this.length; ++i) {
		for ( var j = i, k = (j - 1) >> 1; k >= 0; j = k, k = (k - 1) >> 1) {
			if (Array.compare(this[k],this[j]) >= 0 )//this[k] >= this[j]
				break;
			Array.prototype.swap.call(this,j, k);
		}
	}
	for ( var i = this.length - 1; i > 0; --i) {
		Array.prototype.swap.call(this,0, i);
		for ( var j = 0, k = (j + 1) << 1; k <= i; j = k, k = (k + 1) << 1) {
			if (k == i || Array.compare(this[k-1],this[k]) > 0 ) //this[k] < this[k - 1]
				--k;
			if (Array.compare(this[j],this[k]) >= 0) //this[k] <= this[j]
				break;
			Array.prototype.swap.call(this,j, k);
		}
	}
}