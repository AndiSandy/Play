angular.module("lottery").controller("lottery", ["$scope", "$timeout", function ($scope,$timeout) {
	$scope.staticItems = [];
    $scope.dynamicItems = [];
    
    $.extend($scope,{
    	arrays :{
    		staticItems : [],
    		dynamicItems :[],
    		simple : []
    	}
    });
    
    var RAND_SEED = 0;
    var NUMBER = 400;
    var DEELAY = 10;
    
    var A = 48271, M = 2147483647, Q = parseInt(M/A), R = M%A;
    var Random = function(seed){
    	var state;
    	if(seed < 0){
    		seed += M;
    	}
    	state = seed;
    	if(state==0){
    		state=1;
    	}
    	this.__random__ = function(){
    		var tmpState = A*( state % Q ) - R * (state / Q);
   		    if(tmpState > 0){
   		    	state = tmpState;
   		    }else{
   		    	state = tmpState + M;
   		    }
   		    return state;
    	};
    	this.random = function(){
    		return parseFloat(this.__random__()/M);
    	};
    	this.__random = function(low,high){
    		if(!high){
    			high = low;
    			low = 0; 
    		}
    		var range = high - low;
    	    return low+this.__random__()%range;
    	};
    	//console.info("----initialize---");
    };
    var quick = true;
    var math = {
    		random : function(max){
    			RAND_SEED = (new Date).getTime() * Math.random();
    			var r = Math.ceil(RAND_SEED % max);
    			return r;
    		},
    		sort : function(array){
    			function sort(array) {
    				var s = true;
    		        // 喵的，写到这个才发现yield是多么好啊
    		        for (var i = 0; i < array.length; i++) {
    		            for (var j = array.length; j > 0; j--) {
    		                if (array[j] < array[j - 1]) {
    		                    var temp = array[j - 1];
    		                    array[j - 1] = array[j];
    		                    array[j] = temp;
    		                    s = false;
    		                    break;
    		                    if(quick){
    		                    	return false;
    		                    }
    		                }
    		            }
    		        }
    		        return s;
    		    }
    			if (!sort(array)) {
    	            $timeout(function() {
    	                math.sort(array);
    	            }, DEELAY);
    	        }
    		}
    };
    
    var RANGE = 100;
    var make = {
    	sin : function(c){
    		return Math.ceil(RANGE * (1 + Math.sin(c * Math.PI / 180)));
    	},
    	//普通算法
    	random : function(c){
    		return math.random(RANGE);
    	},
    	//简单算法
    	random1 : function(c){
    		var r = math.random(RANGE); 
    		return (new Random(r)).__random(RANGE);
    	},
    	fill : function(array,mc){
    		for (var i = 0; i < NUMBER; i++) {
    	    	array.push((mc || make.random)(i));
    	    }
    	},
    	__fill : function(array,mc){
            var newItem = (mc || make.random)(RANGE);
            if (array.length > NUMBER) {
                array.splice(0, 1);
            }
            array.push(newItem);
            $timeout(function () {
                make.__fill(array,mc);
            }, DEELAY);
    	}
    };
    
    //============SORT
    make.fill($scope.arrays.staticItems);
    math.sort($scope.arrays.staticItems);
    
    make.fill($scope.arrays.simple);
    math.sort($scope.arrays.simple);
    
    
    //------------
    var counter = 0;
    make.__fill($scope.arrays.dynamicItems);
    
    
}]);