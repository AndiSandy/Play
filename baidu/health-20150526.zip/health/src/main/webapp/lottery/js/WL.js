(function($,w){
	
	var package = "WL.js";
	var log = $.Logger.getLogger(package);
	
	
	function MTRandom(){
		var MT = [];  
		var index = 0;  
		function initialize_generator(seed) {  
		    MT[0] = seed;  
		    for (var i = 1; i < 624; i++) {  
		        MT[i] = 0xffffffff & (0x6c078965 * (MT[i - 1] ^ (MT[i - 1] >> 30)) + i);  
		    }  
		}  
		function generate_numbers() {  
		    for (var i = 0; i < 624; i++) {  
		        var y = (MT[i] & 0x80000000) + (MT[(i + 1) % 624] & 0x7fffffff);  
		        MT[i] = MT[(i + 397) % 624] ^ (y >> 1);  
		        if (y % 2 != 0) {  
		            MT[i] ^= 0x9908b0df;  
		        }  
		    }  
		}  
		function extract_number() {  
		    if (index == 0) {  
		        generate_numbers();  
		    }  
		    var y = MT[index];  
		    y ^= (y >> 11);  
		    y ^= ((y << 7) & 0x9d2c5680);  
		    y ^= ((y << 15) & 0xefc60000);  
		    y ^= (y >> 18);  
		    index = (index + 1) % 624;  
		    return y;  
		}  
		function mt_rand(min, max) {  
		    return extract_number() % (max - min + 1) + min;  
		}
		this.random = function(min,max){
			var seed = new Date().getTime() * Math.random();
			initialize_generator(seed);
			return mt_rand(min,max);
		}
	}
	
	/**
	 * 梅森旋转方法Javascript代码实例
	 * 梅森旋转算法基于二进制字段上的矩阵线性递归。可以快速产生高质量的伪随机数，修正了古典随机数发生算法的很多缺陷。
	 * 这个算法通常使用俩个相近的变体，不同之处在于使用了不同的梅森素数。一个更新的和更常用的是MT19937,32位字长。还有一个变种是64位版的MT19937-64。
	 * 对于一个k位的长度，这个算法会在[0，2^k-1]的区间之间生成离散型均匀分布的随机数。
	 * 
	 */
	mersenneTwister = function(){};
    mersenneTwister.prototype = {
        MT : new Array(164),//create a length 624 array to store the state of the generator[int]
        idx: undefined,//[int]
        isInitialized : false,//[boolean]
        
        //Initialize the generator from a seed
        msInit:function(seed){
            var i,p;
            this.idx = 0;
            this.MT[0] = seed;
            for (i=1; i < 624; ++i) { 
                /* loop over each other element */  
                p = 1812433253 * (this.MT[i-1] ^ (this.MT[i-1] >> 30)) + i;  
                this.MT[i] = p & 0xffffffff; 
                /* get last 32 bits of p */  
            }  
            this.isInitialized = true;  
        },
        msRand:function(){  
            if (!this.isInitialized){  
                return 0;  
            } 
            if (this.idx == 0)  
                this.msRenerate();  

            var y = this.MT[this.idx];  
            y = y ^ (y >> 11);  
            y = y ^ ((y << 7) & parseInt("2636928640l"));  
            y = y ^ ((y << 15) & parseInt("4022730752l"));  
            y = y ^ (y >> 18);  

            this.idx = (this.idx + 1) % 624; /* increment idx mod 624*/  
            return y;  
        },
        msRenerate:function() {  
            var i;  
            var y;  
            for (i = 0; i < 624; ++i) {  
                y = (this.MT[i] & 0x80000000) +   
                        (this.MT[(i+1) % 624] & 0x7fffffff);  
                this.MT[i] = this.MT[(i + 397) % 624] ^ (y >> 1);  
                if (y % 2 != 0) { /* y is odd */  
                    this.MT[i] = this.MT[i] ^ parseInt("2567483615l");  
                }  
            }  
        },
        //random seed
        rseed:function(seed){  
            if(this.isInitialized){  
                return ;  
            }  
            this.msInit(seed);  
        },
        //random value
        rand:function(){  
            if(this.isInitialized == false){  
                return 0;  
            }  
            return this.msRand();  
        },
        //init
        _init:function(seed){  
            this.rseed(seed);  
        }  
    };
      
    
	$.extend(Math,{
		random1 : function(t1,t2,t3){//t1为下限，t2为上限，t3为需要保留的小数位  
		    function isNum(n){  
		        return /^\d+$/.test(n);  
		    }  
		    if(!t1 || (! isNum(t1)) ){t1=0;}  
		    if(!t2 || (! isNum(t2)) ){t2=1;}  
		    if(!t3 || (! isNum(t3)) ){t3=0;}  
		    t3 = t3>15?15:t3; // 小数位不能大于15位  
		    var ra = Math.random() * (t2-t1)+t1,du=Math.pow(10,t3);  
		    ra = Math.round(ra * du)/du;  
		    return ra;  
		},
		random2 : function(min,max){
			function rnd( seed ){
			    var seed = ( seed * 9301 + 49297 ) % 233280; //为何使用这三个数?
			    return seed / ( 233280.0 );
			};
			
			function rand(min,max){
			    var today = new Date(); 
			    var seed = today.getTime() * Math.random();
			    seed = rnd( seed );
			    seed = Math.ceil( seed * (max - min) ) + min;
			    return seed ;
			};
			return rand(min,max);
		},
		rand_range : function (min,max,exact){
	        var mt = new mersenneTwister();
	        var today = new Date(); 
	        var seed = today.getTime()* Math.random();
	        mt._init(seed);
	        if (arguments.length === 1){
	            max = min;
	            min = 0;
	        }
	        var seed_temp ="0."+mt.rand();
	        var range = min + ( (seed_temp ) *(max - min));
	        return exact === void(0) ? Math.round(range) : range.toFixed(exact);
	    },
		irandom : function(m,n){
			return Math.floor(Math.random()*(n)+m);
		},
		$random : function(min,max){
			var time_seed = new Date().getTime();
			var rand_seed = Math.irandom(min,max);
			var seed = parseInt(time_seed * rand_seed);
			var n = seed % max ;
			//log.info("random:" + ( n + min ));
			return n + min;
		},
		randomm : function(min,max){
			var rds = Array.random(min,max);
			var seed = Math.$random(min,max) - 1 ;
			return rds[seed];
		},
		seed : function(){
			
		}
	});
	$.extend(Array,{
		RANDOM_SEED_NUM : 8,
		random : function(f,t,MAX){
			var f= f || 1;
			var MAX = MAX || Number.MAX_VALUE;
			if(f < t){
				var tmp = [];
				tmp.staticsObj = [];
				var n = 0;
				while(tmp.length < t && n < MAX){
					tmp.put(Math.$random(f,t));
					n ++;
				}
				for(var i = f; i <= Array.RANDOM_SEED_NUM; i ++){
					var s1 = [];
					n = 0;
					while(s1.length < t && n < MAX){
						s1.put(tmp[Math.$random(f,t)-1]);
						n ++;
					}
					s1.reverse();
					//log.info(s1.join("-"));
					tmp = s1;
				}
				return tmp;
			}
		}
	});
	
	var WL = w.WL = function(){
		this.init();
	};
	$.extend(WL,{
		r_exclude : [],
		r_include : [],
		b_exclude : [],
		b_include : [],
		blue_series	:	function(){
			return Array.random(1,16).exclude(WL.b_exclude);
		},
		red_series	:	function(){
			return Array.random(1,33).exclude(WL.r_exclude);
		},
		gwl : function(){
			var wl = new WL();
			return wl;
		}
	});
	
	$.extend(WL.prototype,{
		w	:	WL,
		blue_ball	: 	0,
		red_ball	:	[],
		blue_series	: [],
		red_series	: [],
		init	: function(){
			with(this){
				red_ball = [];
				blue_series = WL.blue_series();
				red_series = WL.red_series()
				var r = 6;
				for(var i = 1; i <= r; i ++){
					//var ats = Array.random(0,red_series.length-1);
					var n = Math.$random(0,red_series.length);//ats[Math.$random(0,red_series.length-1)];
					//log.info(n);
					n = red_series.splice(n,1)[0];
					red_ball.push(n);
				}
				red_ball.bubbleSort();
				var b = Math.$random(0,blue_series.length);
				blue_ball = blue_series[b];
				if(!blue_ball){
					log.info(b)
				}
			}
		},
		$2String	:	function(){
			return this.red_ball.join('	') + "	" + this.blue_ball;
		}
	});
	
	var Color = function(){};
	var Ball = function(){};//color
	var RedBall = function(){};//1-33,6
	var BlueBall = function(){};//1-16,1
	var ball_class = {color:'red'};
	var color_class = {color_value : 'red'};
	var redBall_class = {
		color	:	'red',
		min	:	1,
		max	:	33,
		num	:	6
	}; 
	$.extend(RedBall.prototype,redBall_class);
	var blueBall_class = {
		color	:	'blue',
		min	: 	1,
		max	:	16,
		num :	1
	}
	$.extend(BlueBall.prototype,blueBall_class);
}(jQuery,window));		

		