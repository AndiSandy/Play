(function(w){
	
	var $key = function(e){
		function k(e){
			this.e = e;
			var KeyMap = {
				"Ctrl+Enter":function(e){
					var is = e.ctrlKey && e.which == 10;
					return is;
				},
				"Shit+Enter":function(e){
					var is = e.shiftKey && e.which == 13;
					return is;
				},
				"Enter":function(e){
					var enter = e.which == 13;
					return enter;
				},
				down : function(e){
					return e.keyCode == 40;
				},
				up : function(e){
					return e.keyCode == 38;
				},
				left : function(e){
					return e.keyCode == 37;
				},
				right : function(e){
					return e.keyCode == 39;
				},
				del : function(e){
					return e.keyCode == 46;
				}
			};
			var $k = this;
			$k.when = function(key,keyAction){
				var keyEvent = KeyMap[key];
				if(keyEvent && keyEvent(this.e)){
					keyAction.apply(this,[this.e]);
				}
				return this;
			};
		}
		return new k(e);
	};
	
	
	//翻页对象
	w.Pagination = function(total,pagesize,pageAction){
		var $page = this;
		//计算初始化数据
		$page.calculate = function(total,pagesize,pageAction){
			$.extend($page,{
				range : 5,
				pageAction : pageAction || $page.pageAction || function(){},//翻页action
				total : total || $page.total || 10 ,//总记录数
				pagesize : pagesize || $page.pagesize || 10,//每页记录数量
				page : 0//当前页码init 0
			});
			var totalpage = Math.ceil($page.total/$page.pagesize);
			$page.totalpage = totalpage;
			$page.calculatePage();
		};
		//计算页码范围
		$page.calculateRange = function(){
			$page.rangeList = [];
			var rangUp = Math.min(Math.ceil($page.range/2) + $page.page,$page.totalpage);
			var rangDown = Math.max(0,$page.page-Math.floor($page.range/2));
			for(var i = rangDown; i < rangUp; i++){
				$page.rangeList.push({int:i,page:(i+1),actived: i == $page.page});
			}
			//$page.rangeList.active($page.page);
		};
		//计算翻页数据
		$page.calculatePage = function(){
			$page.page = Math.max(0,$page.page);
			$page.page = Math.min($page.page,$page.totalpage-1);
			$page.start = $page.page * $page.pagesize;
			$page.end = ($page.page + 1) * $page.pagesize;
			if( $page.page == 0 ){
				$page.prev.disabled = true;
			}else{
				$page.prev.disabled = false;
			}
			if( $page.page == ($page.totalpage-1)){
				$page.next.disabled = true;
			}else{
				$page.next.disabled = false;
			}
			$page.calculateRange();
		};
		//跳转到指定页码
		$page.gotopage = function(page){
			$page.page = page;
			$page.calculatePage();
			$page.pageAction();
		};
		//前一页
		$page.prev = function(){
			--$page.page;
			$page.calculatePage();
			if(!$page.prev.disabled){
				$page.pageAction();
			}
		};
		//后一页
		$page.next = function(){
			++$page.page;
			$page.calculatePage();
			if(!$page.next.disabled){
				$page.pageAction();
			}
		};
		//初始化计算数据
		$page.calculate();
	};
	//数据表格
	w.Table = function(){
		this.list = [];
	};
	var $interval = setInterval;
	$interval.cancel = clearInterval;
	var $timeout = setTimeout;
	$timeout.cancel = clearTimeout;
	$.extend(Table.prototype,{
			$interval : $interval,
			$timeout : $timeout,
			length : 10,
			compare :function(a,b){
				var oa = a, ob = b;
				return oa == ob ? 0 : oa > ob ? 1 : -1;
			},
			//数据
			list :[],
			//操作
			operator : function(e){
				var $tab = this;
				var selectedIndex = this.list.selected();
				if(selectedIndex >= 0){
					console.info(e.keyCode);
					$key(e).when('down',function(e){
						$tab.list.down(selectedIndex);
						$(e.currentTarget).next().focus();
					}).when('up',function(e){
						$tab.list.up(selectedIndex);
						$(e.currentTarget).prev().focus();
					}).when('del',function(e){
						$tab.list.$remove();
						$(e.currentTarget).prev().focus();
					});
				}
			},
			//聚焦
			focus : function(index,$event){
				this.list.select(index);
			},
			//选中
			selected : function(index,$event){
				this.list.select(index);
				//$($event.currentTarget).focus();
			},
			//直到条件满足再执行
			until : function(time,callback,condition){
				$tab = this;
				if(condition()){
					callback();
				}else{
					var t = $tab.$interval(function(){
						if(condition()){
							callback(); 
							$tab.$interval.cancel(t);
						}
					}, time);
				}
			},
			random : function(){
				var wl = WL.gwl();
				wl.red_ball.push(wl.blue_ball);
				return wl.red_ball;
			},
			//添加数据
			add : function(data){
				this.list.push(data||this.random());
			},
			remove : function(){
				this.list.$remove();
			},
			//排序
			sort : function(){
				var $tab = this;
				function sort(array,compare) {
			        // 喵的，写到这个才发现yield是多么好啊
			        for (var i = 0; i < array.length; i++) {
			            for (var j = array.length-1; j > 0; j--) {
			            	var order = compare ? compare(array[j], array[j - 1]) : (array[j] < array[j - 1]);
			                if ( order < 0 ) {
			                	array.select(j-1);
			                    var temp = array[j - 1];
			                    array[j - 1] = array[j];
			                    array[j] = temp;
			                    console.info(j+""+(j-1));
			                    return false;
			                }
			            }
			        }
			        return true;
			    }
				$tab.until(1000, function(){
				}, function(){
					return sort($tab.list,$tab.compare);
				});
			},
			jGravity : function(){
				$('.lottery').jGravity({ // jGravity works best when targeting the body
	                target: '.ball_red,.ball_blue', // Enter your target critera e.g. 'div, p, span', 'h2' or 'div#specificDiv', or even 'everything' to target everything in the body
	                ignoreClass: 'ignoreMe', // Specify if you would like to use an ignore class, and then specify the class
	                weight: 25, // Enter any number 1-100 ideally (25 is default), you can also use 'heavy' or 'light'
	                depth: 5, // Enter a value between 1-10 ideally (1 is default), this is used to prevent targeting structural divs or other items which may break layout in jGravity
	                drag: true // Decide if users can drag elements which have been effected by jGravity
	            });
			}
	});
}(window));	

	//Array扩展
	Array.prototype.swap = function(index0,index1){
		var t = this[index0];
		this[index0] = this[index1];
		this[index1] = t;
		return this;
	};
	Array.prototype.up = function(index){
		if( index > 0){
			this.swap(index-1,index);
		}
		return this;
	};
	Array.prototype.down = function(index){
		if( index < this.length-1){
			this.swap(index,index+1);
		}
		return this;
	};
	Array.prototype.select = function(index){
		if( index >= 0 && index < this.length){
			for(var i = 0; i < this.length; i ++){
				this[i].selected = false;
			}
			this[index].selected = true;
		}
		return this;
	};
	Array.prototype.active = function(index){
		if( index >= 0 && index < this.length){
			for(var i = 0; i < this.length; i ++){
				this[i].actived = false;
			}
			this[index].actived = true;
		}
		return this;
	};
	Array.prototype.selected = function(){
		var index = -1;
		for(var i = 0; i < this.length; i ++){
			if(this[i].selected){
				index = i;
			}
		}
		return index;
	};
	Array.prototype.$selected = function(){
		var index = this.selected();
		return this[index];
	};
	Array.prototype.$remove = function(){
		var index = this.selected();
		if(index >= 0){
			this.splice(index,1); 
		}
		return this;
	};
	Array.prototype.putAll = function(array){
		for(var i=0; i < array.length; i++){
			this.push(array[i]);
		}
		return this;
	};
	
	Array.prototype.setInt = function(s,e){
		for(var i = s; i <= e; i++){
			this.push(i);
		}
		return this;
	};
	Array.prototype.create = function(s,e,int){
		for(var i = s; i <= e; i++){
			this[i]=int;
		}
		return this;
	};
	Array.prototype.statistics = function(arr){
		for(var i = 0; i < arr.length; i++){
			this[parseInt(arr[i])] += 1 ;
		}
		return this;
	};
	
	$.extend(Array.prototype,{
		staticsObj : [],
		statics : function(elm){
			var sts = this.staticsObj[elm];
			if(sts == null){
				this.staticsObj[elm] = 0;
			}
			this.staticsObj[elm] ++;
		},
		copy : function(arr){
			for(var i = 0; i < arr.length; i ++){
				this[i] = arr[i];
			}
		},
		random : function(min,max){
			var _this = this;
			var arr = Array.random(min,max);
			_this.copy(arr);
			return _this;
		},
		/**
		 * 数组中查找指定元素
		 * @param {Object} elm
		 * @memberOf {TypeName} 
		 * @return {TypeName} 
		 */
		indexOf : function(elm){
			var at = -1;
			for(var i = 0; i < this.length; i ++){
				if(this[i] == elm){
					at = i;
					break;
				}
			}
			return at;
		},
		/**
		 * 放入数组中,如果不存在的话
		 * @param {Object} em
		 * @memberOf {TypeName} 
		 */
		put : function(elm){
			var at = this.indexOf(elm);
			this.statics(elm);
			if(at < 0){
				this.push(elm);
			}
			return this;
		},
		/**
		 * 从数组中移除指定元素
		 * @param {Object} elm
		 * @memberOf {TypeName} 
		 */
		remove : function(elm){
			var at = this.indexOf(elm);
			if(at > 0){
				this.splice(at,1);
			}
			return this;
		},
		/**
		 * 排除数组中的元素
		 * @param {Object} arr
		 * @memberOf {TypeName} 
		 */
		exclude : function(arr){
			for(var i = 0; i < arr.length; i ++){
				var at = this.indexOf(arr[i]);
				if(at > 0){
					this.remove(arr[i]);
				}
			}
			return this;
		},
		/**
		 * 包含指定元素
		 * @param {Object} arr
		 * @memberOf {TypeName} 
		 */
		include : function(arr){
			for(var i = 0; i < arr.length; i ++){
				var at = this.indexOf(arr[i]);
				if(at < 0){
					this.put(arr[i]);
				}
			}
			return this;
		}
	});
	