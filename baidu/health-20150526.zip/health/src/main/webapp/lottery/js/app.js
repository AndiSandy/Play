var lotteryModule = angular.module("lottery", ["chart.js"]);
/*lotteryModule.directive('ngKeydown', function($parse){
	  return function(scope, element, attr){
	    var fn = $parse(attr['ngBlur']);
	    $(element).on('keydown', function(event){
	      fn(scope, {$event: event});
	    });
	  };
});*/
angular.module("lottery").controller("NavCtrl", ["$scope", function($scope) {
    $scope.items = [
		{
		    title: "history-chart",
		    url: "partials/history-chart.html"
		},
		{
		    title: "charts",
		    url: "partials/charts.html"
		},
		{
		    title: "history",
		    url: "partials/history.html"
		},
	    {
	        title: "test",
	        url: "partials/test.html"
	    },
	    {
	        title: "lottery",
	        url: "partials/lottery.html"
	    }
    ];

    $scope.selectedItem = $scope.items[0];

    $scope.change = function(item) {
        $scope.selectedItem = item;
    };
}]);