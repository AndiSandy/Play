angular.module("lottery").controller("history", ["$scope", "$timeout","$interval","$http", function ($scope,$timeout,$interval,$http) {
	
	$data.$http = $http;
	
	var table = $.extend(new Table(),{
		length : 10,
		pagination : new Pagination(),
		$interval : $interval,
		$scope : $scope,
		compare : function(a,b){
			var oa = a.blue, ob = b.blue;
			return oa == ob ? 0 : oa > ob ? 1 : -1;
		},
		add : function(data){
			var d = data || this.random();
			d = {qi:'2015001',red1:d[0],red2:d[1],red3:d[2],red4:d[3],red5:d[4],red6:d[5],blue:d[6]};
			this.list.push(d);
		},
		//加载数据
		load : function(start,success){
			$tab = this;
			$data.http({
				table : 'health_t_l_lottery',
				order : 'qi asc',
				start : start,
				size : $tab.length
			},function(json){
				//console.info(json);
				success && success(json);
				if(json.success){
					$tab.list.length = 0;
					$tab.list.putAll(json.data);
				}
			});	
		},
		//初始化
		init : function(){
			var $tab = this;
			$tab.load(0,function(json){
				$tab.pagination.calculate(json.total, $tab.length, function(){
					$tab.load(this.start);
				});
			});
		},
		styles : [{className:'skin-default',name:'默认'},{className:'skin-normal',name:'正常',selected:true},{className:'skin-baidu',name:'baidu'}]
	});
	$scope.table = table;
	table.init();
	
	/*$scope.$watch('table.list', function(newValue, oldValue) {
		console.info('watch...');
		if (newValue === oldValue) { return; }
		$scope.updated++;
	}, true);*/

	
	var i = 0;
	/*
	table.until(1000, function(){
		//执行一次
	}, function(){
		table.add(table.random());
		i ++;
		return !(i < table.length);
	});*/
}]);