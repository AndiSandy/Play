angular.module("lottery").controller("history-chart", ["$scope", "$timeout","$interval","$http", function ($scope,$timeout,$interval,$http) {
	
	$data.$http = $http;
	
	var PAGE = 10;
	var table = $.extend(new Table(),{
		chat_data : [],
		length : PAGE,
		pagination : new Pagination(null,PAGE,null),
		$interval : $interval,
		$scope : $scope,
		compare : function(a,b){
			var oa = a.blue, ob = b.blue;
			return oa == ob ? 0 : oa > ob ? 1 : -1;
		},
		add : function(data){
			var d = data || this.random();
			d = {qi:'2015001',red1:d[0],red2:d[1],red3:d[2],red4:d[3],red5:d[4],red6:d[5],blue:d[6]};
			this.list.push(d);
		},
		//加载数据
		load : function(start,success){
			$tab = this;
			$data.http({
				table : 'health_t_l_lottery',
				order : 'qi asc',
				start : start,
				size : $tab.pagination.pagesize
			},function(json){
				//console.info(json);
				success && success(json);
				if(json.success){
					$tab.chat_data.length = 0;
					for(var i=0; i < json.data.length; i ++){
						var oa = json.data[i];
						$tab.chat_data.push([oa.red1,oa.red2,oa.red3,oa.red4,oa.red5,oa.red6,oa.blue]);
					}
					chart.statistics();
					$tab.list.length = 0;
					$tab.list.putAll(json.data);
				}
			});	
		},
		//初始化
		init : function(){
			var $tab = this;
			$tab.load(0,function(json){
				$tab.pagination.calculate(json.total, $tab.length, function(){
					$tab.load(this.start);
				});
			});
		},
		styles : [{className:'skin-default',name:'默认'},{className:'skin-normal',name:'正常',selected:true},{className:'skin-baidu',name:'baidu'}]
	});
	$scope.table = table;
	table.init();
	
	var chart = {
		labels : ['red1', 'red2', 'red3', 'red4', 'red5', 'red6', 'blue'],
		data : table.chat_data,
		red :{
			labels : [].setInt(0,33).slice(1,34),
			data : [[].create(0,33,1).slice(1,34)]
		},
		blue :{
			labels : [].setInt(0,16).slice(1,17),
			data : [[].create(0,16,1).slice(1,17)]
		},
		statistics : function(){
			var $chart = this;
			var red = [].create(0,33,1);
			var blue = [].create(0,16,1);
			for(var i =0; i < table.chat_data.length; i++){
				var ball = table.chat_data[i];
				red.statistics(ball.slice(0,6));
				blue.statistics(ball.slice(6,7));
			}
			$chart.red.data = [red.slice(1,34)];
			$chart.blue.data = [blue.slice(1,17)];
		}
	};
	$scope.chart = chart ;
	
}]);