(function($){
	
	/*-----------------------
	 * 日志对象
	 -----------------------*/
	var Logger = window.Logger =  function(package){this.init(package);};
	Logger.getLogger = function(package){
			return new Logger(package);
	}
	var log_impl = {
		package : 'javascript.lang.util.js',
		apis	:['info','warn','error','debug','log','clear','assert'],
		exist	: function(s){
			return typeof s != 'undefined';
		},
		existSysConsole	: typeof console != 'undefined',
		init : function(package){
			var log = this;
			log.package = package || log.package;
			var console = {};
			if(this.existSysConsole){
				console = window.console;
			}
			this.console = console;
			for(var i =0; i < this.apis.length; i ++){
				var apiName = this.apis[i];
				var api = console[apiName];
				if(!this.exist(api)){
					console[apiName] = api = $.noop;
				}
				this[apiName] = function(text){
					var time = new Date().f();
					var log_text = "["+time+"]["+log.package+"]	"+text;//[]
					var func = arguments.callee.api;
					try{
						func(log_text);
					}catch(e){
						//alert(e);
						func.call(console,log_text);
					}
				}
				this[apiName].api = api;
			}
		}
	}
	$.extend(Logger.prototype,log_impl);
	$.Logger = Logger;
	$.logger = new Logger();
	$.log = new Logger("javascript.lang.util.js");
	
	String.prototype.trim = function(){
		return this.replace(/^\s*|\s*$/img,'');
	}
	String.prototype.isEmpty = function(){
		var s = this.trim();
		return s == "" ;
	}
	function nul(obj){
		return obj == null;	
	} 
	Object.nul = nul;
	
	String.Null = function(s){
		return s == null || s.isEmpty();	
	}
	
	if(!$) return;
	
	/*-----------------------
	 * surface 对象
	 -----------------------*/
	var surface = $.surface = {};
	/**
	 * 是否是ie
	 * @param {Object} isIE
	 */
	var isIE = navigator.appVersion.toLowerCase().indexOf("msie") != -1;
	/**
	 * 是否是ipad
	 * @param {Object} isIpad
	 */
	var isIpad = navigator.platform.toLowerCase() == "ipad";
	
	surface.isIE = isIE;
	surface.isIpad = isIpad;
	
	
	/*-----------------------
	 * request请求对象
	 -----------------------*/
	$.request = ( new function(){
		var console = window.console || {};
		console.info = console.info || function(a){
			alert(a);
		}
		this.parameters = {};
		this.init = function(search){
			var search = search || '';
			if(search.indexOf('?') == 0){
				search = search.substring(1);
			}
			var pa = search.split("&");
			for(var i = 0; i < pa.length; i ++){
				var kv = pa[i].split("=");
				this.parameters[kv[0]||''] = kv[1]||'';
			}
		}
		this.parameters = {};
		this.get = function(name){
			return this.parameters[name || ''] || '' ;
		}
		this.toString = function(){
			var string = "";
			for(var a in this.parameters){
				string += a + "-" + this.parameters[a] + "\n";
			}
			console.info(string);
		}
		var search = location.search.substring(1);
		this.init(search);
	});
	
	$.string = (new function(){
		this.fill = "..";
		this.show = function(s,length){
			var s = s || '';
			if(length > 0 && s.length > length){
				s = s.substring(0,length) + this.fill;
			}else if(s == null){
				s = "";
			}
			return $.trim(s);
		}
	});
	
	$.helper = (new function(){
		//var img_regex = //img;
		this.tableKey = function(num){
			var table = "\t";
			var s = "";
			for(var i = 0; i < num; i ++){
				s += table;
			}
			return s;
		}
		this.toString = function(config,level){
			var level = level || 0;
			var tableKey = this.tableKey(level);
			if(config){
				var s = "";
				for(var attr in config){
					var cv = config[attr];
					
					var isobj = false;
					try{
						isobj = $.isPlainObject(cv);
					}catch(e){
						
					}
					if(isobj){
						s += tableKey + attr + "\n" +this.toString(cv,level + 1);
					}else if($.isArray(cv)){
						var sa = attr + "=[";
						for(var i = 0; i < cv.length; i ++){
							var ca = cv[i];
							if( $.isPlainObject(ca)){
								s += "\n"+tableKey +this.toString(ca,level + 1);
							}else if($.isArray(ca)){
								s += "\n"+tableKey +this.toString(ca,level + 1);
							}else if($.isFunction(ca)){
								sa += i + "=[function],";	
							}else{
								sa += i + "="+ca+",";
							}
						}
						sa += "];\n";
						s += tableKey + sa;
					}else if($.isFunction(cv)){
						s += tableKey + attr + "=[function];\n";		
					}else{
						s += tableKey + attr + "=" + cv + ";\n";
					}
				}
				return s;
			}
		}
		this.random = function(max){
			var max = max || 0;
			var timesmap = new Date().getTime();
			var seed = Math.random() * timesmap;
			var r = max > 0 ? seed % max : seed;
			r = window.parseInt(r);
			return r;
		}
	});
	
	/*-----------------------
	 * ajax加载内容
	 -----------------------*/
	$.loadPage = function(src,p,cb){
		var target = this;
		$.post(src,p,function(html){
			cb.call(target,html);
		});
	}
	/*-----------------------
	 * 获取input参数
	 -----------------------*/
  	$.fn.getParameters = function(keys){
  		var p = {};
  		var keys = keys || [];
  		for(var i=0; i < keys.length; i ++){
  			var key = keys[i] || '';
  			var val = $.string.show($("input[name="+key+"]",this).val());
  			p[key] = val;
  		}
  		return p;
  	}
  	
  	
  	/*-----------------------
	 * 日期格式化d.f("yyy-MM-dd hh:mm:ss:SS EEE")
	 -----------------------*/
  	var rs = [
  		{name:'y',y:{regex:/(y+)/,getapi:'getYear',formatter:function(v){
  			if(v < 2000){
  				return 1900 +v;
  			}
  			return v;
  		},pad:'pad4reverse'}},
  		{name:'M',M:{regex:/(M+)/mg,getapi:'getMonth',pad:'pad',formatter:function(v){return v+1;}}},
  		{name:'d',d:{regex:/(d+)/mg,getapi:'getDate',pad:'pad'}},
  		{name:'h',h:{regex:/(h+)/mg,getapi:'getHours',pad:'pad'}},
  		{name:'m',m:{regex:/(m+)/mg,getapi:'getMinutes',pad:'pad'}},
  		{name:'s',s:{regex:/(s+)/mg,getapi:'getSeconds',pad:'pad'}},
  		{name:'S',S:{regex:/(S+)/mg,getapi:'getMilliseconds',pad:'pad'}},
  		{name:'E',E:{regex:/(E+)/mg,getapi:'getDay',formatter:function(v){
  			var weeks = this.weeks[Date.lang || this.lang];
  			return weeks[v];
  		},pad:'pad'}}
  	]
  	var d_static_impl = {
  		lang	: 'zh',
  		f : function(f){
  			return new Date().f(f);
  		}
  	}
  	var d_ipml = {
  		weeks: {en:["Sunday","Monday","Thuesday","Wednesay","Tursday","Friday","Saturday"],zh:["星期天","星期一","星期二","星期三","星期四","星期五","星期六"]},
  		lang : 'en',
  		rs : rs,
  		dateObj : {},
  		isInit : false,
  		needpad	: true,
  			/* 查表法(过程式版本)  by aimingoo */
		pad : function() {
		  var tbl = [];
		  return function(num, n) {
			var snum = num.toString();
		    var len = n - snum.length;
		    if (len <= 0) {
		    	snum = snum.substring(0,n);
		    	return snum;
		    };
		    if (!tbl[len]) tbl[len] = (new Array(len+1)).join('0');
		    return tbl[len] + num;
		  }
		}(),
		pad4reverse : function() {
		  var tbl = [];
		  return function(num, n) {
			var snum = num.toString();
		    var len = n - snum.length;
		    if (len <= 0) {
		    	if($.isNumeric(num)){
		    		snum = snum.split('').reverse().join('');
			    	snum = snum.substring(0,n);
			    	snum = snum.split('').reverse().join('');
		    	}else{
		    		snum = snum.substring(0,n);
		    	}
		    	return snum;
		    };
		    if (!tbl[len]) tbl[len] = (new Array(len+1)).join('0');
		    return tbl[len] + num;
		  }
		}(),
  		initDateObj : function(){
  			for(var i =0;i < this.rs.length; i ++){
  				var eld = this.rs[i];
  				var v = this[eld[eld.name].getapi]();
  				var f = eld[eld.name].formatter;
  				if(f){
  					v = f.call(this,v);
  				}
  				eld[eld.name].text = v;
  				this.dateObj[eld.name] = eld[eld.name];
  			}
  			this.isInit = true;
  		},
  		formatter : 'yyyy-MM-dd hh:mm:ss',
  		f:function(formatter){
  			var d = this;
  			if(!this.isInit) this.initDateObj();
  			var ff = formatter || this.formatter;
  			for(var i = 0; i < this.rs.length; i ++){
  				var obj = this.rs[i];
  				var regex = obj[obj.name].regex;
  				var text = obj[obj.name].text;
  				var pad = obj[obj.name].pad;
  				ff = ff.replace(regex,function(s){
  					return d[pad](text,s.length);
  				});
  			}
  			return ff;
  		}
  	}
  	$.extend(Date.prototype,d_ipml);
  	$.extend(Date,d_static_impl);
  	$.date = Date;
  	
  	
  	
  	$.fn.$outerHeight = function(){
  		var h = $(this).outerHeight();
  		var cssMarginTop = $(this).css("margin-top");
  		var mt = parseInt( cssMarginTop ) || 0  ;
  		var cssMarginBottom = $(this).css("margin-bottom");
  		var mb = parseInt( cssMarginBottom )  || 0;
  		return mt + h + mb
  	}
  	$.fn.$outerWeight = function(){
  		var h = $(this).outerWidth();
  		var ml = parseInt( $(this).css("margin-left") ) || 0;
  		var mr = parseInt( $(this).css("margin-right") )|| 0 ;
  		return ml + h + mr
  	}
  	$.fn.processText = function(){
		var text = $(this).html();
		$.log.info("preocess text..."+text)
		text = Template.preProcess(text);
		text = Template.preProcess(text);
		$.log.info("preocess text..."+text)
		if(/&#\d{5};/img.test(text)){
			//$.log.info("preocess text html...")
			$(this).html(text);
		}
	}
  	
  	
  	/*-----------------------
	 * 工具
	 -----------------------*/
  	Math.rad2ang = function(rad){
  		//ang = PI.rad / 180;
  		var rad = parseFloat(rad);
  		var ang = 180 / Math.PI  * rad ;
  		return ang;
  	}
  	Math.ang2rad = function(ang){
  		//PI/180 = rad / ang;
  		var ang = parseFloat(ang);
  		var rad = Math.PI/180 * ang ;
  		return rad;
  	}
  	
  	$.fn.fitRibbon = function(ang){
		var ribbon = $(this);
		var bwidth = ribbon.width();
		var bheight = ribbon.height();
		var radA = Math.ang2rad(ang);
		var c = bwidth / 2;
		var b = Math.cos(radA) * c;
		var off = (bheight/2) * Math.sin(radA);
		var offx = c - b - off;
		var offy = Math.sin(radA) * c;
		offy = offy + (bheight/2) - off;
		//$.log.info("\noffx:"+offx+"	offy:"+offy + "	off:" + off);
		ribbon.css("top",-offy+"px");
		ribbon.css("left",-offx+"px")
	}
  	
  	/*-----------------------
	 * 需要回收内存的收集容器
	 * {name:'',obj:''} obj需时间finalize方法来释放资源
	 -----------------------*/
  	$.surface.trash = [];
	
}(jQuery))