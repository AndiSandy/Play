angular.module("webadmin").controller("quserMgrCtrl", ["$scope", "$timeout","$interval","$http", function ($scope,$timeout,$interval,$http) {
	
	$data.$http = $http;
	var PAGE = 10;
	var table = $.extend(new Table(),{
		fields : [
		          {name:'qq号',field:'qnum'},
		          {name:'昵称',field:'card'},
		          {name:'名称',field:'nick'},
		          {name:'性别',field:'gender',format:function(v){
		        	  return v == "1" ? '男': v == '0' ? '女' : '未知';
		          }},
		          {name:'所在群号',field:'gnum'}
		],
		length : PAGE,
		pagination : new Pagination(null,PAGE,null),
		$interval : $interval,
		$scope : $scope,
		compare : function(a,b){
			var oa = parseInt(a.gnum), ob = parseInt(b.gnum);
			return oa == ob ? 0 : oa > ob ? 1 : -1;
		},
		valid : function(){
			var o = this.selectedObj;
			return o.qnum && o.card && o.nick && o.gender && o.gnum;
		},
		modify : function(){
			if(this.status == 'create'){
				this.list.push(this.selectedObj);
			}
			this.cancel();
		},
		add : function(data){
			var d = data || this.random();
			d = {qi:'2015001',red1:d[0],red2:d[1],red3:d[2],red4:d[3],red5:d[4],red6:d[5],blue:d[6]};
			this.list.push(d);
		},
		//加载数据
		load : function(start,success){
			$tab = this;
			$data.http({
				table : 'health_t_q_user',
				order : 'gnum asc',
				start : start,
				size : $tab.pagination.pagesize
			},function(json){
				//console.info(json);
				success && success(json);
				if(json.success){
					$tab.list.length = 0;
					$tab.list.putAll(json.data);
				}
			});	
		},
		//初始化
		init : function(){
			var $tab = this;
			$tab.load(0,function(json){
				$tab.pagination.calculate(json.total, $tab.length, function(){
					$tab.load(this.start);
				});
			});
		}
	});
	$scope.table = table;
	table.init();
	
}]);