angular.module("webadmin").controller("voteMgrCtrl", ["$scope", "$timeout","$interval","$http", function ($scope,$timeout,$interval,$http) {
	$data.$http = $http;
	var PAGE = 10;
	var table = $.extend(new Table(),{
		fields : [
		          {name:'投票主题',field:'theme'},
		          {name:'投票类型',field:'type',format:function(v){
		        	  return v == 0 ? '单选':'多选';
		          }},
		          {name:'创建时间',field:'crtime',format:function(v,o){
		        	  o.crtime = v.time || v;
		        	  return new Date(v.time||v).f();
		          }}
		],
		length : PAGE,
		pagination : new Pagination(null,PAGE,null),
		$interval : $interval,
		$scope : $scope,
		selectedObj : {
			crtime:new Date().getTime(),
			options : []
		},
		//比较器
		compare : function(a,b){
			var oa = parseInt(a.gnum), ob = parseInt(b.gnum);
			return oa == ob ? 0 : oa > ob ? 1 : -1;
		},
		status : 'create',
		//创建投票对象
		create : function(){
			this.selectedObj = {
					crtime:new Date().getTime(),
					options : []
			};
			this.status = "create";
		},
		//验证是否填写内容
		valid : function(){
			var o = this.selectedObj;
			return o.theme && o.type;
		},
		//修改投票
		modify : function(){
			var $t = this;
			if(this.status == 'create' || this.status == 'selected'){
				var o = this.selectedObj;
				this.save(o,function(json){
					if(json.detail.data && json.detail.data.length > 0){
						o.tid = json.detail.data[0].tid;
					}
					if(this.status == 'create'){
						$t.list.push(o);
					}
				});
			}
			//this.cancel();
		},
		add : function(data){
		},
		//存储数据
		save : function(d,success){
			$tab = this;
			$data.save({
				table : 'health_t_vote_theme',
				order : 'tid asc',
				id : 'tid',
				data : [d],
				mapper : {tid:'tid',theme:'theme',type:'type',crtime:'crtime'},
				parser : {crtime:'long2date'}
			},function(json){
				//console.info(json);
				success && success(json);
				console.info(json);
			});	
		},
		//选中
		selected : function(index,$event){
			$tab = this;
			this.list.select(index);
			this.selectedObj = this.list.$selected();
			this.status = "selected";
			if(!this.selectedObj.options || this.selectedObj.options.length == 0){
				this.selectedObj.options = [];
				$tab.loadOption(this.selectedObj,function(json){
					if(json.data){
						$tab.selectedObj.options.putAll(json.data);
					}
				});
			}
		},
		//新建选项
		createOption : function(){
			var o = this.selectedObj;
			o.options.push({tid:o.tid});
		},
		//移除选项
		saveOption : function(o,success){
			$tab = this;
			$data.save({
				table : 'health_t_vote_options',
				data : [o],
				id : 'oid'
			},function(json){
				//console.info(json);
				success && success(json);
				console.info(json);
			});	
		},
		//加载选项
		loadOption:function(o,success){
			$tab = this;
			$data.http({
				table : 'health_t_vote_options',
				order : 'oid asc',
				condition : 'tid =' + o.tid
			},function(json){
				//console.info(json);
				success && success(json);
			});	
		},
		//加载数据
		loadVote : function(start,success){
			$tab = this;
			$data.http({
				table : 'health_t_vote_theme',
				order : 'tid asc',
				id : 'tid',
				start : start,
				size : $tab.pagination.pagesize
			},function(json){
				//console.info(json);
				success && success(json);
				if(json.success){
					$tab.list.length = 0;
					$tab.list.putAll(json.data);
				}
			});	
		},
		//初始化
		init : function(){
			var $tab = this;
			$tab.loadVote(0,function(json){
				$tab.pagination.calculate(json.total, $tab.length, function(){
					$tab.loadVote(this.start);
				});
			});
		}
	});
	$scope.table = table;
	table.init();
}]);