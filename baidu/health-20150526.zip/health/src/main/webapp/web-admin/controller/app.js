var lotteryModule = angular.module("webadmin", ["chart.js"]);
angular.module("webadmin").controller("appCtrl", ["$scope", function($scope) {
    
	$scope.items = [
		{
		    title: "投票管理",
		    ctrl: "voteMgr.js",
		    url: "html/voteMgr.html"
		},
		{
		    title: "群管理",
		    ctrl: "qgroupMgr.js",
		    url: "html/qgroupMgr.html"
		},
		{
		    title: "群qq用户管理",
		    ctrl: "quserMgr.js",
		    url: "html/quserMgr.html"
		}
    ];
	
    $scope.selectedItem = $scope.items[0];
    $scope.change = function(item) {
        $scope.selectedItem = item;
    };
    
}]);