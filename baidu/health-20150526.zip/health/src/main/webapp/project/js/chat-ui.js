/**
 * chat-ui 聊天ui
 */
define('chat-ui',['jquery','utils'],function(jquery,utils){
	
	var log = new Logger('health.chat.ui');
	var ui = {
			UserList : {
				model : {
					//user-list:[{nickname,sessionid,username}]
				},
				view :{
					//nickname|username
					//sessionid
				},
				controller : {
					//add	
					//update
					//delete
				}
			}
	};
	return ui;
});


