//console.info("加载成功...");
require.config(require_config);

require(['bootstrap','jquery','passport','browser','jquery.md5'], function (doc,$,passport,Browser){
	
	var debug_server = 'debug/browser.json';
	$(document).one('click',"[rel=debug]",function(){
		console.info('browser');
		passport.ensureLogin(function(msg){
			dialog.alert.success.show("用户已登录!");
			$.post(debug_server,{screen:getSize()},function(msg){
				console.info(msg);
			});
		},function(msg){
			
		});
		
	});
	
	console.info(Browser());
	
});