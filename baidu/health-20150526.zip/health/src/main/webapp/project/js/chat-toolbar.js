define('chat-toolbar',['jquery','utils'],function($){
	var setting = {
			_public_ : {
				index_url : '/health/'
			},
			el : {
				back : '[rel=back]',
				index: '[rel=index]'
			}
	};
	var ChatToolBar = _defineClass_({
		constructor : function(setting){
			this.$setting(setting);
			this.initilize();
		},
		_public_:{
			initilize : function(){
				this.$el();
				this.back.click(function(){
					history.back();
				});
				this.index.click(function(){
					location.href = '/health/';
				});
			}
		}
	});
	var chatToolbar = new ChatToolBar(setting);
	
	return ChatToolBar;
});