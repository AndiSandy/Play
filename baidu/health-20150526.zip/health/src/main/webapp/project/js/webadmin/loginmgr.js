define('loginmgr',['jquery','dialog','KeyEvent'],function($,dialog,KeyEvent){
	
	var log = new Logger("health.webadmin.LoginMgr");
	var setting = {
			_public_ :{
				login_url : 'secure/slogin.json',
				login_jsp : 'slogin.jsp',
				logout_url : 'secure/slogout.json',
				dashboard_url : 'webadmin/dashboard.php'
			},
			//控件选择器
			el : {
				username : '[name=username]',
				password : '[name=password]',
				loginBtn : '[rel=login]',
				rememberMe : '[name=rememberMe]',
				logoutBtn : '[rel=logout]',
				$login : '[name=loginFrm_login]',
			},
			//表单
			frm : {
				username : '[name=username]',
				password : '[name=password]',
			},
			//控件元素
			elm : {}
	};
	
	var LoginMgr = function(_setting_){
		this.setting = $.extend({},setting,_setting_ ||{});
		this.$el();
		this.context = this.setting.context || this.$login;
		this.$frm();
		//this.initilize();
	};
	
	LoginMgr._static_ = {
			COOKIE_USERNAME : 'cookie-login-username',
			COOKIE_REMEMBER : 'cookie-login-rememberMe'
	};
	//登录管理
	LoginMgr._impl_ = {
		initilize : function(){
			var mgr = this;
			//加载自动记忆用户名功能
			this.$el();
			mgr.$frm();
			var remenberMe = $.coookie().g(LoginMgr.COOKIE_REMEMBER);
			if(remenberMe && remenberMe == 'true'){
				var username = $.coookie().g(LoginMgr.COOKIE_USERNAME);
				this.username.val(username);
				this.rememberMe.attr('checked',true);
			}
			
			this.bindEvent();
		},
		bindEvent : function(){
			var mgr = this;
			//绑定登录按钮
			$(mgr.context || document).on('click',this.setting.el.loginBtn,function(){
				mgr.read();
				var username = mgr.frm.username.trim();
				var password = mgr.frm.password.trim();
				if(username != '' && password !=''){
					mgr.login();
				}else{
					log.info('用户名或密码为空!!!');
					dialog.alert.warning.show('用户名或密码为空!!!');
				}
				mgr.remember();
			});
			$(document).on('click',this.setting.el.logoutBtn,function(e){
				mgr.logout();
				e.preventDefault();
			});
			
			mgr.context.keyEvent('Enter',function(e){
				mgr.loginBtn.click();
			});
		},
		login : function(){
			var mgr = this;
			mgr.$frm();
			$.post(this.login_url,this.frm,function(msg){
				log.info(msg);
				if(msg.success){
					//mgr.success.removeClass("hidden").find(".text").text(msg.txt);
					if(this.callback){
						this.callback(msg);
					}else{
						$.timmer.t('health.webadmin.slogin',3000,function(){
							location.href = mgr.dashboard_url;
						});
					}
					dialog.alert.success.show(msg.txt);
				}else{
					dialog.alert.warning.show(msg.txt);
					//mgr.warning.removeClass("hidden").find(".text").text(msg.txt);
				}
			},'json');
		},
		logout : function(){
			var mgr = this;
			$.get(this.logout_url,function(msg){
				log.info(msg);
				dialog.alert.success.show(msg.txt,function(){
					location.href = mgr.login_jsp;	
				});
			},'json');
		},
		remember : function(){
			if(this.rememberMe.is(':checked') && this.username.val().trim() != ''){
				$.coookie().s(LoginMgr.COOKIE_USERNAME,this.username.val());
				$.coookie().s(LoginMgr.COOKIE_REMEMBER,true);
			}else{
				$.coookie().s(LoginMgr.COOKIE_REMEMBER,false);
			}
		}
	};
	return defineClass(LoginMgr);
});

