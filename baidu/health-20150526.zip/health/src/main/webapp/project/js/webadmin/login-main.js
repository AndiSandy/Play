//加载配置
require.config(require_config);
require(['jquery','loginmgr','passport','dialog'], function ($,LoginMgr,passport,dialog){
	
	$("[data-dismiss=hiddeen]").click(function(){
		$(this).parent(".alert").addClass("hidden");
	});
	var log = new Logger("health.webadmin.slogin");
	log.info("login pae is loaded!");
	var loginMgr = new LoginMgr();
	loginMgr.initilize();
	passport.ensureLogin(function(){
		dialog.alert.success.show("用户已登录!");
		$.timmer.t('health.webadmin.slogin',3000,function(){
			location.href = passport.dashboard_url;
		});
	});
	
});
