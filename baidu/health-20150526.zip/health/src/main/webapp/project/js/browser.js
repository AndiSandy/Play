define('browser',['utils'],function(){
	
	function Browser(ua){
		
		//prepare
		String.prototype.explain = function(o){
			var _eval_ = function(exp){
				return eval("("+exp+")");
			};
			//变量替换
			String.prototype.exp = function(o){
				var regexp_variable = /\{([^}]+)\}/g;
				return this.replace(regexp_variable,function(index,value){
					var v = o[value] || value ;
					return v;
				});
			};
			//变量解析
			function explain(o){
				for(var attr in o){
					o[attr] = o[attr].exp(o); 
					//console.info(attr + "=" + o[attr]);
				}
			}
			//解析变量
			explain(o);
			return _eval_(this.exp(o));
		};
		
		//function
		var isstring = function(string){
			return typeof string === 'string';
		},
		boolean = function(b){
			return function(){
				return b;
			};
		},
		extend = function(){
			if(arguments.length > 2){
				var o = arguments[0];;
				var args = [].slice.apply(arguments,[1,arguments.length]);
				for(var i = 0; i< args.length; i ++){
					o = extend(o,args[i]);
				}
				return o;
			}else if(arguments.length == 2){
				var o = arguments[0];
				var b = arguments[1];
				for(var a in b){
					o[a] = b[a];
				}
				return o;
			}
		},
		each = function(object,callback,f){
			for(var attr in object){
				if((f || boolean(true))(attr,object[attr],object)){
					if(isstring(attr)){
						if(callback(attr,object)){
							break;
						}
					}
				}
			}
		};
		
		//attributes
		var ua = ua || navigator.userAgent.toLowerCase(),
		pa = navigator.platform,
		
		//正则
		browser_regexps = {
				number : "\\d",//数字
				dot : "\\.",//点
				blank : '\\s',
				letter : '\\w',//字母
				version : '[{number}{dot}]+' ,//版本
				m_version : '[\\d\\.r_]',//主版本
				name : '{letter}+' ,//名称
				brackets : '\\([^\\)]+\\)' ,//括号对象
				platform : '{brackets}' ,//平台
				browser : '{name}[/]{version}',//浏览器对象
				shell : '{browser}' ,
				engine : '{browser}' ,
				engine_like : '{brackets}' ,
				browser_info : '{name}[/]?{m_version}*' ,
				net : 'NetType[/]({letter}+)',
				browser_mark : 'Mozilla[/]{version}',
				window : 'windows{blank}*nt{blank}*({version})',
				windows : '/{window}/i',
				mise : '\\(({letter}+;{blank}*)*(msie{blank}+{version});{blank}+({window};{blank}+wow{number}+);{blank}+({engine});([^;]+;{blank}+)?(engine)\\)',
				firefox : '({platform}){blank}+({name}[/]{number}+){blank}+({engine})'
		},
		
		//浏览器信息
		o_browser = {
			mise : {
				id : /MSIE[/\s]*([\w\.]+)/ig,
				browser_regexp : "/{browser_mark}{blank}+{mise}/i",
				example : 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C; QQBrowser/7.7.26717.400)',
				example1 : 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)',
				guess : function(ua){
					//Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C; QQBrowser/7.7.26717.400)
					//Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C)
					//Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)
					browser.version = RegExp.$1;
					var bregexp = this.browser_regexp.explain(browser_regexps),
					m = ua.match(bregexp);
					console.info(bregexp);
					if(m){
						var platform_info = RegExp.$1,
						engine_info = RegExp.$3,
						//engine_like = RegExp.$3,
						shells_info = RegExp.$4;
						//shell_info = RegExp.$5,
						//net_info = RegExp.$6;
						browser.platform_info = platform_info;
						browser.engine_info = engine_info;
						browser.shells_info = shells_info || 'mise/' + browser.version;
						browser.net_info = 'nettype/eth';
					}
				}
			},
			firefox : {
				id : /Firefox[/]([\w\.]+)/ig,
				browser_regexp : "/{browser_mark}{blank}+{firefox}/i",
				example : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:32.0) Gecko/20100101 Firefox/32.0',
				guess : function(ua){
					//Mozilla/MozillaVersion (Platform; Encryption; OS-or-CPU; Language; PrereleaseVersion) Gecko/GeckoVersion ApplicationProduct/ApplicationProductVersion
					//Mozilla/5.0 (Windows NT 6.1; WOW64; rv:32.0) Gecko/20100101 Firefox/32.0
					browser.version = RegExp.$1;
					var bregexp = this.browser_regexp.explain(browser_regexps),
					m = ua.match(bregexp);
					if(m){
						var platform_info = RegExp.$1,
						engine_info = RegExp.$2,
						//engine_like = RegExp.$3,
						shells_info = RegExp.$3;
						//shell_info = RegExp.$5,
						//net_info = RegExp.$6;
						browser.platform_info = platform_info;
						browser.engine_info = engine_info;
						browser.shells_info = shells_info || 'nettype/eth';
						//browser.net_info = net_info;
					}
				}
			},
			safari : {
				//id : /Version[/]([\d\.]+)\s+Safari\/([\d\.]+)|Safari\/([\d\.]+)$/i,
				id : /(Version[/]([\d\.]+)\s+)?(Mobile[/][\w\d]+\s+)?Safari[/]([\d\.]+)$/i,
				example1 : 'Version/5.0.2 Mobile/8J2 Safari/6533.18.5',
				example : 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_1_2 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) CriOS/35.0.1916.38 Mobile/10B146 Safari/8536.25',
			},
			chrome : {
				id : /Chrome[/]([\w\.]+)\s+Safari[/][\w\.]+$/i,
				example : 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.103 Safari/537.36',
			},
			opera : {
				id : /OPR[/]([\w\.]+)$|Opera[/]([\d\.]+)/i,
				example : 'Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; en) Presto/2.8.131 Version/11.11',
				regexps : [
				    {
				    	reg : /Opera[/][\d\.]+\s+\(([^\)]+)\)\s+(\w+[/][\d\.]+)\s+\w+[/]([\d\.]+)/i,
				    	match : function(ua){
				    		var m = ua.match(this.reg);
				    		if(m){
				    			return {
				    				platform : RegExp.$1,
				    				engine : RegExp.$2,
				    				shell : 'opera/'+RegExp.$3,
				    			};
				    		}
				    	}
				    },       
				],
				example : 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36 OPR/23.0.1522.77',
			},
			micromessenger : {
				id : /MicroMessenger[/]([\w\.r_]+)/i,
				example : 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_1_2 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Mobile/10B146 MicroMessenger/5.4 NetType/WIFI',
			},
			'default' : {
				browser_regexp : "/{browser_mark}{blank}+({platform}){blank}+({engine}{blank}+({engine_like}{blank}+)?)(({browser_info}{blank}*)+)({net})?/i",
				guess : function(ua){
					//Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36 OPR/23.0.1522.77
					browser.version = RegExp.$2 || RegExp.$4 || RegExp.$1 || RegExp.$3;
					var bregexp = this.browser_regexp.explain(browser_regexps),
					m = ua.match(bregexp);
					if(m){
						var platform_info = RegExp.$1,
						engine_info = RegExp.$2,
						//engine_like = RegExp.$3,
						shells_info = RegExp.$4,
						//shell_info = RegExp.$5,
						net_info = RegExp.$6;
						browser.platform_info = platform_info;
						browser.engine_info = engine_info;
						browser.shells_info = shells_info;
						browser.net_info = net_info  || 'nettype/eth';
					}
					if(!m && this.regexps){
						for(var i = 0; i < this.regexps.length; i ++){
							var regexp = this.regexps[i];
							m = regexp.match(ua);
							if(m){
								break;
							}
						}
						if(m){
							browser.platform_info = m.platform;
							browser.engine_info = m.engine;
							browser.shells_info = m.shell;
							browser.net_info = m.net_info  || 'nettype/eth';
						}
					}
				},
				test : function(){
					console.info('test...');
					main(this.example);
				}
			}
		},
		
		browser = {},
		//平台操作系统信息
		os = {},
		o_platform = {
			windows : {
				id : /windows/i,
				example : 'Windows NT 6.1; U; en',
				example1 : 'Windows NT 6.1; WOW64; rv:32.0',
				guess : function(version){
					//windows nt 6.1; wow64
					var win = {
						'5.1' : 'xp',
						'6.0' : 'vista',
						'6.1' : 'win7',
						'6.2' : 'win8'
					},
					reg = /windows\s+NT\s+([\d\.]+);\s+(([a-z]+);\s+)?((\w+);\s+)?/i;
					if(version.match(reg)){
						os.name = win[RegExp.$1];
					}
					os.name = os.name || 'window xx';
					platform.encription = RegExp.$3 || 'x';
					famliy.name = RegExp.$5 || '32';
				}
			},
			apple : {
				//id : /(iphone);\s+cpu\s+iphone\s+os\s+([\d_]+)\s+like\s+([^\)]*)/i,
				id : /(iphone|ipad|ipod|macintosh);(((\s+(\w+);)?\s+cpu\s+(.*)(?:(like))([^;)]+))|(\s+(\w+)\s+([^;]+)))/i,
				//id : /Macintosh;\s+(\w+)?;?\s+(\w+)?\s+([^;]+);\s+(\w+)/i,
				example : [
		           'Macintosh; Intel Mac OS X 10.6; rv:2.0.1',
		           'iPhone; U; CPU iPhone OS 4_3_3 like Mac OS X; en-us',
		           'iphone; CPU OS 5_1_1 like Mac OS X'
				],
				guess : function(version){
					//iPhone; CPU iPhone OS 6_1_2 like Mac OS X
					var m = version.match(this.id);
					if(RegExp.$3){
						platform.encryption = RegExp.$5 || 'U';
						platform.name = RegExp.$1;
						os.name = RegExp.$6;
						os.like = RegExp.$8;
						client.name = RegExp.$1;
					}else if(RegExp.$9){
						platform.encryption = 'U';
						platform.name = RegExp.$1;
						platform.cpu = m[10];
						os.name = m[11];
						client.name = RegExp.$1;
					}
					
				}
			},
			linux : {
				id : /linux/i,
				guess : function(version){
					
				}
			}
		},
		platform = {},
		//引擎内心信息
		o_engine = { 
			ie:{
				id : /^(\w+)[/]([\d\.r_]+)$/i,
				example : 'Trident/6.0',
				guess : function(ei){
					engine.name = RegExp.$1;
					engine.version = RegExp.$2;
				}
			}, 
			webkit:{
				id : /(\w+)[/]([\d\.r_]+)\s+\((\w+),\s+like\s+(\w+)\)/i,
				example : 'applewebkit/537.36 (khtml, like gecko)',
				guess : function(ei){
					engine.name = RegExp.$1;
					engine.version = RegExp.$2;
					engine.name1 = RegExp.$3;
					engine.like = RegExp.$4;
				}
			}, 
			gecko:{
				id : /gecko[/]([\d\.r_]+)/i,
				example : 'Gecko/20100101',
				guess : function(){
					engine.version = RegExp.$1;
				}
			}, 
			opera:{
				id : /opera[/]([\d\.r_]+)/i,
				example : 'opera/20100101',
			}, 
			khtml:{
				id : /khtml[/]([\d\.r_]+)/i,
				example : 'khtml/20100101',
			},
			'default' : {
				guess : function(){
					engine.version = RegExp.$1;
				},
				test : function(){
					console.info(this.id.match(this.example));
					this.guess();
				}
			}
		},
		engine = {},
		o_shell = {
			ie :{
				id : /(msie)[/]([\d\.]+)/i
			}, 
			chrome : {
				id : /(chrome)[/]([\w\.]+)\s+Safari[/][\w\.]+$/i,
			}, 
			firefox : {
				id : /(firefox)[/]([\w\.]+)/ig,
			}, 
			opera:{
				id : /(OPR)[/]([\w\.]+)$/ig,
			},
			safari : {
				example : 'Version/5.0.2 Mobile/8J2 Safari/6533.18.5',
				id : /(Safari)\/([\d\.]+)$/i,
			},
			se360 : {
				id : /(360se)(?:[/]([\w.]+))?/i
			},
	        se : {
	        	id : /(se) ([\w.]+)/
	        },
	        qq : {
	        	id : /(m?qqbrowser)[/]([\w.]+)/i
	        },
	        tt : {
	        	id : /(tencenttraveler) ([\w.]+)/i
	        },
	        konq : {
	        },
	        netscape : {
	        },
			maxthon :{
			}, 
			theworld :{
			}, 
			cometbrowser :{
			}, 
			greenbrowser :{
				
			}, 
	        "default": {
	        	id : /(\w+)[/]([\d\.r_]+)/i,
	        	guess : function(){
	        		shell.name = RegExp.$1;
	        		shell.version = RegExp.$2;
	        	}
	        }
		},
		shell = {},
		//网络语言
		lang = navigator.language,
		net = {
			id : /nettype[/](\S+)/i,
			guess : function(ni){
				ni.match(this.id);
				net.name = RegExp.$1 || 'eth';
			}
		},
		famliy = {},
		client = {},
		guess = function(b,a,ua){
			each(b,function(type,o){
				if(type != 'default' && o['default']){
					o[type] = extend({},o['default'],o[type]);
				}
				return false;
			});
			each(b,function(type,o){
	            var bobj = o[type];
				if(bobj.id.test(ua)){
					a.name = type;
					o[type].guess(ua);
					return true;
				}
			},function(type,o,object){
				return type != 'default' && typeof object[type] == 'object';
			});
		},
		main = function(ua){
			
			//browser
			guess(o_browser,browser,ua);
			
			//platform os
			browser.platform_info && guess(o_platform,platform,browser.platform_info);
			platform.name = platform.name || pa;
			
			//engine
			browser.engine_info && guess(o_engine,engine,browser.engine_info);
			
			//shell
			browser.shells_info && guess(o_shell,shell,browser.shells_info);
			
			//net
			browser.net_info && net.guess(browser.net_info);
			
			//client
			if(/mobile/i.test(ua)){
				client.type = 'mobile';
			}else{
				client.type = 'pc';
			}
		};
		
		function json2string(json){
			if($.isArray(json)){
				var s = [];
				for(var i = 0; i < json.length; i ++){
					var v = json2string(json[i]);
					s.push(v);
				}
				return '['+s.join(',')+']';
			}else if($.isPlainObject(json)){
				var s = [];
				for(var attr in json){
					if(!$.isFunction(json[attr])){
						var v = json2string(json[attr]);
						s.push("\""+attr+"\"" + ':' + v);
					}
				}
				return '{'+s.join(',')+'}';
			}else{
				return "\""+json + "\"";
			}
		}
		
		main(ua);
		return {
			browser : browser,//浏览器
			engine : engine,//渲染引擎
			shell : shell,//内核
			platform : platform,//平台
			os : os,//操作系统
			famliy : famliy,//操作系统位数
			lang : lang,//语言
			net : net,//网络
			client : client,//客户端
			o : {
				o_browser : o_browser,//浏览器
				o_engine : o_engine,//渲染引擎
				o_shell : o_shell,//内核
				o_platform : o_platform,//平台
				browser_regexps : browser_regexps,
				ua : ua
			}
		};
	}
	window.Browser = Browser;
	return Browser;
});