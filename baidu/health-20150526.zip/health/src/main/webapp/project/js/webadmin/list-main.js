//console.info("加载成功...");
require.config(require_config);

require(['bootstrap','jquery','dialog','ObjectMgr'], function (doc,$,dialog){

	/*dialog.modal.show({
		body : $("[role=form]"),
		header : 'hello world',
		callback : function(){
			alert('ok....');
		}
	});*/
	
});