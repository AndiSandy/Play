define('dialog',['jquery','utils','bootstrap'],function($){
	var log = new Logger("health.webadmin.dialog",'info');

	var setting = {
			_static_ :{
			},
			_public_ : {
				tpl_server : 'scripts/webadmin/tpl/dialog.ftl'
			},
			//控件选择器
			el : {
				$modal : '#myModal',
				success : '.alert-success',
				warning : '.alert-warning',
				info : '.alert-info',
				error : '.alert-danger',
			},
			//表单
			frm : {
			},
			//控件元素
			elm : {}
	};
	
	function $parent(){
		var w = window;
		while(w.parent && w.parent != w){
			//console.info('here...');
			w = w.parent;
		}
		return w;
	}
	//$ = $parent().$ || $;
	
	var Alert = _defineClass_({
		constructor : function(_setting_){
			var setting = {
					alert_delay : 2000
			};
			this.context = $($parent().document.body);
			this.setting = $.extend(setting, _setting_ );
			this.$setting();
			this.initilize();
		},
		_public_:{
			initilize : function(){
				var alert = this;
				var alerts = ['info','success','warning','error'];
				for(var i = 0; i < alerts.length; i ++){
					this[alerts[i]].show = function(text){
						var that = this;
						that._alert = alert;
						var args = [].slice.apply(arguments,[0,arguments.length]);
						alert.show.apply(this,args);
					};
				}
			},
			show : function(text,cb){
				var that = this;
				//that.alert();
				/**/
				that.removeClass("hidden").addClass('in');
				that.find(".text").text(text);
				that.css({position:'absolute',top:'100px','z-index':10000,left:'0px','min-width':200});
				var width = $(that._alert.context).width()/2 - (that.width()/2) - 25;
				that.animate({left:width},1000);
				$.timmer.t('health.webadmin.alert.show',that._alert.setting.alert_delay,function(cb){
					//that.alert('close');
					that.addClass('hidden').removeClass('in');
					(cb||$.noop)();
				},cb);
			}
		}
	});
	
	var Modal = _defineClass_({
		constructor : function(_setting_){
			var setting = {
				el : {
					//context : '[rel=dialog_tpl]',
					$header : '.modal-title',
					$body : '.modal-body',
					$footer : '.modal-footer',
					$save : '[rel=save]',
					$content : '.modal-content',
					$login : '[name=loginFrm_passport]',
					$dialog : '.modal-dialog'
				},
				saveTxt : 'Save'
			};
			this.setting = $.extend(setting, _setting_ );
			this.$setting(_setting_);
			this.$el();
			this.$bak(['$header','$body','$footer','$content']);
			this.context = this.$modal;
			//this.initilize();
		},
		_public_:{
			initilize : function(){
				var modal = this;
				this.$el();
				this.setting.content && this.$content.html(this.setting.content);
				this.setting.body && this.$body.html(this.setting.body);
				this.setting.header && this.$header.html(this.setting.header);
				if(this.setting.footer){
					this.$header.html(this.setting.footer);
				}else{
					var callback = this.setting.callback || $.noop;
					this.$save.text(this.setting.saveTxt).off('click').click(function(){
						modal.$$frm();
						callback(modal.frm,modal);
						modal.hide();
					});
				}
			},
			show : function(_setting_){
				this.recover();
				$.extend(this.setting, _setting_ );
				this.$setting(_setting_);
				this.initilize();
				this.hide();
			},
			hide : function(){
				this.$modal.modal('toggle');
			},
			login : function(){
				this.$login.removeClass('hidden');
				dialog.modal.show({
					content : this.$login,
				});
			},
			recover : function(){
				var _content = this.bak.$content.clone();
				this.$dialog.html(_content);
				//this.$modal.find(this.$content).replaceWith(_content);
				this.$content = _content;
			}
		}
	});
	
	var Dialog = _defineClass_({
		constructor : function(_setting_){
			this.context = $($parent().document.body);
			//this.setting = $.extend(setting, _setting_ );
			this.$setting(_setting_);
			this.initilize();
		},
		_static_:{
			
		},
		_public_:{
			initilize : function(){
				var dialog = this;
				this.$el();
				if(this.$modal.size()==0){
					$.get(dialog.tpl_server,function(html){
						var context = html;
						dialog.context.append(context);
						//dialog.setting.context = context;
						dialog.$el();
						dialog.initilizeAlert();
						dialog.initilizeModal();
					},'html');
				}
			},
			initilizeAlert : function(){
				this.alert = new Alert({
					_public_:{
						info : this.info,
						success : this.success,
						warning : this.warning,
						error : this.error
					}
				});
			},
			initilizeModal : function(){
				this.modal = new Modal({
					_public_ :{
						$modal : this.$modal
					}
				});
			},
			show : function(){
				this.$modal.modal('toggle');
				//$(this.setting.el.modal).modal('toggle');
			},
			confirm : function(text,callback){
				this.modal.show({
					body : text,
					saveTxt : '确定',
					header : '请确认',
					callback : function(frm,modal){
						(callback || $.noop)();
						//modal.hide();
					}
				});
			}
		}
	},setting);
	
	window.dialog = $parent().dialog || new Dialog(setting);
	
	return dialog;
});