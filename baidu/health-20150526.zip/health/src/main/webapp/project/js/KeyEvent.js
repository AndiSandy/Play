define('KeyEvent',['jquery','utils'],function($){
	
	var KeyEvent = _defineClass_({
		constructor : function(setting){
			
		},
		_static_:{
			keyMap : {
				'Ctrl' : function(e){
					return e.ctrlKey;
				},
				'Shift' : function(e){
					return e.shiftKey;
				},
				'Enter' : 13
			},
			checkKey : function(e,key){
				var keyM = KeyEvent.keyMap[key] || '';
				var ok = false;
				if($.isFunction(keyM)){
					ok = keyM(e);
				}else{
					ok = keyM == e.which;
				}
				return ok;
			},
			doKey : function(e,keys,action){
				keys = keys || '';
				action = action || $.noop;
				var or_keys = keys.split(',');
				for(var i = 0; i < or_keys.length; i ++){
					var or_key = or_keys[i];
					var and_keys = or_key.split('+');
					var and_ok = true;
					for(var j=0; j < and_keys.length; j++){
						var and_key = and_keys[j];
						and_ok = and_ok && KeyEvent.checkKey(e,and_key);
					}
					if(and_ok){
						action(e);
					}
				}
			}
		}
	});
	
	$.fn.keyEvent = function(keys,action){
		$(this).keypress(function(e){
			KeyEvent.doKey(e,keys,action);
		});
	};
	
	//var chatToolbar = new KeyEvent(setting);
	
	return KeyEvent;
});