/**
* jquery template // 2012.11.21 // jQuery 1.1.2+
* 
* @author   maigc <magic0115.duapp.com/health/chat/>
*/
(function($,window){
	
	String.fn = String.prototype;
	String.show = function(os,ifNull){
		var ifNull = ifNull || "";
		if(os == null){
			return ifNull;
		}
		return os;
	};
	/**
	 * 模板类
	 * @param {Object} template
	 * @param {Object} data
	 * @return {TypeName} 
	 */
	window.Template = {};
	
	/**
	 * 转换入口
	 * @param {Object} template
	 * @param {Object} data
	 * @return {TypeName} 
	 */
	Template.parse = function(template,data){
		var reg = /\{([^}]*?)\}/img;
		var tplReg = /(<tpl[^>]*?>(.*?)<\/tpl>)/img;
		template = template.replace(tplReg,function(a,_tpl){
			var new_tpl = Template.parseTpl_for(_tpl,data);
			new_tpl = Template.parseTpl_if(new_tpl,data);
			return new_tpl;
		});
		template = template.replace(reg,function(a,b){
			return String.show(data[b] || data,b);
		});
		return template;
	};
	
	/**
	 * 模板中基础模板处理
	 * @param {Object} template
	 * @param {Object} data
	 * @return {TypeName} 
	 */
	Template.parse_eval = function(template,data){
		var reg = /\{([^}]*?)\}/img;
		template = template.replace(reg,function(a,_b_){
			with(data){
				return String.show( eval("("+_b_+")") , _b_ );
			}
		});
		return template;
	};
	
	/**
	 * for 模板处理 <tpl for="a">tpl{a.b}--{a.c}</tpl>
	 * @param {Object} template
	 * @param {Object} data
	 * @param {Object} r
	 * @return {TypeName} 
	 */
	Template.parseTpl_for = function(template,data,r){
		var tplReg_for_after =/<tpl\s*?for=\s*?"([^"]*?)"(?:\s*?join="([^"]*?)")*?\s*?>(.*?)<\/tpl>/img;
		var tplReg_for_before = /<tpl(?:\s*?join="([^"]*?)")\s*?(?:for=\s*?"([^"]*?)"\s*?)*?\s*?>(.*?)<\/tpl>/img;
		r = r || tplReg_for_after;
		if(r.test(template)){
			template = template.replace(tplReg_for_after,function(a,name,_join,_tpl){
				//var _tpl = __tpl || __join;
				//var _join = __tpl && __join ;
				var da = data[name];
				var obj = {};
				var pre_tpl = [];
				for(var i =0; i < da.length; i ++){
					obj[name] = da[i];
					pre_tpl.push(Template.parse_eval(_tpl,obj));
				}
				return pre_tpl.join(_join || "");
			});
		}else if(tplReg_for_before.test(template)){
			template = template.replace(tplReg_for_before,function(a,_join,name,_tpl){
				//_tpl
				var da = data[name];
				var obj = {};
				var pre_tpl = [];
				for(var i =0; i < da.length; i ++){
					obj[name] = da[i];
					pre_tpl.push(Template.parse_eval(_tpl,obj));
				}
				return pre_tpl.join(_join || "");
			});
		}
		return template;
	};
	/**
	 * eval 内部版
	 * @param {Object} data
	 * @param {Object} js
	 * @return {TypeName} 
	 */
	Template.eval = function(data,js){
		with(data || window){
			return eval("("+js+")");
		}
	};
	
	/**
	 * if处理模板 <tpl if="a>b">tpl</tpl>
	 * @param {Object} template
	 * @param {Object} data
	 * @param {Object} r
	 * @return {TypeName} 
	 */
	Template.parseTpl_if = function(template,data,r){
		var tplReg_if =/<tpl\s*?if=\s*?"([^"]*?)"\s*?>(.*?)<\/tpl>/img;
		r = r || tplReg_if;
		if(r.test(template)){
			template = template.replace(r,function(a,ifBoolean_eval,_tpl){
				var ifBoolean = Template.eval(data,ifBoolean_eval);
				if(ifBoolean){
					return Template.parse_eval(_tpl,data);
				}else{
					return "";
				}
			});
		}
		return template;
	};
	
	/**
	 * 和jQuery 结合
	 * @param {Object} ignore
	 * @memberOf {TypeName} 
	 * @return {TypeName} 
	 */
	jQuery.fn.clear = function(ignore){
		if( ignore || !$(this).data("clear")){
			$(this).empty();
			$(this).data("clear",true);
		}
		//$(this).html("")
		return this;
	};
	jQuery.fn.template = function(selector){
		$(this).hide();
		var template = $(this).html();
		$(this).data("template",template);
		$(this).data("target",$(selector || this));
		return this;
	};
	jQuery.fn.jparse = function(data){
		if(Template.debug)return;
		var template = $(this).data("template");
		var target = $(this).data("target");
		var html = Template.parse(template,data);
		target.append(html);
		return this;
	};
	jQuery.fn.tpl = function(selector){
		//$(selector).template(this)
		$(selector).hide();
		var template = $(selector).html();
		$(this).data("template",template);
		//$(this).data("target",$(selector || this));
		return this;
	};
	
	jQuery.fn.parse = function(data){
		if(Template.debug)return;
		var template = $(this).data("template");
		var target = $(this);//.data("target");
		var html = Template.parse(template,data);
		target.append(html);
		return this;
	};
	
	//Template.debug = true;
	
})(jQuery,window);