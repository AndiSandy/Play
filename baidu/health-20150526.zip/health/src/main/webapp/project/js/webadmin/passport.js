//加载配置
define('passport',['jquery','dialog','loginmgr'],function($,dialog,LoginMgr){
	
	var log = new Logger("health.webadmin.passport",'info');
	var setting = {
			_static_ :{
				islogin_url : 'secure/islogin.json',
				dashboard_url : 'webadmin/dashboard.php'
			},
			//控件选择器
			el : {
			},
			//表单
			frm : {
			},
			//控件元素
			elm : {}
	};
	var loginMgr = new LoginMgr();
	var passport = _defineClass_({
		constructor : function(_setting_){
			this.setting = $.extend({},setting,_setting_ ||{});
			this.initilize();
		},
		_static_:{
			ensureLogin : function(success,fail){
				$.get(passport.islogin_url,function(msg){
					log.debug(msg);
					if(msg.success){
						(success||$.noop)(msg);
					}else{
						loginMgr.callback = function(msg){
							dialog.modal.hide();
							(success||$.noop)(msg);
						};
						dialog.modal.login();
						loginMgr.context = dialog.$modal;
						loginMgr.initilize();
						//(fail||$.noop)(msg);
					}
				},'json');
			},
			showLogin : function(){
				dialog.modal.show({
					//saveTxt : '保存',
					body : frm,
					header : '修改' + mgr.$frm.title,
					callback : function(frm,modal){
						log.info(frm);
						//save
						mgr.save(frm);
						//tip
						dialog.alert.success.show('修改成功');
					}
				});
			}
		},
		_public_:{}
	},setting);
	return passport;
});