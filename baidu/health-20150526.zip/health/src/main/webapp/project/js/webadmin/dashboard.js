//加载配置
require.config(require_config);
require(['jquery','bootstrap','dialog','loginmgr'], function ($,utils,dialog,LoginMgr){
	$("[data-dismiss=hidden]").click(function(){
		$(this).parent(".alert").addClass("hidden");
	});
	var loginMgr = new LoginMgr();
	loginMgr.initilize();
	//左侧菜单
	$(document).on('click','[rel=menu] li',function(){
		$('[rel=menu] li').removeClass("active");
		$(this).addClass("active");
	});
	
	
});
