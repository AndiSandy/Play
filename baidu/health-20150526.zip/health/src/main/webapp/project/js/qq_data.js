(function(window,$){
	'use strict';//health_t_test_qgroup
	//data.import({table:'health_t_test_qgroup',id:'gnum',mapper:{gc:'gnum',gn:'gname',owner:'owner'},data:groups.create.concat(groups.join).concat(groups.manage)});
	var $data = new function (){
		var $d = this,domain = 'http://localhost:8080/health/data/',_ = {
				domain : domain,
				service : {
					import :{
						name : 'import_data',
						url : domain + 'import.jsonp'
					},
					query : {
						name : domain + 'query_data.jsonp',
						url : domain + 'query.jsonp'
					}
				},
		};
		$d.import = function(d){
        	var data = {
            		callback : _.service.import.name
            		//table : 'health_t_test_user',
            		//id : 'userid',
            		//data : [{iname:'test',iage:18,imale:'men'}],
            		//mapper : {iname:'name',iage:'age',imale:'male'}
            };
        	$.ajax({
            	type : 'GET',
            	url : _.service.import.url,
            	dataType : 'jsonp',
            	contentType : 'application/json; charset=UTF-8',
            	jsonp : 'callback',
            	data : {jsondata : JSON.stringify($.extend(data,d))},
            	jsonpCallback : _.service.import.name,
            	success : function(json){
            		console.info(json);
            	},
            	error : function(){
            		console.info('import data error...');
            	}
            });
        };
        $d.query = function(d,success){
        	var data = {
            		callback : _.service.import.name
            		//table : 'health_t_test_user',
            		//condition : 'name like "sara%"',
            		//id : 'userid',
            		//data : [{iname:'test',iage:18,imale:'men'}],
            		//mapper : {iname:'name',iage:'age',imale:'male'}
            };
            $.ajax({
            	type : 'GET',
            	url : _.service.query.url,
            	dataType : 'jsonp',
            	contentType : 'application/json; charset=UTF-8',
            	jsonp : 'callback',
            	data : {jsondata : JSON.stringify($.extend(data,d))},
            	jsonpCallback : _.service.import.name,
            	success : success,
            	error : function(){
            		console.info('query data error...');
            	}
            });	
        };
        $d.$http = function(){}; 
        $d.http = function(d,s,e){
        	var data = {
            		callback : _.service.query.name
            		//table : 'health_t_test_user',
            		//condition : 'name like "sara%"',
            		//id : 'userid',
            		//data : [{iname:'test',iage:18,imale:'men'}],
            		//mapper : {iname:'name',iage:'age',imale:'male'}
            };
        	var url = [_.service.query.url,'?jsondata=',JSON.stringify($.extend(data,d)),'&callback=','JSON_CALLBACK'].join(''); 
        	$d.$http.jsonp(url)
        	.success(function(d){
        		(s||$.noop).apply(this,[d]);
        	})
        	.error(function(response, status, headers, config){
        		(e||$.noop).apply(this,arguments);
        	});
        };
        $d.save = function(d,s,e){
        	var data = {
            		callback : _.service.import.name
            		//table : 'health_t_test_user',
            		//condition : 'name like "sara%"',
            		//id : 'userid',
            		//data : [{iname:'test',iage:18,imale:'men'}],
            		//mapper : {iname:'name',iage:'age',imale:'male'}
            };
        	var url = [_.service.import.url,'?jsondata=',JSON.stringify($.extend(data,d)),'&callback=','JSON_CALLBACK'].join(''); 
        	$d.$http.jsonp(url)
        	.success(function(d){
        		(s||$.noop).apply(this,[d]);
        	})
        	.error(function(response, status, headers, config){
        		(e||$.noop).apply(this,arguments);
        	});
        };
    };
    Array.prototype.split = function(s){
    	var al = [];
    	for(var i = 0; i <= Math.ceil(this.length/s); i++){
    		//console.info(i*s+"--"+(i+1)*s);
    		var a = this.slice(i*s,(i+1)*s);
    		if(a.length > 0){
    			al.push(a);
    		}
    	}
    	return al;
    };
    Array.prototype.each = function(f,t){
    	var a = this;
    	a.i = 0;
    	a.tid = 0;
    	function callback(a){
    		if( a.i < a.length ){
    			a.tid = setTimeout(function(){
        			f(a.i,a[a.i]);
        			a.i ++;
        			callback(a);
        		},t|1000);
    		}else{
    			clearTimeout(a.tid);
    		}
    	}
    	callback(a);
    };
    //$qq.search_group_number(310033401,56,10);
    var $qq = new function(){
    	var $q = this,_ = {
    		bkn : 776592531,
    		service : {
    			search_group_number : 'http://qun.qq.com/cgi-bin/qun_mgr/search_group_members',
    			get_group_list : 'http://qun.qq.com/cgi-bin/qun_mgr/get_group_list'
    		}
    	};
    	//qq群成员信息拉取
    	$q.search_group_number = function(gnum,max,step){
    		$.post(_.service.search_group_number,{
    			gc : gnum,
    			st : 0,
    			end : max,
    			bkn : _.bkn,
    		},function(json){
    			if(json && json.mems && json.mems.length > 0){
    				var mems = json.mems;
    				for(var i = 0; i < mems.length; i ++){
    					mems[i].gnum = gnum;
    				}
    				if(step){
    					var al = mems.split(step);
    					al.each(function(i,users){
    						console.info(i+"import...");
    						$data.import({
            					table:'health_t_q_user',
            					id:'qnum',
            					mapper:{uin:'qnum',card:'card',g:'gender',nick:'nick',gnum:'gnum'},
            					data:users
            				});
    					});
    				}else{
    					$data.import({
        					table:'health_t_q_user',
        					id:'qnum',
        					mapper:{uin:'qnum',card:'card',g:'gender',nick:'nick',gnum:'gnum'},
        					data:json.mems
        				});
    				}
    			}
    		},'json');
    	};
    	//qq群信息拉取
    	$q.get_group_list = function(step){
    		$.post(_.service.get_group_list,{
    			bkn : _.bkn
    		},function(json){
    			if(json && json.join && json.join.length > 0){
    				var groups = json.join.concat(json.create).concat(json.manage);
    				if(step){
    					var al = groups.split(step);
    					al.each(function(i,$groups){
    						console.info(i+"import...");
    						$data.import({
    	    					table:'health_t_q_group',
    	    					id:'gnum',
    	    					mapper:{gc:'gnum',gn:'gname',owner:'owner'},
    	    					data:$groups
    	    				});
    					});
    				}else{
    					$data.import({
        					table:'health_t_q_group',
        					id:'gnum',
        					mapper:{gc:'gnum',gn:'gname',owner:'owner'},
        					data:groups
        				});
    				}
    			}
    		},'json');
    	};
    	//签名
    	$q.sign = function(bkn){
    		_.bkn = bkn;
    	};
    };
    
    //彩票
    var $ltry = new function(){
    	var $l = this;
    	$l.import = function(step){
    		var list = [];
    		var el = "#chartTable tbody tr:not(.chart_table_tr_statistic,.chart_table_tr_statistic_current_omission)";
    		$(el).each(function(i,elm){
    			var s = [];
    			$("td:eq(0),td.omission_hit",elm).each(function(j,jelm){
    				s.push($(jelm).text());
    			});
    			list.push({
    				qi : s[0],
    				red1: s[1],
    				red2: s[2],
    				red3: s[3],
    				red4: s[4],
    				red5: s[5],
    				red6: s[6],
    				blue: s[7],
    			});
    		});
    		//console.info(list);
    		if(step){
				var al = list.split(step);
				al.each(function(i,$groups){
					console.info(i+"import...");
					$data.import({
    					table:'health_t_l_lottery',
    					id:'qi',
    					//mapper:{gc:'gnum',gn:'gname',owner:'owner'},
    					data:$groups
    				});
				});
			}
    	};
    };
    window.$data = $data;
}(window,jQuery));