define('editor',['jquery'],function($){
	
	//定义一类
	var defineClass = function(_class_,_static_,_impl_){
		$.extend(_class_,_class_._static_ ||_static_ || {});
		delete _class_._static_;
		$.extend(_class_.prototype,_class_._impl_ ||_impl_ ||{});
		delete _class_._impl_;
		return _class_;
	};
	
	var Editor = function(){
		
	};
	Editor._static_ = {
		init : function(el){
			var _editor = $(el);
			var editor = _editor.get(0);
			var editorDoc = editor.contentWindow.document;
			var editorWindow = editor.contentWindow;
			editorDoc.designMode = "on";
			//editorDoc.open();
			//editorDoc.write("<html><head></head><body style='margin:0px; padding: 0px;'>editor now</body></html>");
			//editorDoc.close();
			$(editorDoc.body).focus(function(){
				$(".editorFrame").addClass("focus");
			}).blur(function(){
				$(".editorFrame").removeClass("focus");
			});
			$(editorDoc.body).width(_editor.width());
			
		}	
	};
	
	return defineClass(Editor);
});