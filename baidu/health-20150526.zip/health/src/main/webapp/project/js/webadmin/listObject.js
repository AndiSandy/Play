define('ObjectMgr',['jquery','dialog'],function($,dialog){
	var log = new Logger("health.webadmin.ObjectMgr");
	var ObjectMgr = _defineClass_({
		constructor : function(_setting_){
			var setting = {
					_public_ :{
					},
					//控件选择器
					el : {
						$objs : 'tr[objid]',
						$frm : '[name=dataFrm]',
						$add : '[rel=add]',
						$update : '[rel=update]',
						$del : '[rel=del]',
						$up : '[rel=up]',
						$down : '[rel=down]'
					},
					//表单
					frm : {
					},
					//控件元素
					elm : {}
			};
			//参数合并
			//参数处理
			this.setting = $.extend(setting, _setting_ );
			this.$setting(_setting_);
			this.$el();
			this.initilize();
		},
		_public_:{
			initilize : function(){
				var mgr = this;

				BeanUtils.extend(mgr.$frm).$attr(['save','query','del','title','update_order']);
				
				//绑定添加按钮
				this.$add.click(function(){
					var frm = mgr.$frm.clone();
					
					dialog.modal.show({
						body : frm,
						header : '添加' + mgr.$frm.title,
						saveTxt : '保存',
						callback : function(frm){
							log.info(frm);
							//save
							mgr.save(frm);
							//close
							//tip
						}
					});
				});
				
				//绑定删除按钮
				$(document).on('click',mgr.setting.el.$del,function(){
					var context = $(this).parents('tr');
					var objid = context.attr('objid');
					var name = context.attr('name');
					log.info("objid"+objid);
					//confirm
					dialog.confirm('确认要删除'+name+'这个记录吗?',function(){
						log.info("del...");
						//del
						mgr.del(objid);
						//tip
						//dialog.alert.success.show("删除成功");
					});
				}).on('click',mgr.setting.el.$update,function(){
					var context = $(this).parents('tr');
					var objid = context.attr('objid');
					log.info("objid"+objid);
					//query
					mgr.query(objid,function(time){
						var frm = mgr.$frm.clone();
						BeanUtils.extend(frm).$$val(time);
						frm.find("select").each(function(i,elm){
							var value = elm.value;
							$("option[value="+value+"]",elm).attr("selected",true);
						});
						dialog.modal.show({
							saveTxt : '保存',
							body : frm,
							header : '修改' + mgr.$frm.title,
							callback : function(frm,modal){
								log.info(frm);
								//save
								mgr.save(frm);
								//tip
								//dialog.alert.success.show('修改成功');
							}
						});
					});
					
				}).on('click',"tbody tr:not(:first) "+mgr.setting.el.$up,function(){
					var context = $(this).parents('tr');
					var objid1 = context.attr('objid');
					var objid2 = context.prev("tr").attr('objid');
					log.info("objid1"+objid1+"objid2"+objid2);
					//query
					mgr.update_order(objid1,objid2);
					
				}).on('click',"tbody tr:not(:last) "+mgr.setting.el.$down,function(){
					var context = $(this).parents('tr');
					var objid1 = context.attr('objid');
					var objid2 = context.next("tr").attr('objid');
					log.info("objid1"+objid1+"objid2"+objid2);
					//query
					mgr.update_order(objid2,objid1);
					
				});
				
				//屏蔽第一个上和最后一个下
				$("table tbody tr:first").find(mgr.setting.el.$up).addClass("disabled");
				$("table tbody tr:last").find(mgr.setting.el.$down).addClass("disabled");
				
			},
			save : function(time){
				var mgr = this;
				$.post(mgr.$frm.save,time,function(msg){
					if(msg.success){
						dialog.alert.success.show(msg.txt);
						location.reload();
					}else{
						dialog.alert.error.show(msg.txt);
					}
				},'json');
			},
			del : function(objid){
				var mgr = this;
				$.post(mgr.$frm.del,{objid:objid},function(msg){
					if(msg.success){
						dialog.alert.success.show(msg.txt);
						location.reload();
					}else{
						dialog.alert.error.show(msg.txt);
					}
				},'json');
			},
			query : function(objid,callback){
				var mgr = this;
				$.post(mgr.$frm.query,{objid:objid},function(msg){
					if(msg.success){
						(callback || $.noop)(msg.obj);
					}else{
						dialog.alert.error.show(msg.txt);
					}
				},'json');
			},
			update_order : function(objid1,objid2,callback){
				var mgr = this;
				$.post(mgr.$frm.update_order,{objid1:objid1,objid2:objid2},function(msg){
					if(msg.success){
						location.reload();
						(callback || $.noop)(msg.obj);
					}else{
						dialog.alert.error.show(msg.txt);
					}
				},'json');
			}
		}
	});
	
	//绑定按钮事件
	//修改事件
	
	return new ObjectMgr();
});

