//requirejs 配置
var bversion = new Date().getTime();
var require_config = {
	baseUrl: "/health/scripts/",
	urlArgs : 'bversion='+bversion,
	shim : {
		'el':{
			deps : ['jquery'],
			exports: 'jQuery.el'
		},
		'bootstrap' : {
			deps : ['jquery']
		},
		'bootstrap-switch' : {
			deps : ['bootstrap']
		},
		'chat' : {
			exports : 'Chat'
		},
		'jquery' : {
			exports : '$'
		},
		'browser' : {
			exports : 'window.browser'
		},
		'template' : {
			deps : ['jquery']
		},
		'passport' : {
			deps : ['utils']
		},
		'hotkeys' : {
			deps : ['jquery']
		},
		'jquery.md5' : {
			deps : ['jquery']
		},
		'bootstrap-wysiwyg' : {
			deps : ['jquery','prettify','bootstrap','hotkeys']
		},
		'lightbox' : {
			deps : ['jquery']
		},
		'jquery.extend' : {
			deps : ['jquery']
		}
	},
	paths : {
		"jquery" : "jquery/dist/jquery",
		"jquery.extend" : "jquery/dist/jquery.extend",
		"jquery.md5" : "jquery/dist/jQuery.md5",
		"el" : "el/e-learning-auto",
		"bootstrap":'bootstrap/dist/js/bootstrap',
		"bootstrap-switch":'bootstrap-switch/dist/js/bootstrap-switch',
		"editor":"editor/editor",
		"utils":"utils",
		"template":"jquery_template",
		"passport":"webadmin/passport",
		"chat-toolbar":"chat-toolbar",
		"dialog":"webadmin/dialog",
		"loginmgr":"webadmin/loginmgr",
		"ObjectMgr":"webadmin/listObject",
		"KeyEvent":"KeyEvent",
		"prettify":"bootstrap-wysiwyg/external/google-code-prettify/prettify",
		"bootstrap-wysiwyg":"bootstrap-wysiwyg/bootstrap-wysiwyg",
		"hotkeys":"bootstrap-wysiwyg/external/jquery.hotkeys",
		"lightbox":"lightbox/js/lightbox",
		"browser":"browser"
	},
	waitSeconds : 15
};

