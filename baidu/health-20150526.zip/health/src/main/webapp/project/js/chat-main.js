//console.info("加载成功...");
require.config(require_config);


define('chat',['jquery','utils','jquery.extend'],function(jquery,utils){
	
	var log = new Logger('health.chat.chat');
	
	var global_setting = {
			send : 'chat/send.json',
			receive : 'chat/receive.json',
			login	: 'secure/login.json',
			logout	: 'secure/logout.json',
			enable : 'chat/enable-records.json',
			load : 'chat/load-records.json'
	};
	var Chat = function(name){
		this.name = name;
		this.index = 0;
	};
	var ChatImp = {
			setting : global_setting,
			config : function(setting){
				return $.extend(global_setting,this.setting ||{});
			},
			send : function(msg,to){
				var that = this;
				this.date = Date.f('yyyy-MM-dd hh:mm:ss');
				this.defineEvent('send',[msg,to]);
				$._post(this.setting.send, {msg:msg,to:to.nickname,sessionid:to.sessionid,date:this.date}, function(json){
					log.debug($.utils.o2s(json));
					that.defineEvent('sended',[msg,to]);
				}, 'json', function(){
					that.defineEvent('send-error',[msg,to]);
				},true);
				return true;
			},
			receive : function(){
				var that = this;
				var msg = {};
				var tname = 'chat-receive'+new Date().getTime();
				$.timmer.s(tname);
				$._post(this.setting.receive, {index:this.index}, function(json){
					msg = json;
					that.defineEvent('receive',[msg]);
					var t = $.timmer.e(tname);
					that.defineEvent('received',[msg,t]);
				}, 'json', function(){
					//console.info('receive error');
					that.defineEvent('receive-error',[msg]);
				},true);
				return msg;
			},
			login : function(username,password){
				var chat = this;
				$.post(this.setting.login,{username:username,password:password},function(msg){
					chat.sessionid = $.coookie().g("CHAT-JSESSIONID") || sessionid;
					log.debug($.utils.o2s(msg));
				},'json');
			},
			logout : function(){
				$.post(this.setting.login,{},function(msg){
					log.debug($.utils.o2s(msg));
				},'json');
			},
			enable_record : function(enable){
				$.post(this.setting.enable,{enable:enable},function(msg){
					log.debug($.utils.o2s(msg));
				},'json');
			},
			load : function(start,size,callback){
				$.post(this.setting.load,{start:start,size:size},function(msg){
					callback(msg);
					log.debug($.utils.o2s(msg));
				},'json');
			},
			liveMsg : function(cb){
				var chat = this;
				$.timmer.i('chat-live-msg',1000,function(){
					var msg = chat.receive();
					(cb||function(msg){
						log.debug($.utils.o2s(msg));
					})(msg);
				});
			},
			stopLiveMsg : function(){
				$.timmer.stop('chat-live-msg');
			}
	};
	$.extend(Chat.prototype,ChatImp,EventDelegate);
	return Chat;
});

//消息通知
define('chat-notice',['chat'],function(chat){
	
	var call = function(name){
		this.name = name;
	};
	$.extend(call.prototype,{
		stack : [],
		_do : function(func){
			this.stack.push(func);
			return this;
		},
		delay : function(i){
			this.stack.push(i);
			return this;
		},
		stop : function(){
			
		},
		done : function(f){
			if(f){
				this._do(f);
			}
			var that = this;
			var _call = this.stack.shift();
			if(typeof _call == 'function'){
				_call.apply(that,[]);
				this.done();
			}else if(typeof _call == 'number'){
				$.timmer.t(this.name,_call,function(){
					that.done();
				});
			}
		}
	});
	$.extend(call,{
		queue : [],
		_d : new call('call-default'),
		m : function(name){
			this.queue.push(name);
			return new call(name);
		},
		_do : function(f){
			return this._d._do(f);
		},
		delay : function(n){
			return this._d.delay(n);
		},
		done : function(f){
			return this._d.done(f);
		}
	});
	
	//检测
	//安装
	//通知
	chat.Notice = {
		el_plugin : '#chat-plugin',	
		pluginTpl : '<div style="display:block;width:1px;height:1px;overflow:hidden;"><object id="chat-plugin" type="application/npchat-plugin" width=400 height=150 id="so2" ></object></div>',
		notice_plugin : {},
		installed : false,
		test : function(){
			return $(this.el_plugin).size() > 0;
		},
		install : function(){
			if(!this.test()){
				$('[rel=plugin-container]').append(this.pluginTpl);
				this.notice_plugin = $(this.el_plugin).get(0);
				this.installed = this.notice_plugin.isActive ? true : false;
				if( !this.installed ){
					//提示下载插件
					//不支持移动设备，不支持chrome和firefox以外的非html5的浏览器
					var ua = navigator.userAgent.toLowerCase;
					if(!/moblie/i.test(ua)){
						$('[rel=plugin-alert]').clone().show().prependTo('.container');
					}
				}
			}else{
				// noop;
			}
		},
		isActive : function(){
			return this.notice_plugin.isActive();
		},
		flashWindowOn : function(){
			if(this.notice_plugin && !this.isActive()){
				this.notice_plugin.flashWindowOn();
			}
		},
		flashWindowOff : function(){
			if(this.notice_plugin && this.isActive()){
				this.notice_plugin.flashWindowOff();
			}
		},
		runing : false,
		notice : function(){
			if( this.installed && !this.runing){
				//激活窗口
				var that = this;
				that.runing = true;
				//this.flashWindowOff();
				call.delay(400)._do(function(){
					that.flashWindowOn();
				}).delay(400)._do(function(){
					that.flashWindowOff();
				}).delay(100)._do(function(){
					that.flashWindowOn();
				}).done(function(){
					that.runing = false;
				});
			}
		}
	};
	return chat.Notice;
});

//信号强度
define('net-sign',['chat'],function(chat){
	var net_sign_setting = {
			el : {
				progress : '#net-sign',
				progress_bar : '.progress-bar'
			},
			sign : {
				delay : 2000,
				min : 1,
				max : 10,
				progress : function(p){
					if(this.danger.progress(p)){
						return this.danger;
					}else if(this.warning.progress(p)){
						return this.warning;
					}else if(this.success.progress(p)){
						return this.success;
					}
				},
				danger : {
					progress : function(p){
						return p < 3;
					},
					style : 'progress-bar-danger',	
				},
				warning : {
					progress : function(p){
						return p >= 3 && p < 6;
					},
					style : 'progress-bar-warning',
				},
				success : {
					progress : function(p){
						return p >= 6;
					},
					style : 'progress-bar-success',	
				}
			}
	};
	$.fn.removeClassEx = function(regexp){
		var classes = (this.attr('class')||'').split(' ');
		var __cls = [];
		for(var i = 0; i < classes.length; i ++){
			var class_ = classes[i];
			if(!regexp.test(class_)){
				__cls.push(class_);
			}
		}
		this.attr('class',__cls.join(' '));
		return this;
	};
	$.fn.lastEx = function(n){
		if(n){
			var l = this.size();
			return this.slice(l-n,l);
		}else{
			return this.last();
		}
	};
	var NetSign = {
		setting : net_sign_setting,
		//更新状态
		update : function(){
			var bars = this.progress.find(this.setting.el.progress_bar);
			var sign = this.setting.sign.progress(bars.size());
			bars.removeClassEx(/progress-bar-.*/i);
			bars.addClass(sign.style);
		},
		//信号衰弱
		weak : function(bn){
			bn = bn || 1;
			var that = this;
			that.progress = $(this.setting.el.progress);
			var bars = that.progress.find(that.setting.el.progress_bar);
			if(!that.bar){
				that.bar = bars.last().clone();
			}
			if(bars.size() > that.setting.sign.min && bars.size() > bn ){
				bars.lastEx(bn).remove();
				that.update();
			}
			/*
			$.timmer.i('net-sign-auto-weak',this.setting.sign.delay,function(){
			});*/
		},
		//信号增强
		strong : function(bn){
			bn = bn || 1;
			var that = this;
			that.progress = $(that.setting.el.progress);
			var bars = that.progress.find(that.setting.el.progress_bar);
			if(!that.bar){
				that.bar = bars.last().clone();
			}
			if((bars.size() + bn) <= that.setting.sign.max){
				that.progress.append(that.copyBar(bn));//that.bar.clone()
				that.update();
			}
		},
		copyBar : function(n){
			var bars = [];
			for(var i = 0; i < n; i ++){
				bars.push(this.bar.clone());
			}
			return bars;
		},
		noop : function(){},
		//信号实体
		sign : {
			min : 10,//最小响应时间
			max : 0,//最大响应时间
			avg : 5,//平均响应时间
			last : -1,//上次响应时间
			step : 5,//最大变化幅度
			log : function(){
				var s = [];
				for(var a in this){
					var v = this[a];
					v = typeof v == 'function' ? 'function' : v;
					s.push(a + "=" + v );
				}
				return s.join(';');
			},
			//比较两次响应时间
			compare : function(a,b){
				return a >= b ? a == b ? 0 : 1 : -1;
			},
			//转化为信号强度
			tosign : function(s){
				var sign = {
					"-1" : 'weak',
					"0" : 'noop',
					"1" : 'strong'
				};
				return sign[s];
			},
			//信号检测
			check : function(t){
				var that = this,sign = 'noop';
				var d = t.diff || 0 ;
				this.cost = d;
				var bar = 1;
				try{
					//初始化信号信息
					if( this.last < 0 ) {
						this.last = d;
						this.min = Math.min(d,this.min);
						this.max = Math.max(d,this.max);
						this.avg = (this.min + this.max) / 2;
					}
					//测算信号变化幅度
					var step = Math.abs(d - this.avg) % 5 ;
					this._step = step;
					if( step <= this.step ){
						//计算信号变化情况及强度
						var min = this.min = Math.min(d,this.min);
						var max = this.max = Math.max(d,this.max);
						var avg = (min + max) / 2;
						var pavg = this.compare( this.avg, avg ) ;//? 'strong' : 'weak'
						var pcost = this.compare( avg , d );
						sign = this.compare( this.last , d);
						sign = sign == 0 ? ( pavg == 0 ? that.tosign(pcost) : that.tosign(pavg)) : that.tosign(sign);
						bar = (d - this.last);
						bar = Math.abs(bar) % 5;
						this.bar = bar;
						this.avg = avg;
					}else{
						sign = this.tosign(sign);
					}
					
				}catch(e){
					console.error(e.message);
				}
				
				this.sign = sign;
				//console.info(that.log());
				
				this.last = d;
				return {sign:sign,bar:bar};
			}
		},
		//监听网络响应时间
		listener : function(t){
			//t.show();
			var that = this;
			var sign = that.sign.check(t);
			that[sign.sign](sign.bar);
		}
	};
	return NetSign;
});
define('ChatWorker',['chat','chat-notice','net-sign'],function(Chat,Notice,sign){
	var keysetting = {
		"Ctrl+Enter":function(e){
			var is = e.ctrlKey && e.which == 10;
			if(is) e.preventDefault();
			return is;
		},
		"Shit+Enter":function(e){
			var is = e.shiftKey && e.which == 13;
			if(is) e.preventDefault();
			return is;
		},
		"Enter":function(e){
			var enter = e.which == 13;
			if(enter) e.preventDefault();
			return enter;
		}
	};
	var log = new Logger('health.chat.chatworker');
	var setting = {
		msg_tpl : '<li class="msg"><div class="col-md-12"><em></em><span class="glyphicon glyphicon-info-sign"></span><span>{0}</span></div></li>',//信息模板
		send_tpl : '<li class="msg send"><div class="col-md-12"><em></em><span>：我</span><span>{1}</span><span>{0}</span></div></li>',//发送模板
		receive_tpl : "<li class='msg'><div class='col-md-12'><em></em><span>{from}</span><span>{date}</span><p class='bg-info'><span>{msg}</span></p></div></li>",//接收信息模板
		user_tpl : "<li nickname='{nickname}' sessionid='{sessionid}' role='presentation'><a  class='user bg-info'><span class='glyphicon glyphicon-user'></span>{nickname}</a></li>",//用户模板
		one_el : '.one',
		many_el : '.many',
		lchat_el : '.lchat',
		chat_log_el : '[rel=chat-logs]',//聊天记录
		chat_log_panel_el : '.chatPanel',//聊天记录容器
		people_list_el : '[rel=people-list]',//在线用户
		userAction_in_log_el : 'a[sessionid]',
		send_el : '[name=send]',//发送按钮
		username_el : "#username",//用户名称输入框
		people_name_el:"[rel=people-name]",//收信人显示框
		msg_el : "[name=msg]",//信息输入框
		nameok_el : "[rel=nameok]",//名称输入确定按钮
		online_num_el : "[rel=online_num]",
		COOKIE_USERNAME : 'chat_name',
		COOKIE_ENABLE_RECORD : 'chat-enable-records',//是否开启聊记录cookie存储名称
		COOKIE_EXPIRE_TIME : 1000*60*60*24*365,//cookie过期时间1年
		key_event : '.key-event',
		switch_el : '[role=tab][mode]',
		emotBtn_el : '[rel=emotBtn]',
		emot_panel_el : '.emot_panel',
		
		//聊天记录-------------
		el_enable_record : '[name=enable-records]',
		el_loadMore : '[rel=loadMore]',
		getMsg : function(elm){
			return elm.val().trim();
		},
		clearMsg : function(elm){
			elm.val('');
		}
	};
	var ChatWorker = function(_setting_){
		var worker = this;
		this.setting = $.extend({},setting,_setting_||{});
		
		
		var notice_arr = Array.makeArray(10,1);
		
		//初始化
		this.one = {
				chatPanel : $(this.setting.one_el+this.setting.chat_log_panel_el ),
				chat_log : $(this.setting.one_el+" "+this.setting.chat_log_el ),
				tab : $(this.setting.switch_el + "[mode=one]"),
				notice : function(){
					var mode = this;
					if(!this.className){
						this.className = "msg_tab_active";
					}
					seq(notice_arr.copy(),function(i,num){
						if(num % 2 == 0){
							mode.tab.addClass(mode.className);
						}else{
							mode.tab.removeClass(mode.className);
						}
					},function(){
						mode.tab.removeClass(mode.className);
					},1000);
				}
		};
		this.many = {
				chatPanel : $(this.setting.many_el+this.setting.chat_log_panel_el ),
				chat_log : $(this.setting.many_el+" "+this.setting.chat_log_el ),
				to : {
					name:'chat_room',
					nickname:'chat_room',
					sessionid:this.setting.chat_room_sessinid
				},
				tab : $(this.setting.switch_el + "[mode=many]"),
				notice : function(){
					var mode = this;
					if(!this.className){
						this.className = "msg_tab_active";
					}
					seq(notice_arr.copy(),function(i,num){
						if(num % 2 == 0){
							mode.tab.addClass(mode.className);
						}else{
							mode.tab.removeClass(mode.className);
						}
					},function(){
						mode.tab.removeClass(mode.className);
					},1000);
				}
		};
		this.lchat = {
				chat_log : $(this.setting.lchat_el+" "+this.setting.chat_log_el )	
		};
		
		
		this.mode = $("li.active " + this.setting.switch_el).attr('mode') || 'one';
		this.people_list = $(this.setting.people_list_el);
		this.send = $(this.setting.send_el);
		
		
		var name = $.coookie().g(this.setting.COOKIE_USERNAME) || (($.browser.product.name ||'unkown') + Date.f('yyyyMMddhhmmss')); 
		$(this.setting.username_el).val(name);
		var chat = this.chat = new Chat(name);
		chat.to = {};
		chat.nickname = chat.name;
		chat.sessionid = this.setting.sessionid;
		//chat.name = name;
		
		//扩展聊天框自动滚动、调整宽度
		this.extend_something();
		
		this.one.chat_log.append(this.setting.msg_tpl.format("你的名字是:"+chat.name));
		chat.login(name,'');
		$.coookie().s(worker.setting.COOKIE_USERNAME,name,{expires:worker.setting.COOKIE_EXPIRE_TIME});
		
		this.switchMode(this.mode);
		this.bindSwitchMode();
		this.logElm_width = $(".tab-pane.active " + this.setting.chat_log_el + " li.msg:eq(0) .col-md-12").$innerWidth() - 30 ;
		
		//初始化消息通知
		Chat.Notice.install();
		
		//信号自然衰弱
		//sign.weak();
	};
	var ChatWorkerImpl = {
		run : function(){
			this.chat.liveMsg();
			this.initilize();
		},
		start : function(){
			this.chat.liveMsg();
		},
		stop : function(){
			this.chat.stopLiveMsg();
		},
		initilize : function(){
			this.bind_receive();
			this.bind_send();
			this.bind_people();
			this.bind_nameok();
		},
		extend_something : function(){
			var worker = this;
			function extend_chat_log(_chat_log){
				_chat_log._append = _chat_log.append;
				_chat_log.append = function(html){
					var msgs = $(html);
					this._append(msgs);
					
					var msg = msgs.find(".col-md-12");
					var width = msg.$innerWidth();
					if(width < worker.logElm_width){
						width = worker.logElm_width;
					}
					var header_width = msg.find(".header").$outerWidth() || 60;
					msg.find(".body").width( width - header_width );
					log.info("width:"+width);
					var chatPanel = $(this).parent(worker.setting.chat_log_panel_el);
					chatPanel.alwaysScrollBottom();
				};
			}
			extend_chat_log(this.one.chat_log);
			extend_chat_log(this.many.chat_log);
			extend_chat_log(this.lchat.chat_log);
		},
		//绑定接收事件
		bind_receive : function(){
			var worker = this;
			
			//成功接收
			this.chat.on('received',function(json,t){
				sign.listener(t);
			});
			this.chat.on('receive-error',function(json,t){
				sign.weak();
			});
			this.chat.on('receive',function(json){
				var msgs = json.msgs || [];
				var onlineusers = json.onlineusers || [];
				
				//聊天室消息
				if(json.chat_room){
					//消息指针
					worker.chat.index = worker.many.index = json.chat_room.index || 0; 
					var room_msgs = json.chat_room.msgs || [];
					if(room_msgs.filter({},function(a,b){
						return !(b.date == worker.chat.date && b.from.sessionid == worker.chat.sessionid);
					}).length > 0){
						worker.loadChatRecords(room_msgs,worker.many);
						/*
						$.each(room_msgs,function(i,msg){
							var tpl = worker.setting.receive_tpl;
							if(msg.from.nickname == worker.chat.nickname){
								tpl = worker.setting.send_tpl;
								msg.to = {nickname:worker.many.to.nickname,sessionid:worker.many.to.sessionid};
								if(msg.date != worker.chat.date){
									var msgHtml = worker.msgFilter(tpl.format(msg));
									worker.many.chat_log.append(msgHtml);
								}
							}else{
								msg.to = worker.chat;
								var msgHtml = worker.msgFilter(tpl.format(msg));
								worker.many.chat_log.append(msgHtml);
							}
						});*/
						worker.msgNotice();
						worker.many.notice();
					}
					
				}
				
				//单人聊天消息
				if(msgs.length > 0){
					worker.loadChatRecords(msgs,worker.one);
					/*
					$.each(msgs,function(i,msg){
						msg.to = worker.chat;
						var msgHtml = worker.msgFilter(worker.setting.receive_tpl.format(msg));
						worker.one.chat_log.append(msgHtml);
					});*/
					worker.msgNotice();
					worker.one.notice();
				}
				
				//更新在线好友信息
				if(onlineusers.length >= 0){
					//自动登录
					if(onlineusers.indexOf(worker.chat,function(a,b){
						return a.sessionid == b.sessionid;
					}) < 0){
						worker.chat.login(worker.chat.name,'');
					}
					$(worker.setting.online_num_el).text(onlineusers.length);
					//log.debug(onlineusers.length);
					worker.people_list.empty();
					$.each(onlineusers.filter(worker.chat,function(a,b){
						return a.sessionid != b.sessionid;
					}),function(i,user){
						var userElm = $(worker.setting.user_tpl.format(user));
						try{
							if(worker.chat.to.sessionid == user.sessionid){
								userElm.addClass('active');
							}
						}catch(e){
							log.warn('no receiver when draw online user');
						}
						worker.people_list.append(userElm);
					});
				}
			});
		},
		//绑定发送信息点击按钮
		bind_send : function(){
			var worker = this;
			this.send.click(function(){
				var msgElm = $(worker.setting.msg_el);
				var msg = worker.setting.getMsg(msgElm);
				if(msg != ''){
					var to = worker.chat.to ;
					if(!to){
						worker.switchMode(worker.mode);
						to = worker.chat.to ;
						if(!to){
							log.warn('no receiver');
							return ;
						}
					}
					if(to.nickname != ''){
						var mSg = {msg:msg,date:Date.f('yyyy-MM-dd hh:mm:ss'),to:to,from:worker.chat};
						var msgHtml = worker.msgFilter(worker.setting.send_tpl.format(mSg));
						worker.chat_log.append(msgHtml);
						worker.chat.send(msg,to);
						worker.setting.clearMsg(msgElm);
					}
				}
				if($(".only_mobile").is(":hidden")){
					
				}else{
					msgElm.focus();
				}
			});
			
			//发送快捷键
			$("li",worker.setting.key_event).click(function(e){
				$("li",worker.setting.key_event).removeClass("active");
				$(this).addClass("active");
				e.preventDefault();
				var key = $("a",this).attr("key");
				//console.info(key);
				current_key_setting = keysetting[key];
			});
			
			
			var currentKey = $(this.setting.key_event + " li.active a").attr('key') || 'Enter';
			
			var current_key_setting = keysetting[currentKey];
			
			$(worker.setting.msg_el).keypress(function(e){
				//console.info('key'+e.which);
				if(current_key_setting(e)){
					worker.send.click();
				}
				//console.info("e.ctrlKey"+e.ctrlKey+e.which+'-'+String.fromCharCode(e.which));
			});
			
			//聊天记录鼠标滑过效果
			worker.chat_log.find('li').hover(function(){
				$(this).addClass('hover');
			},function(){
				$(this).removeClass('hover');
			});
			
			//是否开启聊天记录
			var enable = $.coookie().g(worker.setting.COOKIE_ENABLE_RECORD) == 'true';
			worker.chat.enable_record(enable);
			$(worker.setting.el_enable_record).attr('checked',enable);
			
			$(worker.setting.el_enable_record).click(function(){
				var enable = $(this).is(":checked");
				worker.chat.enable_record(enable);
				$.coookie().s(worker.setting.COOKIE_ENABLE_RECORD,enable,{expires:worker.setting.COOKIE_EXPIRE_TIME});
			});
			
			//加载聊天记录 el_loadMore
			var loadMore = {
					page : 0,
					size : 10,
					loadDom : $(worker.setting.el_loadMore),
					li : $(worker.setting.el_loadMore).parents('li'),
					ul : $(worker.setting.el_loadMore).parents('ul'),
					format : function(msgs){
						var __msgs = [];
						for(var i = 0; i < msgs.length; i ++){
							var msg = msgs[i];
							__msgs.push({
								date : new Date(msg.date).f(),
								msg : msg.msg,
								from :{
									sessionid : msg.from,
									nickname : msg.from_nickname
								},
								to : {
									sessionid : msg.to,
									nickname : msg.to_nickname
								}
							});
						}
						return __msgs;
					},
					load : function(){
						var lm = this;
						worker.chat.load(lm.page * lm.size ,this.size,function(result){
							if(result.msgs && result.msgs.length > 0){
								worker.loadChatRecords(lm.format(result.msgs), worker.lchat);
								lm.page ++;
								//加载按钮移到最后
								lm.ul.append(lm.li);
							}else{
								//没有更多了
								lm.loadDom.parents("span").html("没有更多了！！！");
							}
							
							
						});
					},
					init : function(){
						var lm = this;
						this.loadDom.click(function(){
							lm.load();
						});
					}
			};
			loadMore.init();
		},
		
		//绑定在用户点击选中事件	
		bind_people : function(){
			var worker = this;
			//people click
			$(document).on('click',this.setting.people_list_el+' li',function(){
				var name = $(this).attr('nickname');
				var sessionid = $(this).attr('sessionid');
				$(worker.setting.people_name_el).val(name);
				worker.one.to = worker.chat.to = {nickname:name,sessionid:sessionid};
				//$(worker.setting.people_list_el+' li').removeClass('active');
				//$(this).addClass('active');
				worker.switch2('one');
			});
			$(document).on('click',this.setting.userAction_in_log_el,function(e){
				var name = $(this).attr('nickname');
				var sessionid = $(this).attr('sessionid');
				if(sessionid && sessionid.indexOf('chat') < 0){
					$(worker.setting.people_name_el).val(name);
					worker.one.to = worker.chat.to = {nickname:name,sessionid:sessionid};
					worker.switch2('one');
				}else{
					worker.switch2('many');
				}
				e.preventDefault();
			});
		},
		//绑定名称输入确定按钮	
		bind_nameok : function(){
			var worker = this;
			var nameok = $(this.setting.nameok_el);
			var usernameElm = $(worker.setting.username_el);
			var nameAction = function(){
				var username = usernameElm.val();
				if(username.trim() != ''){
					try{
						$.coookie().s(worker.setting.COOKIE_USERNAME,username,{expires:1000*60*60*24*365});
						worker.chat.nickname = worker.chat.name = username;
						worker.chat.login(username,'');
						worker.chat_log.append(worker.setting.msg_tpl.format("你的名字是:"+worker.chat.name));
					}catch(e){
					}
				}
			};
			nameok.click(nameAction);
			usernameElm.blur(nameAction).keypress(function(e){
				//console.info('key'+e.which);
				if(keysetting['Enter'](e)){
					this.blur();
				}
				//console.info("e.ctrlKey"+e.ctrlKey+e.which+'-'+String.fromCharCode(e.which));
			});
			
			//表情初始化
			$(this.setting.emotBtn_el).one('click',function(){
				worker.initEmot();
			});
		},
		bindSwitchMode : function(){
			var worker = this;
			$(worker.setting.switch_el).click(function(){
				var mode = $(this).attr('mode');
				worker.switchMode(mode);
			});
		},
		msgNotice : function(){
			var msg_tpl = ['【您有新的消息】','【　　　　　　】'];
			var msg = [].copy(msg_tpl,10);
			var worker = this;
			if(!worker.title) worker.title = document.title;
			//Chat.Notice.flashWindowOn();
			seq(msg,
				function(i,title){
					document.title= title;
					
					//任务栏通知-依赖插件
					Chat.Notice.notice();
				},function(){
					document.title= worker.title;
				},1000
			);
		},
		msgFilter : function(html){
			return this.setting.msgFilter(html);
		},
		switchMode : function(mode){
			mode = mode || 'one';
			this.mode = mode;
			var obj = this[mode];
			this.chat_log = obj.chat_log;
			this.chatPanel = obj.chatPanel;
			this.chat.to = obj.to;
			//this.chat.index = obj.index;
		},
		switch2 : function(mode){
			mode = mode || 'one';
			var modeBtn = $(worker.setting.switch_el + "[mode="+mode+"]");
			if(!modeBtn.parent('li').is(".active")){
				modeBtn.click();
			}
		},
		initEmot : function(){
			var panel = $(this.setting.emot_panel_el);
			
			var emot_face = Array.makeArray(55,1);
			var img_tpl = "<img src='{url}' data-edit='insertEmot' style='background-img:url({url})'/>" ;
			
			var default_face = [{'name':'smile-cry','title':'微笑'},{'name':'smile','title':'微笑'},{'name':'tongue','title':'吐舌头'},{'name':'titter','title':'偷笑'},{'name':'laugh','title':'大笑'},{'name':'sad','title':'难过'},{'name':'wronged','title':'委屈'},{'name':'fastcry','title':'快哭了'},{'name':'cry','title':'哭'},{'name':'wail','title':'大哭'},{'name':'mad','title':'生气'},{'name':'knock','title':'敲打'},{'name':'curse','title':'骂人'},{'name':'crazy','title':'抓狂'},{'name':'angry','title':'发火'},{'name':'ohmy','title':'惊讶'},{'name':'awkward','title':'尴尬'},{'name':'panic','title':'惊恐'},{'name':'shy','title':'害羞'},{'name':'cute','title':'可怜'},{'name':'envy','title':'羡慕'},{'name':'proud','title':'得意'},{'name':'struggle','title':'奋斗'},{'name':'quiet','title':'安静'},{'name':'shutup','title':'闭嘴'},{'name':'doubt','title':'疑问'},{'name':'despise','title':'鄙视'},{'name':'sleep','title':'睡觉'},{'name':'bye','title':'再见'}];
			var default_tpl = "<img src='{url}' data-edit='insertEmot' style='background-img:url(url)' title='{title}'/>" ;
			
			var pidgin_face = [{'name':'smile','title':'微笑'},{'name':'cute','title':'可爱'},{'name':'wink','title':'眨眼'},{'name':'laugh','title':'大笑'},{'name':'victory','title':'胜利'},{'name':'sad','title':'伤心'},{'name':'cry','title':'哭泣'},{'name':'angry','title':'生气'},{'name':'shout','title':'大骂'},{'name':'curse','title':'诅咒'},{'name':'devil','title':'魔鬼'},{'name':'blush','title':'害羞'},{'name':'tongue','title':'吐舌头'},{'name':'envy','title':'羡慕'},{'name':'cool','title':'耍酷'},{'name':'kiss','title':'吻'},{'name':'shocked','title':'惊讶'},{'name':'sweat','title':'汗'},{'name':'sick','title':'生病'},{'name':'bye','title':'再见'},{'name':'tired','title':'累'},{'name':'sleepy','title':'睡了'},{'name':'question','title':'疑问'},{'name':'rose','title':'玫瑰'},{'name':'gift','title':'礼物'},{'name':'coffee','title':'咖啡'},{'name':'music','title':'音乐'},{'name':'soccer','title':'足球'},{'name':'good','title':'赞同'},{'name':'bad','title':'反对'},{'name':'love','title':'心'},{'name':'brokenheart','title':'伤心'}];
			var ipb_face = [{'name':'smile','title':'微笑'},{'name':'joyful','title':'开心'},{'name':'laugh','title':'笑'},{'name':'biglaugh','title':'大笑'},{'name':'w00t','title':'欢呼'},{'name':'wub','title':'欢喜'},{'name':'depres','title':'沮丧'},{'name':'sad','title':'悲伤'},{'name':'cry','title':'哭泣'},{'name':'angry','title':'生气'},{'name':'devil','title':'魔鬼'},{'name':'blush','title':'脸红'},{'name':'kiss','title':'吻'},{'name':'surprised','title':'惊讶'},{'name':'wondering','title':'疑惑'},{'name':'unsure','title':'不确定'},{'name':'tongue','title':'吐舌头'},{'name':'cool','title':'耍酷'},{'name':'blink','title':'眨眼'},{'name':'whistling','title':'吹口哨'},{'name':'glare','title':'轻视'},{'name':'pinch','title':'捏'},{'name':'sideways','title':'侧身'},{'name':'sleep','title':'睡了'},{'name':'sick','title':'生病'},{'name':'ninja','title':'忍者'},{'name':'bandit','title':'强盗'},{'name':'police','title':'警察'},{'name':'angel','title':'天使'},{'name':'magician','title':'魔法师'},{'name':'alien','title':'外星人'},{'name':'heart','title':'心动'}];
			var msn = Array.makeArray(40,1);
			
			var emot_config = {
					emot : {
						tpl : img_tpl,
						path : 'images/face1/{0}.gif',
						data : emot_face
					},
					msn : {
						tpl : img_tpl,
						path : 'images/msn/{0}.gif',
						data : msn
					},
					pidgin : {
						tpl : default_tpl,
						path : 'images/pidgin/{name}.gif',
						data : pidgin_face
					},
					ipb : {
						tpl : default_tpl,
						path : 'images/ipb/{name}.gif',
						data : ipb_face
					},
					'default' : {
						tpl : default_tpl,
						path : 'images/default/{name}.gif',
						data : default_face
					}
			};
			
			var initEmot = function(name){
				console.info('init emot...');
				var epanel = panel.find("."+name);
				var emot_data = emot_config[name] || emot_config['default'];
				seq(emot_data.data,function(i,n){
					var tpl = emot_data.tpl;
					var path = emot_data.path;
					var url = path.format(n);
					var o = {};
					if($.isPlainObject(n)){
						n.url = url;
						o = n;
					}else{
						o = {url:url};
					}
					epanel.append(tpl.format(o));
				},function(){
					
				},100);
			};
			panel.find('.tab a').one('click',function(e){
				console.info('click emot...');
				var emot_name = $(this).attr('rel');
				initEmot(emot_name);
				//e.stopPropagation();
				//e.preventDefault();
			});
			
			$("[role=tabs]").each(function(i,elm){
				var target = $(elm).attr("data-target");
				var tabs = $("[role=tab]",elm);
				var pads_role = $("[role=pads]"+target);
				var pads = $("[role=pad]",pads_role);
				tabs.click(function(e){
					tabs.removeClass("active");
					$(this).addClass("active");
					var at = tabs.index(this);
					pads.removeClass("active");
					pads.eq(at).addClass("active");
					e.stopPropagation();
				});
			});
			
			var emot_config_name = $("[role=tab].active a",panel).attr('rel');
			initEmot(emot_config_name);
			
			
			/*for(var i = 1; i <= face_length; i ++){
				panel.append(img_tpl.format(i));
			}*/
		},
		//加载聊天记录
		loadChatRecords : function(msgs,target){
			var worker = this;
			$.each(msgs,function(i,msg){
				var tpl = worker.setting.receive_tpl;
				if(msg.from.sessionid == worker.chat.sessionid){
					tpl = worker.setting.send_tpl;
					msg.to = target.to || msg.to ;
					if(msg.date != worker.chat.date){
						var msgHtml = worker.msgFilter(tpl.format(msg));
						target.chat_log.append(msgHtml);
					}
				}else{
					msg.to = msg.to || worker.chat;
					var msgHtml = worker.msgFilter(tpl.format(msg));
					target.chat_log.append(msgHtml);
				}
			});
		}
	};
	$.extend(ChatWorker.prototype,ChatWorkerImpl);
	return ChatWorker;
});

require(['ChatWorker','bootstrap','lightbox','chat-toolbar'], function (ChatWorker){
	window.ChatWorker =  ChatWorker;
	jQuery(function($){
		var receive_tpl = $("#receiveMsg_tpl").html();
		var send_tpl = $("#sendMsg_tpl").html();
		
		var receive_simple_tpl = $("#receiveMsg_simple_tpl").html();
		var send_simple_tpl = $("#sendMsg_simple_tpl").html();
		
		var receive_quote_tpl = $("#receiveMsg_quote_tpl").html();
		var send_quote_tpl = $("#sendMsg_quote_tpl").html();
		
		
		var tpl_config = [
		                  {//普通的模板
		                	  receive_tpl : receive_tpl,
		                	  send_tpl	  : send_tpl
		                  },
		                  {//简单模板
		                	  receive_tpl : receive_simple_tpl,
		                	  send_tpl	  : send_simple_tpl
		                  },
		                  {//华丽的模板
		                	  receive_tpl : receive_quote_tpl,
		                	  send_tpl	  : send_quote_tpl
		                  },
		                  {}//默认模板
		                  ];
		
		
		var CHAT_SESSION_NAME; 
		try{
			CHAT_SESSION_NAME = chat_session_name  || "CHAT-JSESSIONID";
		}catch(e){
			CHAT_SESSION_NAME ="CHAT-JSESSIONID";
			//console.info(e.message)
		}
		var setting = {
				sessionid : $.coookie().g(CHAT_SESSION_NAME) || sessionid,
				chat_room_sessinid : chat_room_sessinid,
				msg_el : '#bootstrap_editor',
				getMsg : function(elm){
					return elm.html().trim();
				},
				clearMsg : function(elm){
					elm.empty();
				},
				//过滤消息，链接消息新开窗口
				filterMsg : function(msg){
					var regexp = /(http:\/\/([\w-]+\.)+[\w-]+(\/[\w-.\/?%;:&=\u4E00-\u9FA5]*)?)/img;
					if(regexp.test(msg)){
						msg = msg.replace(regexp,function(a,b,c){
							//console.info(arguments);
							var imgreg = /\.(gif|jpg|jpeg|png|bmp|ico|blob)\??.*/img;
							if(!imgreg.test(b)){
								return "<a href='{url}' target='_blank'>{url}</a>".format({url:b});
							}
							return b;
						});
					}
					//filter jscirpt
					/**/
					var jsreg = /(<)(\/?script)(>)/img;
					if(jsreg.test(msg)){
						msg = msg.replace(jsreg,function(a,b,c,d){
							//console.info(arguments);
							return "&lt;"+c+"&gt;";
						});
						//console.info(msg);
					}
					return msg;
				},
				msgFilter : function(html){
					var msg = $(setting.filterMsg(html));
					msg.find("img").css("max-width","100%")
					.attr('data-lightbox',"chat-img")
					.attr('data-title',"聊天的图片");
					return msg;
				},
				msg_tpl : '<li class="msg"><div class="col-md-12"><em></em><span class="glyphicon glyphicon-info-sign"></span><span>{0}</span></div></li>',//信息模板
				receive_tpl : receive_quote_tpl,//接收信息模板
				send_tpl : send_quote_tpl//发送模板
		};
		window.worker = new ChatWorker($.extend(setting,tpl_config.random()||{}));
		//worker.chat.receive();
		//worker.bind_people();
		worker.run();
		
	});
});

require(['bootstrap-wysiwyg'], function (){
	
	$(function($){
		function initToolbarBootstrapBindings() {
	      var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier', 
	            'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
	            'Times New Roman', 'Verdana'],
	            fontTarget = $('[title=Font]').siblings('.dropdown-menu');
	      $.each(fonts, function (idx, fontName) {
	          fontTarget.append($('<li><a data-edit="fontName ' + fontName +'" style="font-family:\''+ fontName +'\'">'+fontName + '</a></li>'));
	      });
	      $('a[title]').tooltip({container:'body'});
	    	$('.dropdown-menu input').click(function() {return false;})
			    .change(function () {$(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');})
	        .keydown('esc', function () {this.value='';$(this).change();});

	      $('[data-role=magic-overlay]').each(function () { 
	        var overlay = $(this), target = $(overlay.data('target')); 
	        overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
	      });
	      if ("onwebkitspeechchange"  in document.createElement("input")) {
	        var editorOffset = $('#editor').offset();
	        $('#voiceBtn').css('position','absolute').offset({top: editorOffset.top, left: editorOffset.left+$('#editor').innerWidth()-35});
	      } else {
	        $('#voiceBtn').hide();
	      }
		};
		function showErrorAlert (reason, detail) {
			var msg='';
			if (reason==='unsupported-file-type') { msg = "Unsupported format " +detail; }
			else {
				console.log("error uploading file", reason, detail);
			}
			$('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>'+ 
			 '<strong>File upload error</strong> '+msg+' </div>').prependTo('#alerts');
		};
	    initToolbarBootstrapBindings();
	    //文件上传
	    function uploadFile(file){
	    	var loader = $.Deferred();
	    	var formdata = new FormData();
	    	formdata.append('file',file);
	    	$.ajax('/health/chat/upload-img.json',{
	    		data:formdata,
	    		processData:false,//不处理数据
	    		contentType:false,//不设置contentType
	    		type:'POST',
	    		success:function(d,t,x){
	    			console.info(d);
	    			loader.resolve(d.imgUrl);
	    		},
	    		error : loader.reject
	    	});
	    	
			return loader.promise();
	    }
		$('#bootstrap_editor').wysiwyg({ 
			fileUploadError: showErrorAlert,
			fileUpload : function(file){
				window.fileInfo = file;
				console.info(fileInfo);
				return uploadFile(fileInfo);
			}
		} ).focus(function(){
			$(this).addClass("focus");
		}).blur(function(){
			$(this).removeClass("focus");
		});
	    window.prettyPrint && prettyPrint();
	    
	});
	
});



