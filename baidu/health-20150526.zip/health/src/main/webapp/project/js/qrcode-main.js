//加载配置
require.config(require_config);
require(['jquery','utils','chat-toolbar'], function ($,utils,ChatToolBar){
	var qrcode_src = "baidu/image/qrcode.html?text={0}&size=90";
	var text = $("[name=text]");
	var generate = $("[name=generate]");
	var qrcode = $("[rel=qrcode]");
	
	generate.click(function(){
		var txt = text.val();
		qrcode.attr('src',qrcode_src.format(encodeURIComponent(encodeURIComponent(txt))));
	});
});



