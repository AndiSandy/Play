/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: UserTest.java
 * Author:   14041326
 * Date:     2014年7月10日 下午2:17:43
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.local.web.health.chat.ChatUser;
import com.local.web.util.MD5Util;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class ChatUserTest {
    
	List<ChatUser> users = new ArrayList<ChatUser>();
	
	Map<ChatUser,String> msgs = new HashMap<ChatUser,String>();
    
    @Before
    public void before(){
        
    	for(int i = 0; i < 10; i ++){
    		ChatUser user = new ChatUser(MD5Util.MD5(""+i),"hehe"+i,"magic"+1);
    		users.add(user);
    		msgs.put(user, "msg"+i);
    	}

    }
    
    @Test
    public void test(){
        
    	ChatUser user = new ChatUser(MD5Util.MD5("5"),"hehe8","magic"+1);
        
    	System.out.println("hashcode:"+user.hashCode());
    	
    	System.out.println("at:"+users.indexOf(user));
    	
    	System.out.println("msg:"+msgs.get(user));
    	
    	System.out.println("has:"+msgs.containsKey(user));
    	
    }
    
    
}
