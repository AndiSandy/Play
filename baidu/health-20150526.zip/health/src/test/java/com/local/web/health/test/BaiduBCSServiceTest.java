/*
 * Copyright (C), 2002-2015, 苏宁易购电子商务有限公司
 * FileName: BaiduBCSServiceTest.java
 * Author:   Administrator
 * Date:     2015年1月7日 下午11:44:24
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.baidu.inf.iis.bcs.model.ObjectMetadata;
import com.baidu.inf.iis.bcs.model.ObjectSummary;
import com.local.web.health.service.BaiduBCSService;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author Administrator
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class BaiduBCSServiceTest {
	
	
	private BaiduBCSService baiduBCSServiceImpl;
    
    @Before
    public void before(){
        @SuppressWarnings("resource")
        ApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"classpath:applicationContext.xml"});
        baiduBCSServiceImpl = (BaiduBCSService) context.getBean("baiduBCSServiceImpl");

    }
    
    @Test
    public void test(){
    	List<ObjectSummary> oss = baiduBCSServiceImpl.list(0,20,"/");
		for (ObjectSummary os : oss) {
			System.out.println(os.toString());
		}
    }
    
    @Test
    public void testPut(){
    	String filename = "D:\\JAVA_HOME.txt";
    	File file = new File(filename);
    	try {
    		ObjectMetadata result = baiduBCSServiceImpl.put("/java_home.text", file, "text/html");
    		System.out.println("=================="+result);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
	
}
