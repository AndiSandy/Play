/*
 * Copyright (C), 2002-2014, 苏宁易购电子商务有限公司
 * FileName: UserTest.java
 * Author:   14041326
 * Date:     2014年7月10日 下午2:17:43
 * Description: //模块目的、功能描述      
 * History: //修改记录
 * <author>      <time>      <version>    <desc>
 * 修改人姓名             修改时间            版本号                  描述
 */
package com.local.web.health.test;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.local.web.health.service.BaiduImageService;

/**
 * 〈一句话功能简述〉<br> 
 * 〈功能详细描述〉
 *
 * @author 14041326
 * @see [相关类/方法]（可选）
 * @since [产品/模块版本] （可选）
 */
public class BaiduImageServiceTest {
    
    private BaiduImageService baiduImageServiceImpl;
    
    @Before
    public void before(){
        @SuppressWarnings("resource")
        ApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"classpath:applicationContext.xml"});
        baiduImageServiceImpl = (BaiduImageService) context.getBean("baiduImageServiceImpl");

    }
    
    @Test
    public void test(){
        String text = "hello world";
    	byte[] bs = baiduImageServiceImpl.getQRCodeImage(text, 90, "AABBCC");
        System.out.println(bs.length);
    }
    
    
}
