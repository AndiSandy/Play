CREATE TABLE `Health_T_User` (
`userId` int NOT NULL AUTO_INCREMENT,
`userName` varchar(255) NOT NULL COMMENT '用户名称',
`nickname` varchar(255) NULL COMMENT '昵称',
`password` varchar(255) NOT NULL COMMENT 'md5密码',
PRIMARY KEY (`userId`) 
)
DEFAULT CHARACTER SET=utf;

CREATE TABLE `Health_T_TimeElm` (
`timeId` int NOT NULL AUTO_INCREMENT,
`timeName` varchar(255) NULL COMMENT '时间元素名称',
`orderno` int NOT NULL AUTO_INCREMENT,
PRIMARY KEY (`timeId`) 
)
DEFAULT CHARACTER SET=utf;

CREATE TABLE `Health_T_WeightLog` (
`logId` int NOT NULL AUTO_INCREMENT,
`userId` int NOT NULL COMMENT '用户id',
`weight` double NULL COMMENT '体重',
`timeId` int NULL COMMENT '时间元素id',
`logTime` datetime NULL COMMENT '记录时间',
PRIMARY KEY (`logId`) 
)
DEFAULT CHARACTER SET=utf;

CREATE TABLE `Health_T_Browser` (
`bid` int NOT NULL AUTO_INCREMENT COMMENT '记录id',
`userAgent` varchar(255) NULL,
`screen` varchar(128) NULL,
`ip` varchar(128) NULL,
PRIMARY KEY (`bid`) 
);

CREATE TABLE `Health_T_Role` (
`roleid` int NOT NULL AUTO_INCREMENT,
`roleName` varchar(128) NULL,
`orderno` int NULL,
PRIMARY KEY (`roleid`) 
);

CREATE TABLE `Health_T_Menu` (
`mid` int NOT NULL AUTO_INCREMENT,
`menuName` varchar(128) NULL,
`url` varchar(255) NULL,
`parentid` int NULL,
`orderno` int NULL AUTO_INCREMENT,
PRIMARY KEY (`mid`) 
);

CREATE TABLE `Health_T_Group` (
`gid` int NOT NULL AUTO_INCREMENT,
`groupName` varchar(128) NULL,
`parentid` int NULL DEFAULT 0,
`orderno` int NULL,
PRIMARY KEY (`gid`) 
);

CREATE TABLE `Health_T_Role_Menu` (
);

CREATE TABLE `Health_T_User_Role` (
);

CREATE TABLE `Health_T_User_Group` (
);

CREATE TABLE `Health_T_ChatRecord` (
`rid` int NOT NULL AUTO_INCREMENT,
`msg` varchar(2048) NULL,
`from` varchar(128) NULL,
`to` varchar(128) NULL,
`date` datetime NULL,
`from_nickname` varchar(128) NULL,
`to_nickname` varchar(128) NULL,
PRIMARY KEY (`rid`) 
);

CREATE TABLE `Health_T_Q_Group` (
`gnum` varchar(255) CHARACTER SET utf8 NOT NULL,
`gname` varchar(255) NULL,
`owner` varchar(255) NULL,
PRIMARY KEY (`gnum`) 
);

CREATE TABLE `Health_T_Q_User` (
`qnum` varchar(255) CHARACTER SET utf8 NOT NULL,
`card` varchar(255) NULL,
`nick` varchar(255) NULL,
`gender` varchar(255) NULL,
`gnum` varchar(255) NULL,
PRIMARY KEY (`qnum`) 
);

CREATE TABLE `Health_T_L_Lottery` (
`qi` varchar(255) NULL,
`red1` varchar(255) NULL,
`red2` varchar(255) NULL,
`red3` varchar(255) NULL,
`red4` varchar(255) NULL,
`red5` varchar(255) NULL,
`red6` varchar(255) NULL,
`blue` varchar(255) NULL,
INDEX `INDEX_L_QI` (`qi`)
);


ALTER TABLE `Health_T_WeightLog` ADD CONSTRAINT `FK_userId` FOREIGN KEY (`userId`) REFERENCES `Health_T_User` (`userId`);
ALTER TABLE `Health_T_WeightLog` ADD CONSTRAINT `FK_timeId` FOREIGN KEY (`timeId`) REFERENCES `Health_T_TimeElm` (`timeId`);

